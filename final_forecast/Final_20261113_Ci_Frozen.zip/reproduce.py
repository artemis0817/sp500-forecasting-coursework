import csv,json,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'training_C.csv').open()))
x=[float(r['momentum']) for r in rows]
y=[float(r['return']) for r in rows]
b=statistics.covariance(x,y)/statistics.variance(x)
a=statistics.mean(y)-b*statistics.mean(x)
s=json.loads((p/'inputs.json').read_text())
m=s['baseline']/s['lookback']-1
r=a+b*m
f=s['baseline']*(1+r)
print(json.dumps(dict(training_n=len(rows),intercept=a,slope=b,momentum=m,expected_return=r,forecast_full_precision=f,forecast_points=format(f,'.2f'))))

"""Explicit source-substitution diagnostic; never issues or overwrites a live forecast."""
from pathlib import Path
import sys,json,shutil,subprocess,os,re
from html.parser import HTMLParser
from datetime import date,datetime,timezone
from decimal import Decimal
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'workflow_v2')]
import live_trials as l
import workflow as w
class Rows(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,t,a):
  if t=='tr':self.row=[]
  if t in ('td','th') and self.row is not None:self.cell=[]
 def handle_data(self,d):
  if self.cell is not None:self.cell.append(d)
 def handle_endtag(self,t):
  if t in ('td','th') and self.cell is not None:
   self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
  if t=='tr' and self.row is not None:self.rows.append(self.row);self.row=None

def main():
 begun=l.now();origin=date(2026,11,3);cut=l.noon(origin);out=HERE/'replays'/begun.strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True)
 blocked=next((ROOT/'2026-11-03/workflow_v2_runs').glob('*'))
 protected=[p for folder in [ROOT/'2026-11-03/workflow_v2_runs',ROOT/'2026-11-03/validation_attempts'] for p in folder.rglob('*') if p.is_file()]
 before={str(p):l.sha(p) for p in protected}
 raw=out/'raw';raw.mkdir();shutil.copytree(blocked/'raw',raw/'fred')
 for path in sorted(HERE.glob('2026*')):
  if path.is_dir():shutil.copytree(path,raw/path.name)
 for p in HERE.glob('*web_check.json'):shutil.copy2(p,raw/p.name)
 source=raw/'20261103T101226901165Z';parse=Rows();parse.feed((source/'yahoo.html').read_text());row=next(r for r in parse.rows if r and r[0]=='Nov 2, 2026')
 assert len(row)>=6;close=Decimal(row[4].replace(',',''));assert close==Decimal('7541.40')
 ft=Rows();ft.feed((source/'ft.html').read_text());ftrow=next(r for r in ft.rows if r and 'November 02, 2026' in r[0]);assert Decimal(ftrow[4].replace(',',''))==close
 chart=json.loads((source/'yahoo_chart.json').read_text())['chart']['result'][0];assert chart['meta']['symbol']=='^GSPC' and chart['meta']['instrumentType']=='INDEX'
 pairs=[(datetime.fromtimestamp(t,timezone.utc),v) for t,v in zip(chart['timestamp'],chart['indicators']['quote'][0]['close'])];stamp,chartclose=next((t,v) for t,v in pairs if t.date()==date(2026,11,2));assert Decimal(str(chartclose)).quantize(Decimal('.01'))==close
 p=l.read_series(raw/'fred/sp500.csv','SP500');y=l.read_series(raw/'fred/dgs10.csv','DGS10');assert date(2026,11,2) not in p
 # Price Close column only, not adjusted close or a price from an ETF/future. Raw responses never edited.
 p[date(2026,11,2)]=float(close);p=dict(sorted(p.items()))
 l.dump(out/'source_extraction.json',{'source':'Yahoo historical Close column','row':row,'FT_row':ftrow,'selected_close':str(close),'chart_close_binary':chartclose,'chart_daily_bar_timestamp':stamp,'bar_timestamp_note':'session-open daily-bar label, not close or publication timestamp','observation_close_UTC':'2026-11-02T21:00:00+00:00','observation_close_New_York':'2026-11-02T16:00:00-05:00','user_supplied_value_not_used_without_independent_check':True})
 for key,vals in [('SP500',p),('DGS10',y)]:l.write(out/f'processed/{key}.csv',[{'observation_date':d,key:v,'source':'Yahoo explicit one-row supplement' if key=='SP500' and d==date(2026,11,2) else 'frozen FRED CSV'} for d,v in vals.items()])
 result=l.predict(p,y,origin);inputs,forecasts,tc,td,excluded,_=result;checks,ind=l.validate(p,y,origin,result)
 assert all(l.b.close_at(l.calendar(),r['target_date'])<cut for r in tc+td)
 l.dump(out/'inputs.json',inputs);l.write(out/'training_C.csv',tc);l.write(out/'training_D.csv',td);l.dump(out/'training_exclusions.json',excluded)
 for f in forecasts:f.update(status='UNISSUED_SOURCE_SUBSTITUTION_REPLAY',origin=cut.isoformat(),target=inputs['target_close_utc'],actual_calculation_started=begun.isoformat(),formally_issued=False,methodological_change='Yahoo one-row baseline supplement; prior cross-provider policy absent; group approval pending')
 l.dump(out/'forecasts.json',forecasts);l.write(out/'forecasts.csv',forecasts);l.write(out/'independent_calculations.csv',ind);l.dump(out/'validation.json',checks)
 manifest=[]
 for mp in raw.rglob('*.metadata.json'):
  m=json.loads(mp.read_text());rp=mp.with_name(mp.name.removesuffix('.metadata.json'));ts=m.get('retrieved_UTC',m.get('retrieved_at_utc'))
  if rp.exists():assert l.sha(rp)==m['sha256']
  if ts:assert datetime.fromisoformat(ts)<cut
  manifest.append({'url':m['url'],'raw_path':str(rp.relative_to(out)),'raw_present':rp.exists(),'sha256':m.get('sha256'),'retrieved_UTC':ts,'retrieved_Europe_London':ts,'original_publication_timestamp':None,'first_availability_timestamp':None,'first_availability_verification':'not independently established; successful pre-cutoff retrieval is an observed-by bound','error':m.get('error')})
 l.dump(out/'raw_source_manifest.json',manifest)
 yahoo_meta=json.loads((source/'yahoo.html.metadata.json').read_text());ft_meta=json.loads((source/'ft.html.metadata.json').read_text())
 l.dump(out/'publication_evidence.json',{'Yahoo':{'url':yahoo_meta['url'],'original_publication':None,'observed_by_UTC':yahoo_meta['retrieved_UTC'],'first_publication_verified':False,'price':str(close)},'FT':{'url':ft_meta['url'],'observed_by_UTC':ft_meta['retrieved_UTC'],'displayed_as_of':'2026-11-02T21:50:00+00:00','as_of_is_not_publication_time':True},'AP':{'url':'https://apnews.com/article/475bb37b4d95dd99e26c94e708c99f8f','indexed_article_date':'2026-11-02T21:21:03+00:00','status':'closing value corroborated by search-service article response; direct HTTP 403; original publication not independently verified from raw publisher HTML'},'Reuters':{'original_url':'https://www.reuters.com/business/media-telecom/wall-street-futures-rise-ai-stocks-catch-their-breath-midterms-focus-2026-11-02/','original_publication':None,'direct_access':'401','syndication_url':'https://uk.marketscreener.com/news/wall-st-rises-as-oil-falls-heading-into-us-midterm-elections-ce785fd9d88efe22','displayed_syndication_publication':'2026-11-02T17:10:00+00:00','displayed_syndication_modified':'2026-11-02T21:42:00+00:00','limitation':'Original timestamp predates close and cannot date insertion of the closing value. Current updated article body states 7541.40. No archived earlier version obtained; web response saved, raw syndication HTTP403.'},'historical_pre_cutoff_evidence':'Contemporaneous Yahoo and FT raw retrievals occurred before Nov3 noon, proving observed-by availability. Article timestamp metadata supports prior-evening publication but does not establish exact first publication or immutable historical article content.'})
 policy=[ROOT/'model_specification_manifest.json',ROOT/'README.md',ROOT/'workflow_v2/README.md',ROOT.parent/'docs/model_specifications.md',ROOT.parent/'treasury_extension/PROTOCOL.md',ROOT.parent/'src/run_backtest.py']
 (out/'policy_evidence').mkdir()
 for path in policy:shutil.copy2(path,out/'policy_evidence'/('_'.join(path.relative_to(ROOT.parent).parts)))
 l.dump(out/'policy_review.json',{'reviewed_files':{str(path):l.sha(path) for path in policy},'preestablished_cross_provider_policy_found':False,'existing_fallback':'FRED CSV supplemented by FRED HTML only','substitution':'one 2026-11-02 Close from Yahoo; FT/AP/Reuters corroboration; unchanged FRED training history and DGS10','approval':'user authorized this diagnostic replay; formal group adoption/issuance approval not recorded','model_rules_changed':False})
 # Fresh reruns, isolated historical outputs.
 work=out/'isolated_research';shutil.copytree(l.HIST,work,ignore=shutil.ignore_patterns('__pycache__'));env=dict(os.environ,PYTHONPATH=str(ROOT.parent/'vendor'));suites=[];(out/'test_logs').mkdir()
 for script in [work/'src/test_backtest.py',work/'src/test_point_in_time.py',work/'treasury_extension/test_extension.py',ROOT/'src/test_live.py',ROOT/'workflow_v2/test_workflow.py']:
  r=subprocess.run([sys.executable,str(script)],capture_output=True,text=True,env=env);log=out/'test_logs'/(script.stem+'.txt');log.write_text(r.stdout+r.stderr);suites.append({'script':str(script),'exit_code':r.returncode,'log':str(log.relative_to(out))});assert r.returncode==0
 l.dump(out/'test_results.json',suites)
 preserved=[{'path':path,'sha256_before':h,'sha256_after':l.sha(Path(path)),'unchanged':l.sha(Path(path))==h} for path,h in before.items()];assert all(r['unchanged'] for r in preserved);l.write(out/'blocked_evidence_preservation.csv',preserved)
 l.dump(out/'code_versions.json',{str(path):l.sha(path) for path in [Path(__file__),ROOT/'src/live_trials.py',l.HIST/'src/run_backtest.py',l.HIST/'treasury_extension/calculate.py']})
 finished=l.now();l.dump(out/'status.json',{'classification':'UNISSUED_SOURCE_SUBSTITUTION_REPLAY_BEFORE_CUTOFF' if finished<=cut else 'LATE_RETROSPECTIVE_SOURCE_SUBSTITUTION_REPLAY','execution_started_UTC':begun,'calculation_and_validation_completed_UTC':finished,'intended_origin_UTC':cut,'actual_issuance':None,'issued':False,'not_replacement_for_blocked_record':True,'approval_required_for_adoption':True,'if_not_issued_by_noon':'Any subsequent issuance/calculation must be retrospective/late, regardless of when source data were available','target_actual':None})
 shutil.copy2(__file__,out/'calculate_replay.py')
 rows='\n'.join(f'| {f["model"]} | {f["forecast_level"]} | {f["forecast_full_precision"]!r} | {f["intercept"]!r} | {f["momentum_beta"]!r} | {f["yield_beta"]!r} |' for f in forecasts)
 (out/'REPORT.md').write_text(f'''# Trial 2 source-substitution investigation and unissued replay

Completed {finished.isoformat()}. Intended origin 3 November 2026 12:00 GMT; target official S&P 500 price-index close 10 November 2026 21:00 GMT. This is a separately labelled diagnostic replay, not a replacement or backdated issuance. **It was computed before noon, so it is not yet a late calculation. No live forecast has been formally issued.** If no approved record is actually issued by noon, later calculations must be retrospective regardless of underlying data availability.

## Verified value and publication evidence

The raw Yahoo historical **Close** row for 2 November reads **7,541.40**, independently matching the FT historical row and the Yahoo chart INDEX/^GSPC response rounded to two decimals. AP's indexed close report and the body of a Reuters-syndicated closing article corroborate it. This is the S&P 500 price index, not SPY, futures or total return. The exact observation close is 2 November 21:00 UTC / 16:00 America/New_York. Yahoo labels daily chart bars with session-open times; those are not close/publication timestamps. Its binary chart number 7541.39990234375 is not used as spurious extra precision: the HTML Close column supplies 7541.40.

Yahoo raw retrieval: {yahoo_meta['retrieved_UTC']}; FT raw retrieval: {ft_meta['retrieved_UTC']}. Both occurred BEFORE the requested cutoff. This contemporaneous capture establishes that a publicly accessible source carried the value by those times. It is not an inference from an after-cutoff download. Exact first publication remains unverified.

AP's search-service article record is dated 2 November 21:21:03 UTC; raw AP access returned 403. Reuters direct access returned 401. Its MarketScreener republication displays original 17:10 GMT and updated 21:42 GMT on 2 November; current body reports the close. The 17:10 time predates market close and CANNOT prove that the closing value was present then. The later update is supportive publication metadata, not a verified first-appearance timestamp; no immutable prior article version was retrieved. Source URLs, raw failures, current retrievals and limitations are in publication_evidence.json and raw_source_manifest.json. Yahoo/FT market “as of” stamps are not treated as first publication.

## Policy finding

No pre-established cross-provider fallback hierarchy was found in the inspected protocol/code. The documented historical supplement was FRED CSV → FRED HTML. Yahoo substitution is therefore a disclosed methodological change requiring human/group approval for live adoption. This request authorizes a separate diagnostic replay; it does not silently revise the standing protocol or assert retrospective approval. Copies and hashes of reviewed policy files are saved. All original blocked evidence remains byte-for-byte unchanged.

## Replay calculations

| Model | Level (2dp) | Full float precision | Intercept | Momentum coefficient | Yield coefficient |
|---|---:|---:|---:|---:|---:|
{rows}

A: F=P. B: F=P(1+0.25m). C: F=P(1+a+bm). D: F=P(1+a+bm+cz). Here m=P[t]/P[t-20]−1 and z=Y[u]−Y[u-5], in percentage points over five nonmissing Treasury intervals. Exact dates/levels: inputs.json. The only added modelling row is the verified 2 November price; raw FRED data remain unchanged. No coefficients or estimation rules were tuned or altered. Both expanding regressions use {len(tc)} matured weekly Friday-origin rows; latest outcome {tc[-1]['target_date']}. The new November 2 price changes the live baseline/momentum, not the Friday training pool.

36 existing test methods reran successfully. Replay-specific future-price/yield poisoning, unmatured-target exclusion, truncated-history checks and independent Decimal forecasts all passed. Full Decimal results are in independent_calculations.csv. Every training target is before cutoff, and the actual captured sources used were retrieved before cutoff. Historical feature vintages/first-publication times remain unverified; numerical tests do not certify those.

## Cause and correction to the earlier interpretation

The frozen FRED endpoints successfully returned responses but lacked November 2 while other publishers carried it. This is evidence of a FRED-feed publication/refresh lag relative to those publishers, not evidence that the official close did not exist. Its exact internal cause (provider ingestion, dissemination or caching) is not observable. The missing-price guard behaved correctly under its locked source policy. However, the prior investigation stopped too early: conflicting broad search snippets were not a sufficient reason to dismiss corroborated dated history rows and article bodies. The workflow also lacked a preapproved alternative-provider route. Python 3.9 versus pinned Python 3.14 was a separate resolved runtime issue, not the cause of the missing price.

## Reproduce / review

From the project root: `/opt/anaconda3/bin/python3.14 research/live_trials/2026-11-03/source_substitution/calculate_replay.py`. Uses saved raw responses, writes a new uniquely named replay, never edits the blocked run. Raw responses are under raw/, modelling datasets under processed/, source extraction and publication evidence are separate JSON records, original-file checks are in blocked_evidence_preservation.csv. SHA256.json and read-only permissions protect this package against accidental overwriting (not owner-resistant WORM storage).

Human review: approve or reject this cross-provider substitution and determine whether to issue a distinct approved live record before noon. Approval cannot retroactively convert a post-noon issue into prospective evidence. No accuracy, November 10 actual, or binding November 13 forecast is generated.
''')
 (out/'AGENT_EXECUTION_LOG.md').write_text('Inspected actual UTC time, existing protocols and blocked evidence. Used web.run for supplied Yahoo/Reuters URLs, AP search and Reuters syndication. Direct urllib raw requests preserved Yahoo HTML/chart and FT; Reuters/AP and syndication errors retained. Inspected exact HTML table rows and chart instrument metadata. Executed calculate_replay.py with the unchanged audited numerical functions and saved sources only. Ran five test suites plus replay-specific independent/adversarial checks. No live issuance function was called; no original source response was edited. Actual retrieval and execution timestamps are in the adjacent JSON records.\n')
 w.seal(out);print(out);print(json.dumps(forecasts,indent=2,default=str))
if __name__=='__main__':main()

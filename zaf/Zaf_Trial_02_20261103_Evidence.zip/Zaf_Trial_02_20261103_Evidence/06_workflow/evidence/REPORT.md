# Trial 2 source-substitution investigation and unissued replay

Completed 2026-11-03T10:15:14.383243+00:00. Intended origin 3 November 2026 12:00 GMT; target official S&P 500 price-index close 10 November 2026 21:00 GMT. This is a separately labelled diagnostic replay, not a replacement or backdated issuance. **It was computed before noon, so it is not yet a late calculation. No live forecast has been formally issued.** If no approved record is actually issued by noon, later calculations must be retrospective regardless of underlying data availability.

## Verified value and publication evidence

The raw Yahoo historical **Close** row for 2 November reads **7,541.40**, independently matching the FT historical row and the Yahoo chart INDEX/^GSPC response rounded to two decimals. AP's indexed close report and the body of a Reuters-syndicated closing article corroborate it. This is the S&P 500 price index, not SPY, futures or total return. The exact observation close is 2 November 21:00 UTC / 16:00 America/New_York. Yahoo labels daily chart bars with session-open times; those are not close/publication timestamps. Its binary chart number 7541.39990234375 is not used as spurious extra precision: the HTML Close column supplies 7541.40.

Yahoo raw retrieval: 2026-11-03T10:12:27.808565+00:00; FT raw retrieval: 2026-11-03T10:12:34.266633+00:00. Both occurred BEFORE the requested cutoff. This contemporaneous capture establishes that a publicly accessible source carried the value by those times. It is not an inference from an after-cutoff download. Exact first publication remains unverified.

AP's search-service article record is dated 2 November 21:21:03 UTC; raw AP access returned 403. Reuters direct access returned 401. Its MarketScreener republication displays original 17:10 GMT and updated 21:42 GMT on 2 November; current body reports the close. The 17:10 time predates market close and CANNOT prove that the closing value was present then. The later update is supportive publication metadata, not a verified first-appearance timestamp; no immutable prior article version was retrieved. Source URLs, raw failures, current retrievals and limitations are in publication_evidence.json and raw_source_manifest.json. Yahoo/FT market “as of” stamps are not treated as first publication.

## Policy finding

No pre-established cross-provider fallback hierarchy was found in the inspected protocol/code. The documented historical supplement was FRED CSV → FRED HTML. Yahoo substitution is therefore a disclosed methodological change requiring human/group approval for live adoption. This request authorizes a separate diagnostic replay; it does not silently revise the standing protocol or assert retrospective approval. Copies and hashes of reviewed policy files are saved. All original blocked evidence remains byte-for-byte unchanged.

## Replay calculations

| Model | Level (2dp) | Full float precision | Intercept | Momentum coefficient | Yield coefficient |
|---|---:|---:|---:|---:|---:|
| A | 7541.40 | 7541.4 | 0.0 | 0.0 | 0.0 |
| B | 7485.00 | 7485.001625621466 | 0.0 | 0.25 | 0.0 |
| C | 7546.43 | 7546.427877612572 | 0.0015511880393786525 | 0.029567571499616106 | 0.0 |
| D | 7560.34 | 7560.341917860437 | 0.0017884990839572338 | 0.025837241161382248 | -0.024935344605322866 |

A: F=P. B: F=P(1+0.25m). C: F=P(1+a+bm). D: F=P(1+a+bm+cz). Here m=P[t]/P[t-20]−1 and z=Y[u]−Y[u-5], in percentage points over five nonmissing Treasury intervals. Exact dates/levels: inputs.json. The only added modelling row is the verified 2 November price; raw FRED data remain unchanged. No coefficients or estimation rules were tuned or altered. Both expanding regressions use 198 matured weekly Friday-origin rows; latest outcome 2026-10-30. The new November 2 price changes the live baseline/momentum, not the Friday training pool.

36 existing test methods reran successfully. Replay-specific future-price/yield poisoning, unmatured-target exclusion, truncated-history checks and independent Decimal forecasts all passed. Full Decimal results are in independent_calculations.csv. Every training target is before cutoff, and the actual captured sources used were retrieved before cutoff. Historical feature vintages/first-publication times remain unverified; numerical tests do not certify those.

## Cause and correction to the earlier interpretation

The frozen FRED endpoints successfully returned responses but lacked November 2 while other publishers carried it. This is evidence of a FRED-feed publication/refresh lag relative to those publishers, not evidence that the official close did not exist. Its exact internal cause (provider ingestion, dissemination or caching) is not observable. The missing-price guard behaved correctly under its locked source policy. However, the prior investigation stopped too early: conflicting broad search snippets were not a sufficient reason to dismiss corroborated dated history rows and article bodies. The workflow also lacked a preapproved alternative-provider route. Python 3.9 versus pinned Python 3.14 was a separate resolved runtime issue, not the cause of the missing price.

## Reproduce / review

From the project root: `/opt/anaconda3/bin/python3.14 research/live_trials/2026-11-03/source_substitution/calculate_replay.py`. Uses saved raw responses, writes a new uniquely named replay, never edits the blocked run. Raw responses are under raw/, modelling datasets under processed/, source extraction and publication evidence are separate JSON records, original-file checks are in blocked_evidence_preservation.csv. SHA256.json and read-only permissions protect this package against accidental overwriting (not owner-resistant WORM storage).

Human review: approve or reject this cross-provider substitution and determine whether to issue a distinct approved live record before noon. Approval cannot retroactively convert a post-noon issue into prospective evidence. No accuracy, November 10 actual, or binding November 13 forecast is generated.

# S&P 500 live forecasting trials — 2026/27

Status at 2 November 2026: one **retrospective, noncertified, unissued replay**; three future trials scheduled but not executed. No binding 13 November forecast. Start with FINDINGS.md, schedule.csv, model_specification_manifest.json and evidence/inspection.json.

The target is the official S&P Dow Jones Indices S&P 500 **price index** close, in index points, excluding dividends. FRED SP500 republishes that index; no ETF, futures or total-return substitute is used. S&P definition: https://www.spglobal.com/spdji/en/indices/equity/sp-500/ . FRED definition and copyright: https://fred.stlouisfed.org/series/SP500 . Treasury series: https://fred.stlouisfed.org/series/DGS10 . Exchange schedule: https://www.nyse.com/markets/hours-calendars . The index definition was verified via web-tool response; direct S&P HTTP retrieval failed with 403 and that failure is retained.

## Evidence and interpretation

Each dated folder has a status record. Executed attempts are under `runs/<actual timestamp>_<mode>/`: unchanged raw responses and metadata, processed data, exchange schedule, model inputs, training ledgers, full-precision and rounded CSV/JSON forecasts, independent checks, validation, execution log and SHA256.json. Original history is in evidence/historical; original_inventory.json hashes all pre-existing non-vendor research files. No Git repository exists; SHA-256 identifies code versions instead. Original research files are untouched. Historical test suites were rerun against the isolated copy because their setup/teardown writes outputs.

The 31 October source snapshots genuinely exist with stored retrieval metadata and matching hashes, but prices end on 28 October in CSV / 29 October on the FRED page. No 30 October baseline or noon-issued forecast was found. Today's post-cutoff downloads support a conditional replay only. FRED's current SP500 page says updated 2 November 10:45 CST (16:45 UTC); that is a page/series update, **not verified first publication of the particular observation**. Observation time, publication proxy, retrieval time, intended origin and actual computation are recorded separately. Local metadata is not independent timestamp notarization.

No record is called point-in-time certified. The model uses the historical market-close assumption and conservative next-federal-business-day yield publication proxy. Unknown historical first-availability times and revisions remain UNVERIFIED. Numerically passing tests does not override this status. A later-downloaded 30 October price is used only in the explicitly noncompliant replay, including its matured training label. Training remains weekly Friday-origin, not daily. The application to Monday–Thursday origins is an explicit requested transfer assumption.

## Run the upcoming trials

From SP500_Coursework, on each named date **before 12:00 GMT**, allow time for retrieval and checking (e.g. start 11:30):

```sh
python3 research/live_trials/src/live_trials.py run --origin 2026-11-03 --mode prospective
python3 research/live_trials/src/live_trials.py run --origin 2026-11-04 --mode prospective
python3 research/live_trials/src/live_trials.py run --origin 2026-11-05 --mode prospective
```

Run only the command corresponding to that day's trial. Internet access is required for fresh raw retrieval. The command rejects a different execution date, execution after noon, a source retrieved after noon, a missing latest expected price, incorrect horizon, or unsupported origin. Completion after noon blocks prospective status. If a source is stale, investigate and save a new attempt; never substitute a newer unavailable value or backdate an earlier attempt. To use an independently downloaded snapshot, `--source PATH` requires sp500.csv, dgs10.csv and their .metadata.json records with URL, SHA256 and actual retrieved_at_utc. Preserve original raw responses. Availability certification still requires evidence, not a timestamp typed by an operator.

The runner prepares research outputs; it does **not** submit coursework or assert human sign-off. The group must review the latest source, source timing, D specification, weekday transfer and limitations before any formal issuance. Store an approval/issuance record separately, naming reviewer, actual approval/issuance UTC, run path and manifest hash, and whether approved only as noncertified research. A post-noon approval cannot create a prospective noon issue. These controls deliberately keep formal issuance pending rather than imply approval. Unknown availability cannot be repaired by approval.

If noon was missed, run with `--mode replay` after cutoff. Every run receives a new directory. Never edit an existing run; save corrections in a separate run and explain the supersession in a separate record. No automated future execution has been scheduled; a group member must run these commands.

## Evaluate only after genuine publication

On or after 9, 10, 11 and 12 November respectively, retrieve a new FRED SP500 CSV with its real UTC retrieval timestamp, exact URL and SHA256 metadata (the same downloader is available as `retrieve` in the Python module). Do not use a prefilled/manual future actual. Run:

```sh
python3 research/live_trials/src/live_trials.py score --run research/live_trials/DATE/runs/RUN_ID --evidence PATH_TO_NEW/sp500.csv
```

Scoring rejects a target not yet due, an invalid retrieval time, wrong source endpoint, missing target observation or checksum mismatch. The target observation must actually be present in the response; reaching 21:00 alone is insufficient. FRED delay may require waiting. Human review must confirm this is the official price-index close and record corrections separately if the provider revises it. Scoring uses the two-decimal forecast submitted for review: APE = 100 abs(F−actual)/actual; deduction = min(50,5 APE); score = 50−deduction (unrounded internally). Historical summaries average individually rounded scores; this small convention difference is disclosed. Evaluations are separate immutable directories and never modify forecasts.

Set each selected run and evaluation path in selected_runs.json, preserving a copy of the old selection if changing it. Never pick a rerun based on its outcome. Run `python3 research/live_trials/src/compare.py` to create a new timestamped comparison snapshot. It reports trial APE, mean/median/max APE, ties credited as wins, average score and paired difference versus A; replay and prospective results are separate. All actuals and performance summaries remain blank until scores exist. Four overlapping trials cannot establish statistical superiority.

## Reproduce and verify

```sh
python3 research/live_trials/src/test_live.py
PYTHONPATH="$PWD/research/vendor" python3 research/live_trials/evidence/historical/src/test_backtest.py
PYTHONPATH="$PWD/research/vendor" python3 research/live_trials/evidence/historical/src/test_point_in_time.py
PYTHONPATH="$PWD/research/vendor" python3 research/live_trials/evidence/historical/treasury_extension/test_extension.py
```

The original replay command and source path are recorded in agent_execution_log.md and the run log. Recompute it into a new run using `--mode replay --source research/live_trials/sources/network_retry`. Existing local research/vendor dependencies are reused; versions are in evidence/historical/requirements.txt. The portable evidence archive includes these dependencies and does not require an AI account (compiled dependencies may require a matching Python/platform; otherwise install the pinned requirements). No credentials are included.

SHA256.json files and the hash-linked evidence_register.jsonl provide tamper detection, **not** a cryptographic signature, external timestamp or operating-system-enforced immutability. Preserve the archive and its externally stored checksum. A full account transcript is not exported; the package contains actual runner arguments, source-request metadata, saved tool response and a factual tool execution summary.

```mermaid
flowchart LR
 G[Research goal] --> R[Data retrieval]
 R --> S[Source checks]
 S --> C[Calculation tools]
 C --> F[Model forecasts]
 F --> V[Independent validation]
 V --> H[Human approval — pending]
 H --> O[Frozen issued output]
 S --> U[Unknown availability: label noncertified]
 V --> E[Freeze unissued evidence now]
```

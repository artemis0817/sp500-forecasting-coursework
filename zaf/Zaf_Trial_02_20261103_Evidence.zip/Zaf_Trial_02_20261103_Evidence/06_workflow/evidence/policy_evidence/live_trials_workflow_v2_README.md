# Automated trial workflow, version 2

This supersedes the old CLI procedure for new runs; old forecasts, code and archives are preserved. Model parameters and fit functions remain unchanged. Entry point from SP500_Coursework:

```sh
python3 run_live_trial.py --date 2026-11-03
```

Run this on **3 November 2026, before 12:00 GMT**, preferably around 11:30 to allow downloads and validation. It targets the official S&P 500 **price-index close on 10 November 2026 at 21:00 GMT** (16:00 America/New_York). The same command accepts 4 or 5 November for their scheduled targets. Four dated trial directories already exist. No future trial has been executed, and no operating-system or Codex scheduler has been installed. This command automates retrieval, calculations, verification, local research issuance and evidence preservation once invoked.

To test without issuing anything:

```sh
python3 run_live_trial.py --date 2026-11-02 --dry-run
```

For offline reproduction, add `--source /absolute/path/to/a/completed/dry_run/raw`. Offline input is permitted only in dry-run mode. A future date is rejected; the binding 13 November forecast is disabled. Actuals and later scores are not populated by this workflow.

## Timing and availability

Every attempt gets a unique directory under DATE/workflow_v2_runs. Fresh raw CSV and HTML responses are saved unchanged with actual retrieval UTC and Europe/London timestamps. The source manifest records instrument, dataset, exact endpoint, raw SHA-256, latest observation, per-model last-used observation, reporting lag and unresolved publication assumptions. The Treasury source supplies dates, not verified intraday observation times: these fields remain null rather than invented. A scheduled equity close is labelled as such, not as FRED publication time. HTTP Last-Modified is retained only as a response header, never promoted to first-availability evidence.

Before fitting, source hashes and timestamp ordering are checked; inputs and every training label are checked against XNYS and the information cutoff. Live execution requires fresh retrieval completed before noon. Retrieval establishes that the exact snapshot bytes were observed by that time; it does **not** establish first publication or historical vintage values at earlier training origins. The previously audited Friday-training and yield-release proxies remain explicitly unverified. This is reflected in `prospective_issued_historical_vintages_unverified`, never a claim of fully certified vintage research. A dry-run may calculate a retrospective diagnostic despite failing the current snapshot's historical-cutoff check, but its preforecast_checks.json records the failure and it cannot be issued.

`status.json` is the authoritative combined timing decision. Prospective status requires all four recorded completions—retrieval, calculation, verification and the fsynced issuance-record write—to be no later than noon. If issuance is attempted just before noon but its write finishes after noon, status is `late_not_prospective`; the pre-write timestamp cannot override the actual completion. `issuance.json` records the local research issuance attempt and forecast checksum. Dry runs always record `issued: false`. Institutional approval and coursework submission are not asserted or automated. Unknown historical publication/vintage evidence remains a limitation even for an on-time local issue.

## Models and safeguards

A uses the latest eligible official close. B uses the fixed coefficient 0.25 times the 20-session return. C reuses audited expanding OLS with an intercept and momentum. D reuses audited expanding OLS with momentum and the five nonmissing Treasury-observation interval change, in percentage points. Both retain a minimum of 52 matured six-session Friday-origin observations. No model selection or parameter tuning is performed. D was exploratory in the historical research; the requested four-model trial does not imply it was previously selected for binding submission. Weekday live origins use the previously documented transfer from Friday training.

Validation reuses the existing Decimal OLS checks, future-price/yield poisoning, truncated-history and unmatured-target checks. Missing latest expected prices fail, and missing required D inputs prevent complete issuance. Cleaned datasets and full training rows are separate from raw data. Each folder includes code copies/checksums, model inputs, coefficients, precision-preserving JSON and rounded CSV, independent checks, validation, logs, stage timestamps and reproduction instructions.

All JSON/CSV evidence writes use exclusive creation. Completed and failed attempts are sealed with a SHA-256 manifest, then made read-only (files 0444, directories 0555). A locked append-only register links each manifest hash to prior register contents. These are application/OS permission controls and tamper detection, not WORM storage or independent timestamp notarization: the file owner can deliberately restore write permission. Never edit an issued directory. Run corrections separately and store evaluation outputs outside it. Do not overwrite or reinterpret the original issuance.

## Dependencies and permissions

Python 3 with the project's existing research/vendor packages is used automatically. Exact dependencies are preserved in ../evidence/historical/requirements.txt; this machine uses the already installed compatible Python runtime. On another platform, install those dependencies into a compatible environment. Network access to HTTPS fred.stlouisfed.org and write permission to research/live_trials are required. In Codex's restricted shell the initial DNS attempt may fail; permit the public-source network retry when required. No API key, credentials, AI account or paid data endpoint is required. No secrets are written to the evidence.

Tests:

```sh
python3 research/live_trials/workflow_v2/test_workflow.py
python3 research/live_trials/src/test_live.py
python3 research/live_trials/workflow_v2/verify_runs.py
```

The prior 22 historical tests were rerun in an isolated copy and their new logs are retained under historical_tests/. The original research and earlier sealed runs are unchanged. CHECKLIST.md and checklist.json list the exact successful dry-run paths, checksums and permissions; failures.json lists the retained unsuccessful attempt.

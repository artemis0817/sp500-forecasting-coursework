# Proposed fallback-source hierarchy — group approval required

Status: PROPOSED / NOT ACTIVE for future trials. Prepared 3 November 2026. The user's approval of Yahoo's 2 November close applies to Trial 2 only. It does not approve this future policy or change any model formula, training rule, factor, calendar or lag.

## S&P 500 price-index closing level

1. Primary: established FRED SP500 CSV, sourced from S&P Dow Jones Indices. Verify expected session, daily close, unit and gaps.
2. Same-provider fallback: saved FRED SP500 series page if the CSV lags. Require an explicitly dated value; reject discrepancies between same-date values pending resolution.
3. Cross-provider fallback, only if the group approves this policy: a directly retrievable S&P Dow Jones Indices official price-index daily-close record; otherwise Yahoo Finance ^GSPC historical **Close** column. Use the price index, not SPY, futures, total return or adjusted-close data. Treat API binary floating-point representation as corroboration, not extra precision beyond the documented index close.
4. Independently corroborate a cross-provider close with a dated Reuters/AP closing article body or an FT historical daily-close row. A dynamic quote widget, search snippet alone, or unexplained conflicting values is insufficient. Shared data feeds are not necessarily independent price formation; disclose provider relationships where known.
5. If no unambiguous dated close and corroboration can be retrieved by the deadline, block issuance rather than silently use a stale session or invent a value. Escalate any conflict to a human.

## Treasury yields

Keep FRED DGS10 and the audited conservative next-federal-business-day 16:15 America/New_York publication proxy, including the existing holiday convention. No automatic Treasury source substitution is approved by this proposal. Substitution to Federal Reserve H.15 requires a separate documented group decision confirming identical instrument, unit and observation alignment. Never select a newer observation solely because a later download contains it.

## Operational and provenance requirements

- Preserve every raw response unchanged, including error records. Use a new snapshot folder for every request/attempt, with exact requested/resolved URL, dataset ID, retrieval start/completion UTC and Europe/London, response headers stripped of credentials, SHA-256, latest observation, observation actually used and source limitations.
- Separate scheduled market close, daily-bar label, quote update, original article publication, article modification, first availability and retrieval times. Record null when unknown. A live pre-cutoff retrieval demonstrates an observed-by bound; it does not establish exact first publication. An after-cutoff retrieval does not prove historical availability without appropriate evidence.
- Restrict a supplement to the missing, verified observation; never replace historical training data wholesale. Save a processed dataset and row-level source ledger. Compare overlapping values and investigate discrepancies.
- Record the approved substitution before issuance, with approver, approval-recording time, selected source/value, rationale and hashes. Preserve the primary-source failure and original calculation/blocked record.
- Re-run independent numerical, calendar, maturity, poisoning, truncated-history and integrity checks. All essential steps, approval, actual issuance and evidence freezing must finish by the scheduled cutoff for prospective status. Late approval cannot backdate a forecast.
- Freeze issued evidence with an exclusive-create record, manifest, read-only files and append-only register. Save corrections/evaluations separately; never silently revise an issued forecast.
- Record actual computation and issuance times even when earlier than noon. Do not claim to include information that arrived after an early issue.

## Approval register (currently empty)

Group approver(s): pending. Approval timestamp: pending. Effective trial/date: pending. Adopted version/hash: pending. Until approved, cross-provider fallback for each future trial requires an explicit case-specific human decision.

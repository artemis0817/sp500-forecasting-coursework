"""Issue previously validated Trial 2 values following explicit user approval; no refitting."""
from pathlib import Path
import sys,json,os,shutil,csv
from decimal import Decimal
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'src'),str(ROOT/'workflow_v2')]
import live_trials as l
import workflow as w

def main():
 started=l.now();cut=l.noon(l.date(2026,11,3));trial=ROOT/'2026-11-03';replay=trial/'source_substitution/replays/20261103T101500939911Z'
 # Reject duplicate formal issuance. Corrections must be implemented as separate explicit actions.
 issues=trial/'issued';issues.mkdir(exist_ok=True)
 if list(issues.glob('*/issuance.json')):raise ValueError('An issuance exists; refusing duplicate issue')
 out=issues/started.strftime('%Y%m%dT%H%M%S%fZ');out.mkdir()
 approval={'scope':'Trial 2 only: Yahoo ^GSPC historical Close 7541.40 for 2026-11-02 and issuance of the existing validated four forecasts','approval_text':'I approve the use of the verified Yahoo Finance S&P 500 historical closing level of 7,541.40 for 2 November 2026 as a fallback source for Trial 2, subject to documenting the source-substitution decision and remaining publication-time limitations. Please formally issue and freeze the four Trial 2 forecasts for the 10 November 2026 official S&P 500 closing level, using the existing validated replay calculations.','approver':'user in this chat; personal identity not independently authenticated','approval_recorded_UTC':l.now().isoformat(),'approval_recorded_Europe_London':l.now().astimezone(l.LON).isoformat(),'original_message_sent_timestamp':None,'timestamp_limitation':'Platform message timestamp not exposed. This is the actual time approval was recorded by the agent, not a fabricated user-send time.','future_hierarchy_group_approval':False}
 # Use one instant for UTC/London views of the same recorded approval.
 approval['approval_recorded_Europe_London']=l.datetime.fromisoformat(approval['approval_recorded_UTC']).astimezone(l.LON).isoformat();w.save(out/'approval.json',approval)
 protected=[p for folder in [trial/'workflow_v2_runs',trial/'validation_attempts',replay] for p in folder.rglob('*') if p.is_file()];before={str(p):l.sha(p) for p in protected}
 for rel,h in json.loads((replay/'SHA256.json').read_text()).items():assert l.sha(replay/rel)==h
 for path,h in json.loads((replay/'code_versions.json').read_text()).items():assert l.sha(Path(path))==h
 fs=json.loads((replay/'forecasts.json').read_text());assert [f['model'] for f in fs]==list('ABCD')
 independent={r['model']:r for r in l.rows(replay/'independent_calculations.csv')}
 for f in fs:
  d=Decimal(independent[f['model']]['decimal_forecast']);assert str(d.quantize(Decimal('.01')))==f['forecast_level'];assert abs(d-Decimal(str(f['forecast_full_precision'])))<Decimal('1e-8')
 for result in json.loads((replay/'test_results.json').read_text()):assert result['exit_code']==0
 v=json.loads((replay/'validation.json').read_text())
 for key in ['future_price_and_yield_poison','truncated_history','unmatured_target','six_sessions']:assert v[key]=='PASS'
 replay_status=json.loads((replay/'status.json').read_text());calc_end=l.datetime.fromisoformat(replay_status['calculation_and_validation_completed_UTC'])
 retrieved=[]
 for m in json.loads((replay/'raw_source_manifest.json').read_text()):
  if m['raw_present']:
   assert l.sha(replay/m['raw_path'])==m['sha256'];retrieved.append(l.datetime.fromisoformat(m['retrieved_UTC']))
 shutil.copytree(replay,out/'validated_replay_evidence')
 # Copies remain byte-identical, including their original 'unissued replay' provenance.
 for rel,h in json.loads((replay/'SHA256.json').read_text()).items():assert l.sha(out/'validated_replay_evidence'/rel)==h
 policy=ROOT/'policies/fallback_source_hierarchy_PROPOSED_2026-11-03.md';shutil.copy2(policy,out/policy.name)
 sources=json.loads((replay/'raw_source_manifest.json').read_text())
 for s in sources:s['raw_path']='validated_replay_evidence/'+s['raw_path']
 w.save(out/'source_manifest.json',sources)
 for name in ['inputs.json','code_versions.json','validation.json','independent_calculations.csv','publication_evidence.json']:
  shutil.copy2(replay/name,out/name)
 verification=l.now();issue_stamp=l.now()
 levels=[]
 for f in fs:
  row=dict(f);row.update(status='FORMALLY_ISSUED_USER_APPROVED',formally_issued=True,actual_issuance_UTC=issue_stamp.isoformat(),approval_recorded_UTC=approval['approval_recorded_UTC'],approved_source_substitution='Yahoo Finance ^GSPC historical Close 7541.40, 2026-11-02; user-approved for Trial 2 only',original_replay_forecast_sha256=l.sha(replay/'forecasts.json'),calculation_values_unchanged=True)
  levels.append(row)
 w.save(out/'forecasts.json',levels);w.table(out/'forecasts.csv',levels)
 # These are the fixed reviewed forecasts, not a newly generated set.
 assert all(a['forecast_full_precision']==b['forecast_full_precision'] and a['forecast_level']==b['forecast_level'] for a,b in zip(fs,levels))
 w.save(out/'issuance.json',{'actual_issuance_UTC':issue_stamp.isoformat(),'actual_issuance_Europe_London':issue_stamp.astimezone(l.LON).isoformat(),'intended_origin_UTC':cut.isoformat(),'target_UTC':'2026-11-10T21:00:00+00:00','issued':True,'status_authority':'Separate completion receipt determines prospective vs late after evidence freezing finishes','scope':'formal local Trial 2 research forecast; no external coursework submission performed','approval_record': 'approval.json','forecasts_sha256':l.sha(out/'forecasts.json'),'original_replay':str(replay),'original_replay_manifest_sha256':l.sha(replay/'SHA256.json'),'no_model_recalculation':True,'historical_publication_vintages_certified':False})
 preservation=[{'path':p,'before_sha256':h,'after_sha256':l.sha(Path(p)),'unchanged':l.sha(Path(p))==h} for p,h in before.items()];assert all(r['unchanged'] for r in preservation);w.table(out/'prior_evidence_preservation.csv',preservation)
 w.save(out/'preissue_validation.json',{'checked_UTC':verification,'existing_36_test_methods_passed':True,'replay_specific_independent_leakage_checks_passed':True,'source_and_code_hashes_match':True,'copied_evidence_hashes_match':True,'issued_levels_match_validated_values_exactly':True,'approval_recorded_UTC':approval['approval_recorded_UTC'],'original_calculation_and_validation_completed_UTC':calc_end.isoformat(),'latest_successful_source_retrieval_UTC':max(retrieved).isoformat(),'models_reestimated':False})
 shutil.copy2(__file__,out/'issue_trial2_approved.py')
 (out/'README.md').write_text('''# Formally issued Trial 2 forecasts

This is a new user-approved issuance of the exact validated calculation values. The original blocked attempt and source-substitution replay remain unchanged. The copied validated_replay_evidence retains its original unissued labels as provenance; forecasts.json and issuance.json at this directory's root are the newly issued record.

The authoritative timing classification is in the separate completion receipt under ../receipts/. It checks approval, successful source retrieval, original calculation/validation, preissue verification, actual issuance write and completed evidence freezing against 3 November 2026 12:00 GMT. The intended origin is noon; actual issuance time is separately recorded and must not be described as exactly noon. This issue does not claim knowledge of information arriving after its actual issue time.

Target: official S&P 500 price-index close on 10 November 2026, 21:00 GMT. No target actual or accuracy is entered.

Source substitution: user approved Yahoo Finance ^GSPC historical Close 7541.40 for 2 November. Raw Yahoo HTML/chart, FT corroboration, FRED historical prices and DGS10 yields are copied unchanged in validated_replay_evidence/raw. Exact URLs, UTC/London retrievals and hashes appear in source_manifest.json. Publication evidence and source errors remain documented. Actual pre-cutoff retrieval proves an observed-by bound, not exact first publication. Reuters original access failed; syndicated publication/update dates and AP indexed timestamps are not immutable historical snapshots. Historical model-input vintages remain uncertified.

Approval timestamp is when the agent recorded the user's explicit approval. The platform did not expose the original message-send timestamp, which remains null. No identity, timestamp or external submission has been invented.

The proposed future fallback hierarchy is included but is NOT ACTIVE: group approval and an effective trial/date are pending. Trial 2 approval does not extend automatically to future trials. No standing model parameters, training rules or source whitelist were changed.

To verify: hash every file named in SHA256.json and compare; inspect the completion receipt's reference to this manifest. Files are read-only and writes are exclusive-create; the local owner can deliberately reverse permissions, so this is not WORM storage or independent timestamp notarization. Never overwrite this record. Corrections and later evaluations must be separate and explicitly linked.

For offline numerical reproduction, follow validated_replay_evidence/REPORT.md using saved inputs and Python 3.14. Do not rerun the issuance script: it deliberately rejects a duplicate issuance. The supplied independent calculations already confirm the two-decimal issue values.
''')
 (out/'AGENT_ISSUANCE_LOG.md').write_text('Read actual UTC time (10:19:39 on 3 November) and validated replay status/code/test records. Recorded explicit user approval with actual agent-recording time; original platform message time unavailable. Executed issue_trial2_approved.py using existing Python 3.14. Verified all copied evidence hashes, recorded code hashes, prior test results and independent Decimal comparisons without refitting or downloading new observations. Created new formal forecast/issuance records and proposed future policy, then froze them. No blocked/replay file was edited. No future target scoring or November 13 forecast executed.\n')
 issue_write_completed=l.now();w.seal(out);freeze_completed=l.now()
 events={'approval_recorded':approval['approval_recorded_UTC'],'latest_source_retrieved':max(retrieved).isoformat(),'calculation_validation_completed':calc_end.isoformat(),'preissue_verification_completed':verification.isoformat(),'actual_issuance':issue_stamp.isoformat(),'issuance_files_completed':issue_write_completed.isoformat(),'evidence_freeze_completed':freeze_completed.isoformat()}
 timing='PROSPECTIVE_ISSUED_BEFORE_NOON_WITH_APPROVED_SOURCE_SUBSTITUTION' if all(l.datetime.fromisoformat(t)<=cut for t in events.values()) else 'LATE_APPROVED_RETROSPECTIVE_REPLAY'
 receipt_dir=issues/'receipts'/out.name;receipt_dir.mkdir(parents=True)
 w.save(receipt_dir/'completion.json',{'classification':timing,'events_UTC':events,'cutoff_UTC':cut.isoformat(),'target_UTC':'2026-11-10T21:00:00+00:00','issued_directory':str(out),'issued_manifest_sha256':l.sha(out/'SHA256.json'),'approval_message_timestamp_limitation':approval['timestamp_limitation'],'first_publication_and_historical_vintages':'not certified','future_fallback_policy':'PROPOSED_NOT_GROUP_APPROVED','receipt_recorded_UTC':l.now().isoformat()});w.seal(receipt_dir)
 # Post-freeze verification includes the receipt. If crossing the cutoff, append an overriding late notice, never edit sealed records.
 for folder in [out,receipt_dir]:
  for rel,h in json.loads((folder/'SHA256.json').read_text()).items():assert l.sha(folder/rel)==h
 end=l.now()
 if end>cut and timing.startswith('PROSPECTIVE'):
  late=issues/'receipts'/(out.name+'_late_completion_override');late.mkdir();w.save(late/'completion.json',{'classification':'LATE_APPROVED_RETROSPECTIVE_REPLAY','reason':'Final receipt or post-freeze integrity check completed after cutoff','actual_completion_UTC':end.isoformat(),'supersedes_classification_only':str(receipt_dir/'completion.json')});w.seal(late);timing='LATE_APPROVED_RETROSPECTIVE_REPLAY'
 print(json.dumps({'status':timing,'issued_directory':str(out),'receipt':str(receipt_dir/'completion.json'),'final_verified_UTC':end.isoformat(),'forecasts':{f['model']:f['forecast_level'] for f in levels}},indent=2))
if __name__=='__main__':main()

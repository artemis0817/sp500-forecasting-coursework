# Formally issued Trial 2 forecasts

This is a new user-approved issuance of the exact validated calculation values. The original blocked attempt and source-substitution replay remain unchanged. The copied validated_replay_evidence retains its original unissued labels as provenance; forecasts.json and issuance.json at this directory's root are the newly issued record.

The authoritative timing classification is in the separate completion receipt under ../receipts/. It checks approval, successful source retrieval, original calculation/validation, preissue verification, actual issuance write and completed evidence freezing against 3 November 2026 12:00 GMT. The intended origin is noon; actual issuance time is separately recorded and must not be described as exactly noon. This issue does not claim knowledge of information arriving after its actual issue time.

Target: official S&P 500 price-index close on 10 November 2026, 21:00 GMT. No target actual or accuracy is entered.

Source substitution: user approved Yahoo Finance ^GSPC historical Close 7541.40 for 2 November. Raw Yahoo HTML/chart, FT corroboration, FRED historical prices and DGS10 yields are copied unchanged in validated_replay_evidence/raw. Exact URLs, UTC/London retrievals and hashes appear in source_manifest.json. Publication evidence and source errors remain documented. Actual pre-cutoff retrieval proves an observed-by bound, not exact first publication. Reuters original access failed; syndicated publication/update dates and AP indexed timestamps are not immutable historical snapshots. Historical model-input vintages remain uncertified.

Approval timestamp is when the agent recorded the user's explicit approval. The platform did not expose the original message-send timestamp, which remains null. No identity, timestamp or external submission has been invented.

The proposed future fallback hierarchy is included but is NOT ACTIVE: group approval and an effective trial/date are pending. Trial 2 approval does not extend automatically to future trials. No standing model parameters, training rules or source whitelist were changed.

To verify: hash every file named in SHA256.json and compare; inspect the completion receipt's reference to this manifest. Files are read-only and writes are exclusive-create; the local owner can deliberately reverse permissions, so this is not WORM storage or independent timestamp notarization. Never overwrite this record. Corrections and later evaluations must be separate and explicitly linked.

For offline numerical reproduction, follow validated_replay_evidence/REPORT.md using saved inputs and Python 3.14. Do not rerun the issuance script: it deliberately rejects a duplicate issuance. The supplied independent calculations already confirm the two-decimal issue values.

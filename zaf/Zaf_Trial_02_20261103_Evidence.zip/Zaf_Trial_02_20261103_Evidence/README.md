# Zaf Trial 2 frozen evidence sharing package

Information cutoff: 2026-11-03T12:00:00Z. Target: 2026-11-10T21:00:00Z. Original issuance: 2026-11-03T10:21:31.820164Z.

**Prospective before-noon issuance; approved one-row Yahoo substitution**. This folder was packaged on 2026-11-12, not at the original forecast time. Original snapshots, forecasts and timings are preserved; packaging is not a new forecast or issuance.

## Folder guide

- 01_raw: unchanged source payloads and captured metadata, including URLs, retrieval timestamps and availability evidence. FRED supplies historical SP500 and DGS10; Trials 2–4 add exactly one approved Yahoo daily Close corroborated by FT.
- 02_inputs: saved modelling inputs, price/yield data where originally saved, and C/D training ledgers. The offline verifier reconstructs eligible prices directly from the original raw snapshots.
- 03_models: A–D frozen coefficients and specifications. A is unchanged price; B is fixed 0.25 times 20-session simple momentum; C is expanding momentum OLS; D adds lagged five-observation Treasury-yield change. C/D use 198 matured Friday-origin six-session training rows.
- 04_forecasts: original full-precision and two-decimal forecast records. Candidate and issued versions remain separately labelled.
- 05_checks: original saved validation evidence and the new offline reproduction result.
- 06_workflow: approval, issuance, source decisions, logs and byte-identical shared model code. COPY_PROVENANCE.json identifies originals and any prior personal-path redactions in sharing metadata.

## Reproduce offline

Use Python 3.14 and install the pinned dependencies in requirements.txt in a virtual environment. Then, from this extracted folder:

```
python -m pip install -r requirements.txt
python reproduce.py
```

The verification command uses only these packaged raw inputs and code. It reconstructs factors, re-estimates solely on the unchanged historical training data as a reproduction check, compares frozen coefficients and all four forecasts, and runs independent Decimal and look-ahead tests. It does not fetch prices, retune methodology or issue forecasts. Dependency installation may need internet; verification itself does not need an AI account, API key or network. Our verification used the project's installed pinned environment, not a fresh pip installation. Original historical entry scripts are evidence and may require their original folder layout; use reproduce.py for this portable copy.

## Limitations

Exact first publication and historical value vintages remain unverified. Trial 1 is retrospective. Trial 2 was issued before noon. Trials 3–4 were deliberately issued after noon from pre-noon captures, late under the initial issuance rule. Original manifests may reference excluded historical-project copies or original paths; SHA256.json governs this curated package. Sharing metadata with redacted personal paths is a derivative, clearly traced in COPY_PROVENANCE.json. Raw price/yield snapshots and model code remain unchanged. Local hashes are not external notarisation. Source rights still apply; this is coursework sharing evidence, not a licence for public redistribution.

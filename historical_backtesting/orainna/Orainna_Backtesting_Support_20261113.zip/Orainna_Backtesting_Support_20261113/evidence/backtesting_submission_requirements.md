# Shared GitHub backtesting instructions inspected on 13 November 2026

Repository page: https://github.com/artemis0817/sp500-forecasting-coursework/tree/main/historical_backtesting

The shared README asks each member to use their own folder, such as `zaf/`, `artemis/`, or `orainna/`. It asks for a readable README, scripts, input snapshots, results and checksums; for larger evidence, a ZIP plus readable summary and checksum is acceptable. It asks contributors to state exact feature/return formulas, fitted versus fixed coefficients, expanding/rolling rules, training weekdays, target horizons, label-maturity gates, sources and availability caveats, forecast/error tables and independent checks. Frozen runs should not be overwritten; corrections should be saved as a new dated version.

This package follows those requirements for the saved two-model Orainna interim backtest. It labels the log-return OLS separately from report C(i)'s simple-return OLS.

# Interim run log

Run date: 31 October 2026, London time. This is an interim research run, not the 13 November final run.

Commands run from the project root:

```text
python3 --version
python3 sp500_coursework/src/run_validation.py
python3 sp500_coursework/evidence/independent_check.py
```

Observed environment: Python 3.9.6; macOS 26.6 arm64. The validation used the saved `^GSPC` JSON snapshot, not a live query. It produced 142 out-of-sample weekly Friday origins at 12:00 Europe/London from 9 February 2024 through 23 October 2026, after a minimum of 52 training origins. For the latest origin, London had not yet changed from BST, so its timestamp is 11:00 UTC.

Observed metrics:

| Model | MAPE | Mean signed percentage error | Mean absolute point error |
| --- | ---: | ---: | ---: |
| Unchanged-price benchmark | 1.6062% | −0.2849% | 100.2670 points |
| Expanding-window momentum-only OLS | 1.5845% | +0.1618% | 98.7263 points |

The MAPE difference is approximately 0.0217 percentage points in this interim sample. It is small and is not evidence by itself that the momentum model will generalize. The G model was not run because point-in-time Dst vintages are unverified. The independent arithmetic check is retained in `independent_check.md`. A separate close-value cross-check for 30 October is recorded in `source_check.md`.

# Source and timing check (interim, 31 October 2026)

## S&P 500 price index

- Coursework target/reference definition: official S&P 500 **price-index** closing level on 20 November 2026. See the [S&P Dow Jones Indices S&P 500 page](https://www.spglobal.com/spdji/en/indices/equity/sp-500/).
- Research series saved here: Yahoo Finance chart endpoint for symbol `^GSPC`, which is a third-party S&P 500 price-index observation series, not an ETF or total-return index.
- Snapshot retrieval time: see `data/raw/sp500_yahoo_manifest.json` (UTC).
- Saved interval: 1 January 2023 through 30 October 2026; the last usable close is 7,580.0698 points on 30 October 2026.
- Exact vendor publication timestamp: Yahoo's saved chart response does not provide it. Its daily chart timestamp is a session label (the last timestamp appears at 09:30 New York time), not a verified close-publication timestamp. For historical validation, the script conservatively treats a session close as available at 16:00 America/New_York on its session date. That is an exchange-close availability assumption, not a verified Yahoo publication time.
- Independent one-day cross-check: an Associated Press report published 30 October 2026 at 20:21:11 UTC reports the S&P 500 closed at 7,580.07, down 140.32 points (1.8%); this agrees with the Yahoo close rounded to two decimals. This checks one observation, not the whole series and not the official coursework scoring source. [AP market close report](https://apnews.com/article/wall-street-stocks-dow-nasdaq-a01d3551e794fed1a0c317c20bc3f0a2).
- Cross-check final input values and the scoring reference against S&P DJI before the final run.
- The source is suitable for an interim reproducible calculation only with this limitation disclosed. Do not treat Yahoo as the official grading source.

## Dst event candidate

- Official data center: Kyoto World Data Center for Geomagnetism, [Dst index service](https://wdc.kugi.kyoto-u.ac.jp/dstdir/index.html).
- The saved file `data/raw/kyoto_dst_quicklook_2026-10.html` is the Quicklook page retrieved on 31 October; its retrieval time is in the adjacent manifest. It is a contemporaneous snapshot, not a historical archive of what was shown at all past model origins.
- Kyoto's [version documentation](https://wdc.kugi.kyoto-u.ac.jp/wdc/pdf/AEDst_version_def_v2.pdf) says real-time Dst is computed every 30 minutes, can contain uncorrected noise and baseline offsets, can be modified, and is approved for monitoring rather than scientific analysis. Provisional Dst is quality-corrected but generally published with a lag of several months.
- Kyoto's September 2026 provisional table was updated on 19 October 2026, illustrating that provisional observations are not available in real time. See [the dated table](https://wdc.kugi.kyoto-u.ac.jp/dst_provisional/202609/index.html).
- **Availability decision:** current Dst can be inspected, but point-in-time Dst vintages for the historical backtest origins have not been established. A backtest using today's revised provisional/final history would risk look-ahead. Do not fit or score G until vintage evidence is found.

## Retrieval record

The two raw snapshots and manifests are retained under `data/raw/`. Retrieval time is not the same as source publication time. No Dst or S&P point-in-time publication time is invented in this record.

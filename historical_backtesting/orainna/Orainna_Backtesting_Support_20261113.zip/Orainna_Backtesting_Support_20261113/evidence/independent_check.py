#!/usr/bin/env python3
"""Independent one-row arithmetic check using the frozen chart JSON."""

import csv
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
source = json.loads(
    (ROOT / "data/raw/sp500_yahoo_chart_2023-01-01_to_2026-10-31.json").read_text()
)["chart"]["result"][0]
zone = ZoneInfo(source["meta"]["exchangeTimezoneName"])
observations = []
for timestamp, close in zip(source["timestamp"], source["indicators"]["quote"][0]["close"]):
    if close is not None:
        session = datetime.fromtimestamp(timestamp, timezone.utc).astimezone(zone).date().isoformat()
        observations.append((session, float(close)))
by_date = dict(observations)
with (ROOT / "evidence/validation_origins.csv").open() as handle:
    row = list(csv.DictReader(handle))[-1]

index = next(i for i, (session, _) in enumerate(observations) if session == row["p0_date"])
p0 = by_date[row["p0_date"]]
p_minus_20 = observations[index - 20][1]
actual = by_date[row["target_date"]]
momentum = math.log(p0 / p_minus_20)
realized_return = math.log(actual / p0)
forecast = p0 * math.exp(
    float(row["intercept"]) + float(row["momentum_coefficient"]) * momentum
)
ape = 100 * abs(forecast - actual) / actual

print("Origin:", row["origin"], "Target close date:", row["target_date"])
print(f"P0={p0:.8f}; P-20={p_minus_20:.8f}; actual={actual:.8f}")
print(f"M=ln(P0/P-20)={momentum:.10f}; saved M={float(row['momentum']):.10f}")
print(f"realized log return={realized_return:.10f}; saved={float(row['target_log_return']):.10f}")
print(f"recomputed forecast={forecast:.8f}; saved={float(row['momentum_forecast']):.8f}")
print(f"recomputed APE={ape:.10f}%")

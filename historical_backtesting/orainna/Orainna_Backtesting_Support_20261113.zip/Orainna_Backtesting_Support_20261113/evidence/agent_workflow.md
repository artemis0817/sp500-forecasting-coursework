# Labelled agent workflow

```mermaid
flowchart LR
  A[Goal and cutoff: predict S&P 500 close, target 20 Nov 2026 21:00 London; freeze inputs 13 Nov 12:00] --> B[Inspect dated source snapshots and record source / retrieval / publication times]
  B --> C[Python: construct 20-session momentum and target log return]
  C --> D[Python: expanding time-ordered fit and 7d 9h backtest]
  D --> E[Compare unchanged-price benchmark and momentum candidate]
  E --> F[Agent recommendation: G excluded pending point-in-time Dst vintages]
  F --> G[Independent arithmetic and timestamp checks]
  G --> H[Human group reviews evidence and approves one binding forecast]
```

The diagram records the intended workflow. The final cutoff run, final forecast, and group approval have not happened yet and are not represented as completed.

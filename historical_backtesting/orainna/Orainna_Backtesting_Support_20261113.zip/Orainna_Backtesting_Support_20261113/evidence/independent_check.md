# Independent calculation check

This was a separate calculation path, not a fabricated correction. It reads the frozen Yahoo JSON directly, selects the final evaluated origin, recomputes the 20-session momentum, realized log return, exponential forecast, and absolute percentage error, and compares them with `validation_origins.csv`.

Reproduce from the project root:

```sh
python3 sp500_coursework/evidence/independent_check.py
```

Observed check output:

```text
Origin: 2026-10-23T11:00:00+00:00 Target close date: 2026-10-30
P0=7663.43017578; P-20=7704.12988281; actual=7580.06982422
M=ln(P0/P-20)=-0.0052968463; saved M=-0.0052968463
realized log return=-0.0109372759; saved=-0.0109372759
recomputed forecast=7696.75345761; saved=7696.75345761
recomputed APE=1.5393477381%
```

This verifies the arithmetic for one saved row. It does not verify the Yahoo source against the official scoring feed or establish that the model is predictively reliable.

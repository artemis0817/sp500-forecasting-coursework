#!/usr/bin/env python3
"""Reproducible expanding-window validation from the frozen Yahoo chart JSON."""

import csv
import json
import math
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/raw/sp500_yahoo_chart_2023-01-01_to_2026-10-31.json"
OUT_CSV = ROOT / "evidence/validation_origins.csv"
OUT_JSON = ROOT / "evidence/validation_summary.json"
NY = ZoneInfo("America/New_York")
LONDON = ZoneInfo("Europe/London")
MIN_TRAIN = 52
HORIZON = timedelta(days=7, hours=9)


def solve(matrix, vector):
    """Solve a small OLS normal equation system by Gaussian elimination."""
    a = [list(row) + [value] for row, value in zip(matrix, vector)]
    n = len(a)
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(a[r][col]))
        if abs(a[pivot][col]) < 1e-14:
            raise ValueError("Singular OLS design")
        a[col], a[pivot] = a[pivot], a[col]
        scale = a[col][col]
        a[col] = [v / scale for v in a[col]]
        for row in range(n):
            if row == col:
                continue
            scale = a[row][col]
            a[row] = [x - scale * y for x, y in zip(a[row], a[col])]
    return [a[i][-1] for i in range(n)]


def fit_ols(rows):
    # x = [intercept, 20-session log momentum], y = log return to target close.
    xtx = [[0.0, 0.0], [0.0, 0.0]]
    xty = [0.0, 0.0]
    for row in rows:
        x = [1.0, row["momentum"]]
        y = row["target_log_return"]
        for i in range(2):
            xty[i] += x[i] * y
            for j in range(2):
                xtx[i][j] += x[i] * x[j]
    return solve(xtx, xty)


def load_closes():
    payload = json.loads(INPUT.read_text())
    result = payload["chart"]["result"][0]
    exchange_zone = ZoneInfo(result["meta"].get("exchangeTimezoneName", "America/New_York"))
    closes = []
    for stamp, close in zip(result["timestamp"], result["indicators"]["quote"][0]["close"]):
        if close is None:
            continue
        session_date = datetime.fromtimestamp(stamp, timezone.utc).astimezone(exchange_zone).date()
        available_at = datetime.combine(session_date, time(16, 0), exchange_zone).astimezone(timezone.utc)
        closes.append({"date": session_date, "close": float(close), "available_at": available_at})
    closes.sort(key=lambda row: row["date"])
    return closes


def last_available_index(closes, cutoff):
    eligible = [i for i, row in enumerate(closes) if row["available_at"] <= cutoff]
    return eligible[-1] if eligible else None


def make_origins(closes):
    rows = []
    first = closes[0]["date"]
    last = closes[-1]["date"]
    day = first
    while day <= last:
        if day.weekday() == 4:  # Friday, same weekday as the final cutoff.
            local_origin = datetime.combine(day, time(12, 0), LONDON)
            origin = local_origin.astimezone(timezone.utc)
            p0_index = last_available_index(closes, origin)
            target_time = (local_origin + HORIZON).astimezone(timezone.utc)
            target_index = last_available_index(closes, target_time)
            target_session_date = target_time.astimezone(NY).date()
            target_is_near_target_session = (
                target_index is not None
                and 0 <= (target_session_date - closes[target_index]["date"]).days <= 2
            )
            if p0_index is not None and target_is_near_target_session:
                if p0_index >= 20 and target_index > p0_index:
                    p0 = closes[p0_index]["close"]
                    p20 = closes[p0_index - 20]["close"]
                    rows.append(
                        {
                            "origin": origin,
                            "target_time": target_time,
                            "p0_date": closes[p0_index]["date"],
                            "target_date": closes[target_index]["date"],
                            "p0": p0,
                            "actual": closes[target_index]["close"],
                            "momentum": math.log(p0 / p20),
                            "target_log_return": math.log(closes[target_index]["close"] / p0),
                        }
                    )
        day += timedelta(days=1)
    return rows


def score(forecasts, field):
    actuals = [r["actual"] for r in forecasts]
    predictions = [r[field] for r in forecasts]
    errors = [100 * (p - a) / a for p, a in zip(predictions, actuals)]
    ape = [abs(e) for e in errors]
    return {
        "n": len(forecasts),
        "mean_absolute_percentage_error_pct": sum(ape) / len(ape),
        "mean_signed_percentage_error_pct": sum(errors) / len(errors),
        "mean_absolute_point_error": sum(abs(p - a) for p, a in zip(predictions, actuals)) / len(actuals),
    }


def main():
    closes = load_closes()
    all_rows = make_origins(closes)
    evaluated = []
    for current in all_rows:
        training = [r for r in all_rows if r["target_time"] <= current["origin"]]
        record = dict(current)
        record["baseline_forecast"] = current["p0"]
        record["training_n"] = len(training)
        record["momentum_forecast"] = None
        record["intercept"] = None
        record["momentum_coefficient"] = None
        if len(training) >= MIN_TRAIN:
            intercept, coefficient = fit_ols(training)
            record["intercept"] = intercept
            record["momentum_coefficient"] = coefficient
            record["momentum_forecast"] = current["p0"] * math.exp(
                intercept + coefficient * current["momentum"]
            )
            evaluated.append(record)

    if not evaluated:
        raise RuntimeError("No out-of-sample origins met the minimum training requirement")

    columns = [
        "origin", "target_time", "p0_date", "target_date", "p0", "actual",
        "momentum", "target_log_return", "training_n", "intercept",
        "momentum_coefficient", "baseline_forecast", "momentum_forecast",
    ]
    with OUT_CSV.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in evaluated:
            writer.writerow(
                {
                    key: row[key].isoformat() if isinstance(row[key], (date, datetime)) else row[key]
                    for key in columns
                }
            )

    summary = {
        "status": "INTERIM; not the final coursework forecast",
        "input_file": str(INPUT.relative_to(ROOT)),
        "source_symbol": "^GSPC",
        "first_close_date": closes[0]["date"].isoformat(),
        "last_close_date": closes[-1]["date"].isoformat(),
        "forecast_origin_rule": "Friday 12:00 Europe/London local time",
        "target_horizon": "7 days 9 hours Europe/London wall-clock time; UTC interval varies across DST changes",
        "target_close_rule": "latest S&P 500 session close available at or before origin + horizon",
        "validation": "expanding-window OLS, training labels admitted only after target close is observed",
        "minimum_training_origins": MIN_TRAIN,
        "tested_origins": len(evaluated),
        "first_test_origin": evaluated[0]["origin"].isoformat(),
        "last_test_origin": evaluated[-1]["origin"].isoformat(),
        "unchanged_price_benchmark": score(evaluated, "baseline_forecast"),
        "momentum_only_model": score(evaluated, "momentum_forecast"),
        "event_factor_G": "not fitted: point-in-time Dst vintages are not established",
        "limitations": [
            "Yahoo Finance is a third-party data source, not the official S&P DJI marking reference.",
            "Yahoo does not provide exact publication timestamps or historical data vintages in this snapshot.",
            "Weekly Friday origins reduce overlap; forecasts remain serially dependent and this is one interim sample.",
            "A lower historical error does not establish a reliable forecast for the final target.",
        ],
    }
    OUT_JSON.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Recalculate summary error metrics from saved per-origin forecasts using Decimal."""
import csv,json
from decimal import Decimal
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((ROOT/'evidence/validation_origins.csv').open(newline='')))
models={'random_walk':'baseline_forecast','expanding_log_momentum_OLS':'momentum_forecast'}
out={'method':'Decimal arithmetic from per-origin CSV; APE=100*abs(forecast-actual)/actual; signed error=100*(forecast-actual)/actual; MAE=mean(abs(forecast-actual)).','n':len(rows),'first_origin':rows[0]['origin'],'last_origin':rows[-1]['origin'],'first_target_date':rows[0]['target_date'],'last_target_date':rows[-1]['target_date'],'source_csv':'evidence/validation_origins.csv','models':{}}
for name,col in models.items():
    apes=[]; signed=[]; abs_errors=[]
    for row in rows:
        actual=Decimal(row['actual']); forecast=Decimal(row[col]); signed.append(Decimal(100)*(forecast-actual)/actual); apes.append(abs(signed[-1])); abs_errors.append(abs(forecast-actual))
    n=Decimal(len(rows)); out['models'][name]={'MAPE_pct':str(sum(apes)/n),'mean_signed_percentage_error_pct':str(sum(signed)/n),'mean_absolute_point_error':str(sum(abs_errors)/n)}
p=ROOT/'evidence/INDEPENDENT_METRICS.json'; p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

# Agent research instruction

You are assisting the group with an S&P 500 price-index forecast. The binding coursework target is the official S&P 500 price-index close on 20 November 2026 at 21:00 London time (16:00 New York). The final information boundary is 13 November 2026 at 12:00 London time. Never use data published after that cutoff in the submitted forecast.

Use only saved, dated inputs for a frozen run. State each source URL, retrieval time, source publication time when available, data vintage, and last usable observation. Separate observed inputs, calculated factors, model estimates, and human judgement. Do not describe a source timestamp as a publication timestamp unless the source supports that claim.

Start with an unchanged-price benchmark and a one-factor 20-session log-momentum model. Compare them with an expanding, time-ordered evaluation at Friday 12:00 Europe/London origins and the same 7-day-9-hour London-time horizon. At each origin, train only on outcomes whose target close was already observed by that origin. Report the forecasts, errors, failures, and overlapping-window limitations. Do not tune parameters using later outcomes.

Treat the five-calendar-day Dst threshold-crossing factor as an unverified candidate. Only fit it if saved historical data vintages establish what Dst values were available at each forecast origin. Otherwise explain the data-timing failure and recommend excluding it. Do not invent a causal mechanism, a correction, a source timestamp, a result, or group approval.

Use Python as the calculation tool. Independently check at least one calculation from the saved inputs with a separate calculation path and preserve the actual check output. Save the prompt, frozen inputs, scripts, software versions, outputs, source checks, and limitations so another person can reproduce the run without an online AI service. The human group must approve the final forecast.

"""Compare VIX2/5/10 using the original frozen snapshot and identical forecast origins."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, argparse
import numpy as np
import pandas as pd
import run_model as base

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--windows',nargs='+',type=int,default=[2,5,10])
parser.add_argument('--output-subdir',default='vix_window_comparison')
args=parser.parse_args()
WINDOWS=sorted(set(args.windows))
assert 5 in WINDOWS and all(1<=k<=60 for k in WINDOWS)
OUT=(ROOT/args.output_subdir).resolve()
assert ROOT in OUT.parents
OUT.mkdir(exist_ok=True)
suffix='vix2_to_10' if WINDOWS==list(range(2,11)) else 'vix2_5_10'
protected=[ROOT/'results/metrics.csv',ROOT/'results/backtest_predictions.csv',ROOT/'results/summary.json']
before={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
p,v,_,_=base.load_data()
samples=base.make_samples(p,v)
for k in WINDOWS:
    factor=np.log(v/v.shift(k))
    samples[f'vix_change{k}']=samples.vix_date.map(factor)
assert samples[['momentum20']+[f'vix_change{k}' for k in WINDOWS]].notna().all().all()
records=[]
for _,row in samples.loc[(samples.origin_date>=base.TEST_START)&samples.target_log_return.notna()].iterrows():
    train=samples.loc[(samples.origin_date>=row.origin_date-pd.DateOffset(years=base.TRAIN_YEARS))&
        (samples.origin_date<row.origin_date)&(samples.nominal_target_date<row.origin_date)&samples.target_log_return.notna()]
    if len(train)<base.MIN_TRAIN:continue
    assert (train.actual_target_date<row.origin_date).all()
    assert row.price_date<row.origin_date and row.vix_date<row.origin_date
    r=row.to_dict()
    r.update(train_n=len(train),train_first_origin=train.origin_date.min(),train_last_origin=train.origin_date.max(),
        latest_training_target=train.actual_target_date.max(),benchmark=row.p0,
        drift_forecast=float(row.p0*np.exp(train.target_log_return.mean())))
    pred,ret,coef=base.fit_predict(train,row,['momentum20'])
    r.update(momentum_forecast=pred)
    for k in WINDOWS:
        pred,ret,coef=base.fit_predict(train,row,['momentum20',f'vix_change{k}'])
        r.update({f'vix{k}_forecast':pred,f'vix{k}_pred_log_return':ret,
            f'vix{k}_alpha':coef[0],f'vix{k}_beta_m':coef[1],f'vix{k}_beta_v':coef[2]})
    records.append(r)
bt=pd.DataFrame(records)
specs=[('benchmark','Random walk (no drift)',0),('momentum_forecast','Momentum-only OLS',0)]+[
    (f'vix{k}_forecast',f'Momentum + VIX{k}',k) for k in WINDOWS]+[('drift_forecast','Historical drift (diagnostic)',0)]
for key,_,_ in specs:
    bt[f'{key}_ape_pct']=100*(bt[key]-bt.actual_close).abs()/bt.actual_close
    bt[f'{key}_signed_error_pct']=100*(bt[key]-bt.actual_close)/bt.actual_close

# Reproduce original four methods before interpreting the new candidates.
old=pd.read_csv(ROOT/'results/backtest_predictions.csv')
assert bt.origin_date.dt.strftime('%Y-%m-%d').tolist()==old.origin_date.tolist()
for newkey,oldkey in [('benchmark','benchmark'),('momentum_forecast','momentum_forecast'),('vix5_forecast','dual_forecast'),('drift_forecast','drift_forecast')]:
    assert np.allclose(bt[newkey],old[oldkey],atol=1e-7,rtol=0)
assert (bt.train_n.to_numpy()==old.train_n.to_numpy()).all()

metrics=[]
bape=bt.benchmark_ape_pct
v5ape=bt.vix5_forecast_ape_pct
for key,label,k in specs:
    ape=bt[f'{key}_ape_pct']
    metrics.append(dict(model=key,label=label,vix_lookback_trading_days=k,n=len(bt),
        mape_pct=float(ape.mean()),median_ape_pct=float(ape.median()),
        rmse_points=float(np.sqrt(np.mean((bt[key]-bt.actual_close)**2))),worst_ape_pct=float(ape.max()),
        win_rate_vs_benchmark_pct=float(100*(ape<bape).mean()) if key!='benchmark' else None,
        relative_mape_improvement_vs_benchmark_pct=float(100*(1-ape.mean()/bape.mean())),
        mape_difference_vs_vix5_pp=float(ape.mean()-v5ape.mean()),
        win_rate_vs_vix5_pct=float(100*(ape<v5ape).mean()) if key!='vix5_forecast' else None,
        mean_assignment_accuracy_score=float(np.maximum(0,50-5*ape).mean())))
metrics=pd.DataFrame(metrics)
yearly=[]
for year,g in bt.groupby(bt.origin_date.dt.year):
    for key,label,k in specs:yearly.append(dict(year=int(year),model=key,label=label,n=len(g),mape_pct=float(g[key+'_ape_pct'].mean())))
daily=pd.concat([p,v],axis=1,sort=True)
daily['momentum20']=np.log(p/p.shift(20))
for k in WINDOWS:daily[f'vix_change{k}']=np.log(v/v.shift(k))
daily.loc[daily.index>=pd.Timestamp('2021-01-01')].to_csv(OUT/f'daily_inputs_{suffix}.csv',index_label='date',float_format='%.10f')
bt.to_csv(OUT/f'backtest_predictions_{suffix}.csv',index=False,float_format='%.10f')
metrics.to_csv(OUT/'metrics_comparison.csv',index=False,float_format='%.10f')
pd.DataFrame(yearly).to_csv(OUT/'yearly_comparison.csv',index=False,float_format='%.10f')
for k in WINDOWS:
    cols=['origin_date','price_date','vix_date','p0','momentum20',f'vix_change{k}','nominal_target_date',
        'actual_target_date','actual_close','train_n','latest_training_target',f'vix{k}_forecast',f'vix{k}_forecast_ape_pct',f'vix{k}_alpha',f'vix{k}_beta_m',f'vix{k}_beta_v']
    bt[cols].to_csv(OUT/f'VIX{k}_backtest.csv',index=False,float_format='%.10f')
    # Independent recomputation from the written file, not the in-memory error column.
    saved=pd.read_csv(OUT/f'VIX{k}_backtest.csv')
    pred=saved.p0*np.exp(saved[f'vix{k}_alpha']+saved[f'vix{k}_beta_m']*saved.momentum20+saved[f'vix{k}_beta_v']*saved[f'vix_change{k}'])
    assert np.allclose(pred,saved[f'vix{k}_forecast'],atol=2e-6,rtol=0)
    ape=100*(saved[f'vix{k}_forecast']-saved.actual_close).abs()/saved.actual_close
    assert np.allclose(ape,saved[f'vix{k}_forecast_ape_pct'],atol=1e-8)

ranking=metrics.loc[metrics.vix_lookback_trading_days>0].sort_values('mape_pct').copy()
ranking.insert(0,'mape_rank',range(1,len(ranking)+1))
ranking.to_csv(OUT/'vix_window_ranking.csv',index=False,float_format='%.10f')
summary=dict(generated_utc=datetime.now(timezone.utc).isoformat(),data_boundary_utc=base.AS_OF.isoformat(),windows=WINDOWS,
    first_origin=str(bt.origin_date.min().date()),last_origin=str(bt.origin_date.max().date()),
    first_target=str(bt.nominal_target_date.min().date()),last_target=str(bt.nominal_target_date.max().date()),
    training_years=base.TRAIN_YEARS,n=len(bt),metrics=metrics.where(metrics.notna(),None).to_dict('records'),
    checks=dict(original_four_methods_reproduced=True,identical_training_counts=True,date_boundaries_checked=True,
        independent_saved_forecast_and_error_checks=True),
    interpretation='VIX window sensitivity is post-hoc on the existing evaluation set; it is development evidence, not an untouched holdout.')
# Avoid non-standard NaN in JSON.
summary['metrics']=[{key:(None if isinstance(val,float) and np.isnan(val) else val) for key,val in x.items()} for x in summary['metrics']]
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
for path in protected:assert hashlib.sha256(path.read_bytes()).hexdigest()==before[path]
print(metrics[['label','mape_pct','median_ape_pct','rmse_points','worst_ape_pct','mape_difference_vs_vix5_pp']].to_string(index=False))
print('\nBY YEAR\n',pd.DataFrame(yearly).pivot(index='year',columns='label',values='mape_pct').to_string())
print('\nVerified: 103 matching origins; original four methods reproduced; original outputs unchanged.')

from pathlib import Path
import json
import numpy as np
import pandas as pd

root=Path(__file__).resolve().parent
summary=json.loads((root/'results/summary.json').read_text(encoding='utf-8'))
d=pd.read_csv(root/'results/backtest_predictions.csv')
for col in ['price_date','vix_date','latest_training_target']:
    assert (pd.to_datetime(d[col])<pd.to_datetime(d.origin_date)).all(),col
for spec in summary['metrics']:
    key=spec['model']
    ape=100*np.abs(d[key].to_numpy()-d.actual_close.to_numpy())/d.actual_close.to_numpy()
    assert np.allclose(ape,d[key+'_ape_pct'],atol=1e-8)
    assert np.isclose(ape.mean(),spec['mape_pct'],atol=1e-8)
assert np.allclose(d.dual_pred_return,d.dual_alpha+d.dual_beta_m*d.momentum20+d.dual_beta_v*d.vix_change5,atol=1e-8)
assert np.allclose(d.dual_forecast,d.p0*np.exp(d.dual_pred_return),atol=1e-5)
assert len(d)==103
print('Verified 103 origins: saved errors, MAPE, dates, forecast mapping and contribution sum.')

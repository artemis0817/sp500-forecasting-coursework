"""Fixed-spec S&P 500 forecasting prototype. Offline reproduction from raw snapshots."""
from pathlib import Path
import json, hashlib, platform
from datetime import datetime, timezone
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW, OUT = ROOT/'data/raw', ROOT/'results'
OUT.mkdir(exist_ok=True)
AS_OF = pd.Timestamp('2026-10-30 12:00:00+00:00')
DAY = AS_OF.tz_localize(None).normalize()
TEST_START = DAY - pd.DateOffset(years=2)
TRAIN_YEARS, MIN_TRAIN = 3, 100

def load_data():
    doc = json.loads((RAW/'sp500_yahoo.json').read_text())['chart']['result'][0]
    assert doc['meta']['symbol'] == '^GSPC'
    dates = pd.to_datetime(doc['timestamp'],unit='s',utc=True).tz_convert('America/New_York').tz_localize(None).normalize()
    p = pd.Series(doc['indicators']['quote'][0]['close'],index=dates,name='sp500_close').dropna()
    v0 = pd.read_csv(RAW/'vix.csv')
    v = pd.Series(v0['CLOSE'].to_numpy(),index=pd.to_datetime(v0['DATE'],format='%m/%d/%Y'),name='vix_close').dropna()
    assert not p.index.duplicated().any() and not v.index.duplicated().any()
    p, v = p.sort_index(), v.sort_index()
    raw_max_p, raw_max_v = p.index.max(), v.index.max()
    # Today's chart bar is still in progress and is after the declared noon cutoff.
    p, v = p.loc[p.index < DAY], v.loc[v.index < DAY]
    assert (p > 0).all() and (v > 0).all()
    return p, v, raw_max_p, raw_max_v

def make_samples(p,v):
    m = np.log(p/p.shift(20))
    vc = np.log(v/v.shift(5))
    rows=[]
    for origin in pd.date_range(p.index.min()+pd.DateOffset(months=2),DAY,freq='W-FRI'):
        pp, vv = p.loc[p.index < origin], v.loc[v.index < origin]
        if pp.empty or vv.empty: continue
        d, vd = pp.index[-1], vv.index[-1]
        if pd.isna(m.loc[d]) or pd.isna(vc.loc[vd]): continue
        nominal = origin + pd.Timedelta(days=7)
        # A target is not treated as observed before its scheduled date has passed.
        observed = nominal < DAY
        target_date, actual = pd.NaT, np.nan
        if observed:
            eligible = p.loc[p.index <= nominal]
            if not eligible.empty:
                target_date, actual = eligible.index[-1], float(eligible.iloc[-1])
                assert (nominal-target_date).days <= 4
        target_local = (nominal+pd.Timedelta(hours=16)).tz_localize('America/New_York')
        rows.append(dict(origin_date=origin,origin_utc=origin.tz_localize('UTC')+pd.Timedelta(hours=12),
            price_date=d,vix_date=vd,p0=float(pp.iloc[-1]),momentum20=float(m.loc[d]),vix_change5=float(vc.loc[vd]),
            nominal_target_date=nominal,target_close_utc=target_local.tz_convert('UTC'),
            actual_target_date=target_date,actual_close=actual,
            target_log_return=np.log(actual/float(pp.iloc[-1])) if observed else np.nan))
    return pd.DataFrame(rows)

def fit_predict(train,row,factors):
    X=np.column_stack([np.ones(len(train))]+[train[f].to_numpy() for f in factors])
    y=train.target_log_return.to_numpy()
    coef,_,rank,_=np.linalg.lstsq(X,y,rcond=None)
    assert rank==len(factors)+1
    # Independent algebraic check: least-squares solution vs normal equations.
    ref=np.linalg.solve(X.T@X,X.T@y)
    assert np.allclose(coef,ref,rtol=1e-7,atol=1e-9)
    x=np.array([1.]+[row[f] for f in factors])
    r=float(x@coef)
    return float(row.p0*np.exp(r)),r,coef

def main():
    p,v,rp,rv=load_data()
    samples=make_samples(p,v)
    predictions=[]
    for _,row in samples.loc[samples.origin_date>=TEST_START].iterrows():
        start=row.origin_date-pd.DateOffset(years=TRAIN_YEARS)
        train=samples.loc[(samples.origin_date>=start)&(samples.origin_date<row.origin_date)&
            (samples.nominal_target_date<row.origin_date)&samples.target_log_return.notna()]
        if len(train)<MIN_TRAIN: continue
        assert (train.actual_target_date<row.origin_date).all()
        assert row.price_date<row.origin_date and row.vix_date<row.origin_date
        single,sr,sc=fit_predict(train,row,['momentum20'])
        dual,dr,dc=fit_predict(train,row,['momentum20','vix_change5'])
        r=row.to_dict()
        r.update(train_n=len(train),train_first_origin=train.origin_date.min(),train_last_origin=train.origin_date.max(),
            latest_training_target=train.actual_target_date.max(),benchmark=row.p0,
            momentum_forecast=single,dual_forecast=dual,drift_forecast=float(row.p0*np.exp(train.target_log_return.mean())),momentum_pred_return=sr,dual_pred_return=dr,
            single_alpha=sc[0],single_beta_m=sc[1],dual_alpha=dc[0],dual_beta_m=dc[1],dual_beta_v=dc[2],
            dual_intercept_contribution=dc[0],dual_m_contribution=dc[1]*row.momentum20,
            dual_v_contribution=dc[2]*row.vix_change5)
        predictions.append(r)
    predictions=pd.DataFrame(predictions)
    scored=predictions.loc[predictions.actual_close.notna()].copy()
    for key in ['benchmark','momentum_forecast','dual_forecast','drift_forecast']:
        scored[key+'_ape_pct']=100*(scored[key]-scored.actual_close).abs()/scored.actual_close
        scored[key+'_signed_error_pct']=100*(scored[key]-scored.actual_close)/scored.actual_close
    metrics=[]
    bape=scored.benchmark_ape_pct
    for key,label in [('benchmark','Unchanged close'),('momentum_forecast','Momentum only'),('dual_forecast','Momentum + VIX'),('drift_forecast','Historical drift (diagnostic)')]:
        ape=scored[key+'_ape_pct']
        metrics.append(dict(model=key,label=label,n=len(scored),mape_pct=float(ape.mean()),median_ape_pct=float(ape.median()),
          rmse_points=float(np.sqrt(np.mean((scored[key]-scored.actual_close)**2))),worst_ape_pct=float(ape.max()),
          win_rate_vs_benchmark_pct=float(100*(ape<bape).mean()) if key!='benchmark' else None,
          relative_mape_improvement_pct=float(100*(1-ape.mean()/bape.mean())),
          mean_assignment_accuracy_score=float(np.maximum(0,50-5*ape).mean())))
    scored.to_csv(OUT/'backtest_predictions.csv',index=False,float_format='%.10f')
    pd.DataFrame(metrics).to_csv(OUT/'metrics.csv',index=False,float_format='%.8f')
    samples.to_csv(OUT/'weekly_samples.csv',index=False,float_format='%.10f')
    daily=pd.concat([p,v],axis=1,sort=True)
    daily['momentum20']=np.log(p/p.shift(20))
    daily['vix_change5']=np.log(v/v.shift(5))
    daily.loc[daily.index>=pd.Timestamp('2021-01-01')].to_csv(OUT/'daily_inputs.csv',index_label='date',float_format='%.10f')
    latest=predictions.iloc[-1].to_dict()
    def clean(x):
        if x is pd.NaT:return None
        if isinstance(x,(pd.Timestamp,datetime)):return x.isoformat()
        if isinstance(x,(np.integer,)):return int(x)
        if isinstance(x,(np.floating,float)) and pd.isna(x):return None
        if isinstance(x,(np.floating,)):return float(x)
        return x
    latest={k:clean(x) for k,x in latest.items()}
    worst=scored.nlargest(5,'dual_forecast_ape_pct')
    worst.to_csv(OUT/'worst_cases.csv',index=False,float_format='%.10f')
    yearly=[]
    for year,g in scored.groupby(scored.origin_date.dt.year):
        yearly.append(dict(year=int(year),n=len(g),**{k:float(g[k+'_ape_pct'].mean()) for k in ['benchmark','momentum_forecast','dual_forecast','drift_forecast']}))
    result=dict(as_of_utc=AS_OF.isoformat(),generated_utc=datetime.now(timezone.utc).isoformat(),test_requested_start=TEST_START.date().isoformat(),
      test_first_origin=str(scored.origin_date.min().date()),test_last_origin=str(scored.origin_date.max().date()),
      target_first=str(scored.nominal_target_date.min().date()),target_last=str(scored.nominal_target_date.max().date()),
      train_years=TRAIN_YEARS,min_train=MIN_TRAIN,metrics=metrics,yearly=yearly,latest_demo=latest,
      data=dict(sp500_first=str(p.index.min().date()),sp500_last=str(p.index.max().date()),vix_last=str(v.index.max().date()),
       raw_sp500_max=str(rp.date()),raw_vix_max=str(rv.date()),excluded_sp500_current_day=bool(rp>=DAY)),
      checks=dict(training_targets_strictly_before_origin=True,features_strictly_before_origin=True,
       ols_independent_solution_check=True,n_scored=len(scored),n_unscored=len(predictions)-len(scored)),
      coefficient_summary=dict(dual_beta_m_positive_pct=float(100*(scored.dual_beta_m>0).mean()),
       dual_beta_v_negative_pct=float(100*(scored.dual_beta_v<0).mean())),
      versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__))
    (OUT/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    sources=[]
    for name,url in [('sp500_yahoo.json','https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?range=10y&interval=1d'),('vix.csv','https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv')]:
        path=RAW/name
        sources.append(dict(file=name,url=url,snapshot_saved_utc=datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat(),
          sha256=hashlib.sha256(path.read_bytes()).hexdigest(),publication_time='Not independently archived for historical observations. Prior-day-close availability assumed.'))
    (ROOT/'data/source_manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(period=[result['test_first_origin'],result['test_last_origin']],metrics=metrics,demo=latest),ensure_ascii=False,indent=2))

if __name__=='__main__':main()

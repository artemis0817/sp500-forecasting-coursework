#!/usr/bin/env python3
"""Independent arithmetic check using a separate aggregate-sum OLS formula."""
import json
from pathlib import Path
from math import exp
r=json.loads(Path('outputs/rebuilt_forecast.json').read_text())
rows=r['training_observations']; n=len(rows)
xs=[x['momentum20'] for x in rows]; ys=[x['target_log_return'] for x in rows]
sx=sum(xs); sy=sum(ys); sx2=sum(x*x for x in xs); sxy=sum(x*y for x,y in zip(xs,ys))
b=(n*sxy-sx*sy)/(n*sx2-sx*sx); a=(sy-b*sx)/n
pred=r['p0']*exp(a+b*r['momentum20'])
assert abs(a-r['intercept'])<1e-10 and abs(b-r['slope'])<1e-10
assert f'{pred:.2f}'==r['momentum20_ols_two_decimals']
print('Independent aggregate-sum formula:')
print('n =',n,'intercept =',format(a,'.12f'),'slope =',format(b,'.12f'))
print('forecast =',format(pred,'.2f'),'saved =',r['momentum20_ols_two_decimals'])
print('PASS: coefficients and displayed forecast match')

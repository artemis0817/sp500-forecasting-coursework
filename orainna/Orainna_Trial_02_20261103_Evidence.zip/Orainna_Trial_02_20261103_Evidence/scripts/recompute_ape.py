#!/usr/bin/env python3
"""Calculate APE from the documented actual close transcription and forecasts."""
import csv,json
from pathlib import Path
forecasts=json.loads(Path('outputs/rebuilt_forecast.json').read_text())
with Path('inputs/comparison_actuals.csv').open(newline='') as f: actuals={r['date']:float(r['sp500_close']) for r in csv.DictReader(f)}
target=forecasts['target_date']; actual=actuals[target]
rows=[]
for name,val in [('Momentum20 only OLS',float(forecasts['momentum20_ols_two_decimals'])),('Random walk',float(forecasts['random_walk_two_decimals']))]:
    ape=abs(val-actual)/actual*100; rows.append({'model':name,'forecast':val,'actual':actual,'ape_percent':ape})
out={'target_date':target,'actual_close':actual,'actual_source':'inputs/comparison_actuals.csv; see inputs/actuals_source_record.md','calculations':rows}
Path('outputs/ape.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

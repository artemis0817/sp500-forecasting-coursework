#!/usr/bin/env python3
"""Rebuild one Orainna trial from its included frozen Artemis ZIP; stdlib only."""
import json, sys, hashlib
from pathlib import Path
from zipfile import ZipFile
from datetime import datetime, timezone, timedelta, time
from zoneinfo import ZoneInfo
from math import log, exp

def fit(xs, ys):
    xb=sum(xs)/len(xs); yb=sum(ys)/len(ys)
    b=sum((x-xb)*(y-yb) for x,y in zip(xs,ys))/sum((x-xb)**2 for x in xs)
    return yb-b*xb,b

archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path('inputs/frozen_trial.zip')
with ZipFile(archive) as z:
    raw_name=next(n for n in z.namelist() if n.endswith('/01_raw/sp500_yahoo.json'))
    man_name=next(n for n in z.namelist() if n.endswith('/01_raw/manifest.json'))
    rec_name=next(n for n in z.namelist() if n.endswith('/04_forecasts/forecast_record.json'))
    raw_bytes=z.read(raw_name); manifest=json.loads(z.read(man_name)); rec=json.loads(z.read(rec_name))
    expected=next(x['sha256'] for x in manifest if x['file']=='sp500_yahoo.json')
    digest=hashlib.sha256(raw_bytes).hexdigest()
    if digest!=expected: raise SystemExit('FAIL: Yahoo raw JSON SHA-256 mismatch')
    chart=json.loads(raw_bytes)['chart']['result'][0]
    if chart['meta']['symbol']!='^GSPC': raise SystemExit('FAIL: wrong symbol')
    ny=ZoneInfo('America/New_York'); closes={}
    for stamp,close in zip(chart['timestamp'],chart['indicators']['quote'][0]['close']):
        day=datetime.fromtimestamp(stamp,timezone.utc).astimezone(ny).date()
        if close is not None: closes[day]=float(close)
cutoff=datetime.fromisoformat(rec['information_cutoff_utc']); cutoff_day=cutoff.date()
eligible=sorted(d for d in closes if d<cutoff_day); p0=closes[eligible[-1]]
ref=eligible[-21]; m20=log(p0/closes[ref])
start=cutoff_day.replace(year=cutoff_day.year-3)
while start.weekday()!=cutoff_day.weekday(): start+=timedelta(days=1)
rows=[]; origin=start
while origin<cutoff_day:
    nominal=origin+timedelta(days=7)
    close_time=datetime.combine(nominal,time(16),ny).astimezone(timezone.utc)
    if close_time<cutoff:
        before=[d for d in eligible if d<origin]; targets=[d for d in closes if d<=nominal]
        if before and targets:
            pd=before[-1]; idx=eligible.index(pd)
            if idx>=20:
                td=targets[-1]; x=log(closes[pd]/closes[eligible[idx-20]]); y=log(closes[td]/closes[pd])
                rows.append((origin.isoformat(),x,y))
    origin+=timedelta(days=7)
a,b=fit([r[1] for r in rows],[r[2] for r in rows]); pred=p0*exp(a+b*m20)
saved=next(x['forecast_value'] for x in rec['forecasts'] if x['model']=='momentum_only_OLS')
if len(rows)!=155 or f'{pred:.2f}'!=f'{saved:.2f}': raise SystemExit('FAIL: rebuilt forecast does not match frozen record')
result={'trial':archive.name,'source_sha256':digest,'cutoff_utc':cutoff.isoformat(),'target_date':rec['target_time_utc'][:10],'last_eligible_close_date':eligible[-1].isoformat(),'p0':p0,'momentum20_reference_date':ref.isoformat(),'momentum20':m20,'training_n':len(rows),'training_first_origin':rows[0][0],'training_last_origin':rows[-1][0],'intercept':a,'slope':b,'momentum20_ols_full_precision':pred,'momentum20_ols_two_decimals':f'{pred:.2f}','random_walk_two_decimals':f'{p0:.2f}','frozen_archive_ols_two_decimals':f'{saved:.2f}','source_capture_after_cutoff':True,'training_observations':[{'origin_date':r[0],'momentum20':r[1],'target_log_return':r[2]} for r in rows]}
Path('outputs').mkdir(exist_ok=True); Path('outputs/rebuilt_forecast.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2)); print('PASS: hash verified; 155 observations; forecast reproduces to 2 decimals')

# Actual close source record

The four target closes were manually transcribed from the Yahoo Finance ^GSPC historical page viewed in Chrome at 2026-11-13 01:08 UTC: https://finance.yahoo.com/quote/%5EGSPC/history/ . The retrieval time is the page-view time recorded in the review, not an asserted Yahoo publication timestamp. No raw HTML response or screenshot was retained, so this CSV is a transcription record, not a frozen original source capture.

Cross-checks recorded in the review: FRED SP500 matched 9–11 November; it had not yet posted 12 November at review time. Associated Press corroborated the 12 November close of 7,592.40: https://apnews.com/article/3f3668a937a11535103e3a5c8d82c9fc . Recheck FRED after its next update before treating the final date as independently matched by FRED.

The CSV values are observations. APEs in the calculation files are arithmetic derived from the two-decimal workbook forecasts and these observed closes.

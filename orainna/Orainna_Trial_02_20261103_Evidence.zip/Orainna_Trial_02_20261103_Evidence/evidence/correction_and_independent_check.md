# Audit trail and independent check

A provenance concern prompted replacing the earlier check against precomputed training CSVs with a direct rebuild from the raw Yahoo JSON snapshots inside the frozen trial archives. The rebuild verified the raw-file hashes against each archive manifest, reconstructed all 155 matured weekly observations, and reproduced the archived Momentum20-only OLS display value to two decimals. The recalculation did not change the reported display value; no correction outcome is invented.

`independent_check.py` verifies coefficients using the aggregate-sum OLS identities, a separate arithmetic path from the centered covariance calculation in the primary rebuild. This checks regression arithmetic given the saved training rows; it is not an independent provider capture or an independent raw-data parser.

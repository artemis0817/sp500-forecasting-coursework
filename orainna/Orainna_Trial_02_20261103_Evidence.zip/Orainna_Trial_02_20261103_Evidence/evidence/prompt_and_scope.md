# User task and scope record

Relevant user instruction, preserved from the conversation: “我还有evidence需要提供，你给我制作一个zip，需要非常详细的evidence，认真一点谢谢”. The user later selected the earlier Yahoo version: “还是用你前面的yahoo的那一版”. The coursework evidence requirement previously supplied by the user was: “保存指令、来源快照、代码、软件版本、工具输出，以及一次真实纠错或独立核查的证据。证据ZIP应能在没有在线AI服务的情况下复现预测，不得为补齐记录而编造纠错过程或结果。”

This archive records Orainna's supplemental workbook rows: Momentum20-only OLS and Random walk across Trials 01–04. The coursework's primary candidates remain Random walk, Fixed momentum, and Expanding regression; these supplemental rows do not replace the main report or establish group model selection.

The outputs are retrospective reconstructions completed on 13 November 2026. Original trial snapshots were captured after their listed noon cutoffs. The group approval fields remain pending.

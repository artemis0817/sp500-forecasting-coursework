# Trial 4 candidate forecasts

The target is the official S&P 500 price-index close on 12 November at 21:00 GMT. All source responses were retrieved by 2026-11-05T11:39:10.424925+00:00. The information cutoff was 2026-11-05T12:00:00+00:00. Calculations ran from 2026-11-05T12:00:00.685105+00:00 to 2026-11-05T12:00:01.109871+00:00. Validation completed at 2026-11-05T12:00:19.628362+00:00. Formal issuance requires a separate user decision.

| Model | Candidate level | Full-precision level |
|---|---:|---:|
| A | 7688.62 | 7688.62 |
| B | 7660.74 | 7660.742756983351 |
| C | 7697.25 | 7697.2494458789 |
| D | 7707.16 | 7707.158741193527 |

FRED's price series ended 3 November. The approved Yahoo 4 November Close of 7,688.62 matches FT. All models use that baseline. The 20-session lookback is 2026-10-07 at 7801.77, giving momentum -1.45031192%. D uses the 3 November DGS10 yield of 4.95% and the 27 October yield of 4.99%, a change of −0.04 percentage points. Its endpoint publication proxy is 4 November 16:15 New York.

The exchange calendar places six sessions between baseline and target. C/D used 198 matured Friday-origin rows through the 2026-10-30 outcome. The independent membership reconstruction, Decimal checks, future poisoning, unmatured-label exclusion, truncated-history comparison, negative availability controls and all five established test suites passed.

Source timestamps establish an observed-by bound at this trial cutoff. Exact first publication, intraday Treasury observation time and historical feature vintages remain unverified. Local checksums detect changes and depend on the recorded clock. The Trial 4 instructions authorize a post-noon calculation and require approval before issue. Under the earlier pre-noon issuance convention, a later issue would be classified as late.

"""Reconstruct Trial 4 candidates from the frozen preparation after the information cutoff."""
from pathlib import Path
from datetime import date, datetime, timedelta
from decimal import Decimal
import csv
import json
import os
import shutil
import subprocess
import sys
import tempfile

TRIAL = Path(__file__).resolve().parent
ROOT = TRIAL.parent
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "2026-11-03/source_substitution")]
import live_trials as model
from calculate_replay import Rows

DAY = date(2026, 11, 5)
CUTOFF = model.noon(DAY)
PREP = TRIAL / "preparation/20261105T113907330232Z"

def load(path):
    return json.loads(path.read_text())

def stamp_is_eligible(stamp):
    return stamp.tzinfo is not None and stamp <= CUTOFF

def check_source(path, manifest):
    if model.sha(path) != manifest["sha256"]:
        raise ValueError(f"Source checksum failed for {path}")
    if not stamp_is_eligible(datetime.fromisoformat(manifest["retrieved_utc"])):
        raise ValueError(f"Cutoff evidence failed for {path}")

def dated_row(path, date_label):
    parser = Rows()
    parser.feed(path.read_text())
    matches = [row for row in parser.rows if row and date_label in row[0]]
    if len(matches) != 1:
        raise ValueError(f"Expected one dated row in {path}")
    return matches[0]

def run_tests(out):
    suites = []
    with tempfile.TemporaryDirectory() as temp:
        history = Path(temp) / "historical"
        shutil.copytree(model.HIST, history, ignore=shutil.ignore_patterns("__pycache__"))
        paths = [history / "src/test_backtest.py", history / "src/test_point_in_time.py",
                 history / "treasury_extension/test_extension.py", ROOT / "src/test_live.py",
                 ROOT / "workflow_v2/test_workflow.py"]
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(ROOT.parent / "vendor"))
        logs = out / "test_logs"
        logs.mkdir()
        for path in paths:
            proc = subprocess.run([sys.executable, str(path)], env=env, capture_output=True, text=True)
            log = logs / (path.stem + ".txt")
            log.write_text(proc.stdout + proc.stderr)
            suites.append({"suite": path.name, "exit_code": proc.returncode, "log": str(log.relative_to(out))})
            proc.check_returncode()
    return suites

def main():
    started = model.now()
    if started <= CUTOFF or not __debug__:
        raise ValueError("Requires an actual post-noon clock and enabled model integrity checks")
    out = TRIAL / "candidate" / started.strftime("%Y%m%dT%H%M%S%fZ")
    out.mkdir(parents=True)
    for name, expected in load(PREP / "SHA256.json").items():
        assert model.sha(PREP / name) == expected
    approval = load(TRIAL / "preparation/fallback_approval.json")
    assert approval["scope"] == "Trial 4 candidate calculations only"
    assert approval["value"] == 7688.62 and not approval["formal_issuance_approval"]
    sources = load(PREP / "source_manifest.json")
    for source in sources:
        check_source(PREP / source["file"], source)
    latest_capture = max(datetime.fromisoformat(s["retrieved_utc"]) for s in sources)
    prices = model.read_series(PREP / "sp500.csv", "SP500")
    yields = model.read_series(PREP / "dgs10.csv", "DGS10")
    yahoo = dated_row(PREP / "yahoo.html", "Nov 4, 2026")
    ft = dated_row(PREP / "ft.html", "November 04, 2026")
    price = Decimal(yahoo[4].replace(",", ""))
    assert "^GSPC" in (PREP / "yahoo.html").read_text()
    assert price == Decimal(ft[4].replace(",", "")) == Decimal(str(approval["value"]))
    session = date(2026, 11, 4)
    assert max(prices) == date(2026, 11, 3) and session not in prices
    prices[session] = float(price)
    cal = model.calendar()
    assert all(model.b.close_at(cal, day) < CUTOFF for day in prices)
    assert all(model.d.release_at(day) < CUTOFF for day in yields)
    assert model.b.close_at(cal, model.DATES[DAY]).isoformat() == "2026-11-12T21:00:00+00:00"
    # Use existing fit, Friday-origin training rules and audited lag without any parameter selection.
    model.write(out / "processed_prices.csv", [{"date":d,"SP500":v} for d,v in sorted(prices.items())])
    model.write(out / "processed_yields.csv", [{"date":d,"DGS10":v} for d,v in sorted(yields.items())])
    result = model.predict(prices, yields, DAY)
    inputs, forecasts, train_c, train_d, exclusions, _ = result
    calculated = model.now()
    assert inputs["base_date"] == session and inputs["horizon_sessions"] == 6
    assert len(train_c) == len(train_d) and not exclusions
    for source in sources:
        source['last_observation_used_by_models'] = ({m: str(session) for m in 'ABCD'} if source['file']=='yahoo.html' else {'D':str(inputs['yield_date'])} if source['file']=='dgs10.csv' else {m:str(max(d for d in prices if d<session)) for m in 'ABCD'} if source['file']=='sp500.csv' else {})
        if source['file']=='yahoo.html': source['role']='approved daily Close supplement'
    source_by_file = {s["file"]: s for s in sources}
    audit = []
    for series, values in [("SP500", prices), ("DGS10", yields)]:
        for day, value in values.items():
            raw = ("yahoo.html" if day == session else "sp500.csv") if series == "SP500" else "dgs10.csv"
            source = source_by_file[raw]
            equity = series == "SP500"
            audit.append({"dataset":series, "observation_date":day, "value":value,
                          "observation_close_UTC":model.b.close_at(cal, day).isoformat() if equity else None,
                          "yield_lag_proxy":None if equity else model.d.release_at(day).isoformat(),
                          "first_publication_UTC":None, "source_file":raw, "source_sha256":source["sha256"],
                          "observed_by_UTC":source["retrieved_utc"], "eligible_at_noon":True})
    model.write(out / "cutoff_eligibility_audit.csv", audit)
    # Check chronological inclusion against an independently enumerated exchange-session sample.
    sessions = [t.date() for t in cal.sessions]
    expected = []
    for target in sorted(prices):
        origin = target - timedelta(days=7)
        if origin.weekday() != 4 or origin < model.b.START:
            continue
        prior = [s for s in sessions if model.b.close_at(cal, s) < model.b.origin_at(origin)]
        if len(prior) < 21 or prior[-21] not in prices:
            continue
        if sessions.index(target) - sessions.index(prior[-1]) == 6 and model.b.close_at(cal,target) < CUTOFF:
            expected.append((origin, target))
    for train in [train_c, train_d]:
        assert [(r["origin"],r["target_date"]) for r in train] == expected
        assert all(model.b.close_at(cal,r["target_date"]) <= datetime.fromisoformat(source_by_file["sp500.csv"]["retrieved_utc"]) < CUTOFF for r in train)
    checks, independent = model.validate(prices, yields, DAY, result)
    for f, r in zip(forecasts, independent):
        assert f["model"] == r["model"] and Decimal(r["decimal_forecast"]).quantize(Decimal(".01")) == Decimal(f["forecast_level"])
        f.update(status="VALIDATED_CANDIDATE", issued=False, intended_origin=CUTOFF.isoformat(),
                 calculated_utc=calculated.isoformat(), target=inputs["target_close_utc"])
    # Run negative controls through the actual admission rule.
    assert not stamp_is_eligible(CUTOFF + timedelta(microseconds=1))
    assert not stamp_is_eligible(datetime(2026,11,5,11,30))
    try:
        check_source(PREP / "yahoo.html", dict(source_by_file["yahoo.html"], sha256="invalid"))
    except ValueError:
        pass
    else:
        raise AssertionError("Corrupt source would be admitted")
    model.write(out / "forecasts.csv", forecasts)
    model.dump(out / "forecasts.json", forecasts)
    model.dump(out / "model_inputs.json", inputs)
    model.write(out / "independent_checks.csv", independent)
    model.write(out / "training_C.csv", train_c)
    model.write(out / "training_D.csv", train_d)
    model.dump(out / "source_extraction.json", {"Yahoo_daily_row":yahoo, "FT_daily_row":ft, "selected_column":"Close"})
    model.dump(out / "source_manifest.json", {"frozen_capture":str(PREP),"capture_manifest_sha256":model.sha(PREP/"SHA256.json"),"sources":sources})
    shutil.copy2(TRIAL / "preparation/fallback_approval.json", out / "candidate_source_approval.json")
    model.dump(out / "model_versions.json", {str(p):model.sha(p) for p in [Path(__file__),Path(model.__file__),model.HIST/"src/run_backtest.py",model.HIST/"treasury_extension/calculate.py"]})
    prior = load(TRIAL / 'preparation/prior_trials_hashes.json')
    assert all(model.sha(ROOT / name)==digest for name,digest in prior.items())
    model.dump(out / 'earlier_trials_preservation.json', {'verified_files':len(prior),'all_unchanged':True,'verified_utc':model.now()})
    suites = run_tests(out)
    assert all(model.sha(ROOT / name)==digest for name,digest in prior.items())
    finished = model.now()
    model.dump(out / "validation_results.json", {"information_cutoff":CUTOFF,"candidate_started":started,
               "candidate_calculated":calculated,"validation_finished":finished,"latest_input_retrieval":latest_capture,
               "tests":suites,"trial_specific_checks":checks,"negative_controls_passed":["late retrieval","naive timestamp","hash mismatch"],
               "independent_training_membership":"PASS","independent_forecasts_2dp":"all match","matured_rows":len(train_c),
               "latest_matured_target":train_c[-1]["target_date"],"approved_for_candidate_calculation":True,
               "formal_issue_approval":False,"issued":False,"historical_vintage_certification":False})
    lines = ["# Trial 4 candidate forecasts", "",
             f"The target is the official S&P 500 price-index close on 12 November at 21:00 GMT. All source responses were retrieved by {latest_capture.isoformat()}. The information cutoff was {CUTOFF.isoformat()}. Calculations ran from {started.isoformat()} to {calculated.isoformat()}. Validation completed at {finished.isoformat()}. Formal issuance requires a separate user decision.", "",
             "| Model | Candidate level | Full-precision level |", "|---|---:|---:|"]
    lines += [f"| {f['model']} | {f['forecast_level']} | {f['forecast_full_precision']!r} |" for f in forecasts]
    lines += ["", f"FRED's price series ended 3 November. The approved Yahoo 4 November Close of 7,688.62 matches FT. All models use that baseline. The 20-session lookback is {inputs['lookback_date']} at {inputs['lookback_level']}, giving momentum {inputs['momentum']:.8%}. D uses the 3 November DGS10 yield of 4.95% and the 27 October yield of 4.99%, a change of −0.04 percentage points. Its endpoint publication proxy is 4 November 16:15 New York.",
              "", f"The exchange calendar places six sessions between baseline and target. C/D used {len(train_c)} matured Friday-origin rows through the {train_c[-1]['target_date']} outcome. The independent membership reconstruction, Decimal checks, future poisoning, unmatured-label exclusion, truncated-history comparison, negative availability controls and all five established test suites passed.",
              "", "Source timestamps establish an observed-by bound at this trial cutoff. Exact first publication, intraday Treasury observation time and historical feature vintages remain unverified. Local checksums detect changes and depend on the recorded clock. The Trial 4 instructions authorize a post-noon calculation and require approval before issue. Under the earlier pre-noon issuance convention, a later issue would be classified as late."]
    (out / "REPORT.md").write_text("\n".join(lines)+"\n")
    (out / "README.md").write_text(f"Candidate computation is reproducible offline from {PREP}. From the project root run PYTHONDONTWRITEBYTECODE=1 /opt/anaconda3/bin/python3.14 research/live_trials/2026-11-05/validate_candidates.py after the cutoff. A new directory records the actual rerun time. SHA256.json covers this candidate package. Review REPORT.md, forecasts.csv, model_inputs.json, cutoff_eligibility_audit.csv, validation_results.json and independent_checks.csv. Source responses are in the separate preparation package. An issued record requires separate approval.\n")
    model.dump(out / "SHA256.json",{str(p.relative_to(out)):model.sha(p) for p in out.rglob("*") if p.is_file()})
    for name, digest in load(out / "SHA256.json").items():
        assert model.sha(out / name) == digest
    for path in out.rglob("*"):
        if path.is_file():
            path.chmod(0o444)
    (out/"test_logs").chmod(0o555)
    out.chmod(0o555)
    print(out)
    print([(r["model"], r["forecast_level"]) for r in forecasts])

if __name__ == "__main__":
    main()

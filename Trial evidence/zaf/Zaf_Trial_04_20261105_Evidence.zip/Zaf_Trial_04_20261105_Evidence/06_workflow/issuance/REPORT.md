# Trial 4 issued forecasts

Information cutoff: 5 November 2026, 12:00 GMT. Target: official S&P 500 price-index close on 12 November 2026, 21:00 GMT.

Actual issuance: 2026-11-05T12:05:32.541792+00:00. Approval recorded: 2026-11-05T12:05:32.440155+00:00. Calculation completed: 2026-11-05 12:00:01.109871+00:00. Validation completed: 2026-11-05 12:00:19.628362+00:00.

| Model | Issued level |
|---|---:|
| A | 7,688.62 |
| B | 7,660.74 |
| C | 7,697.25 |
| D | 7,707.16 |

All four use the approved Yahoo 4 November historical Close of 7,688.62, corroborated by FT and captured before noon. FRED ends 3 November. Momentum uses 7 October at 7,801.77. D uses 3 November DGS10 4.95% minus 27 October 4.99%, with the existing conservative release lag. The six-session target alignment is unchanged. C/D have 198 matured Friday-origin rows through the 30 October outcome, with unchanged specifications and estimation rules.

All 36 established tests, independent Decimal rounded forecasts, maturity, chronology, poisoning, truncated-history and negative-availability checks passed. 1853 earlier-trial files remain unchanged. Exact first publication and historical vintages are unverified. Test logs retain non-failing pandas deprecation and resource warnings.

Issued after noon under the requested Trial 4 protocol, not before noon. Under the earlier before-noon issuance convention this is late. No future accuracy has been calculated. No binding 13 November forecast was produced.

Copied preparation/candidate evidence retains its original historical pending/unissued labels. This issuance record is authoritative for formal status. Read-only files and SHA-256 hashes protect against accidental changes, not owner-level tampering. The separate issuance receipt records the actual final freeze verification time.

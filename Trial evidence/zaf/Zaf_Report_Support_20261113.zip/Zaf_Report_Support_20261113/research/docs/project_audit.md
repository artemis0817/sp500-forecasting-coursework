# Project inspection and corrections

Every initial file was inventoried with size and SHA-256 in `initial_inventory.json`. The Word brief was extracted in full. Both CSVs, README and Python source were inspected. `.DS_Store` and the Python 3.13 bytecode cache were identified as generated binary metadata, not financial evidence; their hashes were recorded, and they were not executed. No AGENTS.md was found in the parent-folder search.

| Finding | Resolution / status |
|---|---|
| Script has a numpy dependency, only informally documented; no environment lock | Numpy was installed already. New code also requires pandas and exchange_calendars. Project-local packages and exact versions recorded. |
| No exchange calendar; silently skips absent dates | Validate complete expected XNYS sessions; reject missing trading dates. Holidays/early closes saved explicitly; no filling. |
| Claimed six-session regression actually fits heterogeneous holiday horizons | Primary estimates only six-session weekly outcomes. Separate holiday panel explicitly scales C by h/6. |
| “Noon London” varies in summer; requested origins are noon GMT | Use timezone-aware 12:00 UTC throughout. Both precede US regular trading, so this wording correction does not change baseline dates. |
| Market-close availability confused with FRED publication availability | Do not certify historical FRED point-in-time availability. Preserve current update time, label public-market-close assumption and run a delayed-input scenario. |
| Raw downloads and retrieval times not saved | Save original bytes, source URL, UTC retrieval timestamp, HTTP metadata and hashes. |
| Requested five years not enforced by original download | New sample starts 2021-10-30, with first session 2021-11-01. Original legacy run is passed this same five-year CSV. |
| Permissive input silently drops malformed values, overwrites duplicates, allows nonfinite/nonpositive values | New parser rejects invalid/duplicate numeric records; calendar validation detects missing rows. |
| At least 104 origins is not enough in every boundary case due to an unmatured previous target; original silently skips failed fits | New fit fails loudly if fewer than 52 matured training outcomes. All panels have 52 rows and sufficient prior history. |
| CLI --test-origins accepts invalid counts | Corrected research protocol fixes count at 52; no free count parameter or coefficient tuning. |
| Score formula correct, but original did not round individual scores to two decimals | New per-origin coursework score is rounded to two decimals; summary is mean of rounded individual scores. |
| Existing seven-week CSVs lack provenance | All 14 baseline/actual pairs match new FRED data. Seven lookback dates and fixed predictions match to displayed precision. Their earlier provenance and availability remain unverified. |
| FRED CSV latest date differs from HTML | All three CSV endpoints stop 28 October. Preserve them; supplement 29 October only from saved FRED HTML. No 30 October price invented. |
| No unit tests / uncertainty / failure detail | Six tests, independent Decimal recomputation, scalar OLS checks, future perturbation, block-bootstrap and worst forecasts saved. |
| Seven historical examples already seen | Holdout is sequential out-of-sample for estimation, not wholly unseen by the researcher. Protocol fixed before full evaluation; do not claim preregistration. |

The original script ran successfully on saved inputs; its A/B predictions exactly reproduce the secondary panel. Its C differs because it mixes horizons. The original numerical examples were not fabricated on the evidence available: current FRED values agree. The correct criticism is missing original provenance and a small selected sample, not demonstrated false prices.

Environment notes: the first network attempt failed in the sandbox; the approved retry succeeded. The first package download also hit network restrictions. Installation into `research/vendor` succeeded. Pip reported conflicts with unrelated globally installed numba/botocore packages; no global packages were changed, and the backtest imports neither. The calendar stack emits a pandas timezone-array deprecation warning; explicit UTC timestamp assertions passed. Initial test code left read handles open; this was corrected and the six tests rerun successfully. Original files remain unchanged.

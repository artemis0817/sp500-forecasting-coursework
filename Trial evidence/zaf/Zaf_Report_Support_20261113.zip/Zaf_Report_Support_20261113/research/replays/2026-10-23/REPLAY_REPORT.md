# Historical replay for 23 October 2026

This retrospective calculation uses the existing models without retuning. It is not a forecast actually issued on 23 October and does not generate the binding November forecast. The original 52-origin evaluation and model specifications remain unchanged.

Origin: **2026-10-23T12:00:00+01:00**, equivalent to 2026-10-23T11:00:00+00:00 and 2026-10-23T07:00:00-04:00. Target: **30 October 2026 official S&P 500 price-index close**, 2026-10-30T20:00:00+00:00 (16:00 New York; 20:00 London, following the UK clock change). There are **six exchange sessions** from the baseline to the target: 23, 26, 27, 28, 29 and 30 October.

## Inputs and forecasts

Latest eligible price: **22 October 2026, 7,663.43**, from the saved FRED SP500 CSV. That session closed at 2026-10-22T20:00:00+00:00, 15 hours before the cutoff. The 20-session lookback is **2026-09-24**, price **7,704.13**. Momentum is -0.005282880741, or **-0.52828807%**.

A uses the unchanged baseline. B uses F=P(1+0.25m). C uses F=P(1+a+bm), with the existing intercept-plus-momentum expanding OLS specification, exactly six-session weekly training labels and the original five-year start boundary.

C used **196 matured training observations**. The latest included target is **2026-10-16**. The 23 October closing outcome is excluded because it was still in the future at that day's noon cutoff. Every included feature and target close timestamp is recorded in `training_rows.csv`.

- Intercept a: **0.001705009144** in decimal return units.
- Momentum slope b: **0.029349573612**, multiplying decimal 20-session momentum.
- Forecast return a+bm: **0.001549958847**, or **0.15499588%**.

## Scoring after forecast generation

Scoring uses **7,580.07**, the actual supplied by the user. It has not been independently verified against S&P DJI in this replay, and was not added to the saved market data or supplied to the forecasting function. The JSON forecast record was saved and hashed before the script introduced this scoring value. This procedural separation does not claim that the user-supplied outcome was unknown to the analyst; the unchanged specifications determine the forecast.

| Model | Forecast | APE | Marks deducted | Score /50 |
|---|---:|---:|---:|---:|
| A | 7,663.43 | 1.099726% | 5.498630 | 44.50 |
| B | 7,653.31 | 0.966202% | 4.831008 | 45.17 |
| C | 7,675.31 | 1.256426% | 6.282132 | 43.72 |

APE = 100 × |F−actual| / actual. Deduction = min(50, 5×APE). Score = round(50−deduction, 2). Calculations use full-precision forecasts, with two-decimal levels shown only for presentation, consistent with the existing backtest. Only the final score is rounded for marking; the deduction above retains six decimal places.

## Independent verification and sample membership

A separate Decimal calculation rebuilt weekly training data directly from the raw CSV, estimated intercept/slope through centered sums, and recomputed all forecasts, errors, deductions and rounded scores. All matched: forecast tolerance 1e−8 index points; APE/deduction tolerance 1e−10. Altering all prices dated on/after 23 October and inserting an extreme target-date test value left forecasts and coefficients unchanged. Original specification/code/evaluation files were hash-checked unchanged.

**This origin is not in the existing 52-origin primary evaluation sample**, which ends at origin 16 October and target 23 October. It is also absent from the holiday and delayed panels. The original saved data lacked the 30 October actual, so this origin could not be scored then. This replay is saved separately and does not append or reselect the 52-origin sample.

## Remaining data timing limitations

The input CSV was retrieved on 31 October, so this is a reconstruction from current-vintage historical values. Exchange close times show the relevant market sessions had ended, but do not prove that the specific FRED observations and their exact retrieved vintages were available at the historical cutoff. Historical intraday FRED release timestamps and revisions remain unverified for both feature prices and training outcomes. Therefore the replay is conditional on prior official-close availability, not a certified historical FRED-only replay. The user-supplied scoring value is separately labelled, not claimed to be independently authenticated official evidence.

Source: FRED SP500, https://fred.stlouisfed.org/series/SP500 ; original source URL, retrieval timestamp and raw SHA-256 remain in `research/data/raw/fred_SP500.csv.metadata.json`. The calendar uses the project's pinned exchange_calendars XNYS schedule. No new financial data were downloaded or substituted.

## Reproduce

From the project root: `python3 research/src/replay_2026_10_23.py`. The script imports the existing model helpers, builds training using only the truncated input history, freezes forecasts and then scores them. Results, frozen forecast, training ledger, filtered inputs, validation and a specification snapshot are saved in this directory.

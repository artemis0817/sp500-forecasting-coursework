# October comparison evidence

Read `REPORT.md` for the five-week table, monthly summary, coefficients, timing, overlap, interpretation and limitations.

Run from the project root:

```sh
MPLCONFIGDIR=/tmp/sp500-october-mpl python3 research/october_comparison/calculate.py
```

Outputs:
- `weekly_comparison.csv`: 15 model/week rows, full-precision forecasts, actuals, errors, deductions, scores and marks differences versus A.
- `monthly_summary.csv`: conditional five-week comparison, including wins and beat rates.
- `verified_four_week_summary.csv`: aggregate excluding the unverified 30 October actual.
- `comparison_with_52.csv`: comparison against the unchanged primary 52-origin evaluation.
- `forecasts_frozen_before_scoring.csv`: timing, baselines, lookbacks, coefficients, training counts and sample membership.
- `training_ledger.csv`: each eligible training row at each of the five origins.
- `figures/weekly_errors.png` and `.svg`: line chart, with unverified fifth observation marked.
- `sources/` and `source_verification.csv`: original raw copies, metadata, live source check and level reconciliation.
- `validation/`: independent Decimal calculations, monthly aggregate checks, leakage checks and software versions.
- `inputs/`: each cutoff's truncated price history and unchanged specification snapshot.

The first four targets are already in the 52-origin sample. The fifth uses the prior user-supplied actual of 7,580.07, which has not been verified against FRED or S&P DJI. It was previously examined in the separate replay. Do not describe this month as independent validation. Historical FRED release timestamps and revisions remain unresolved. No November forecast is produced.

#!/usr/bin/env python3
"""Five fixed-spec October replays, independent arithmetic and saved research figures."""
from pathlib import Path
import sys,csv,io,json,hashlib,shutil,statistics
from datetime import date,timedelta,datetime,timezone
from decimal import Decimal,localcontext,ROUND_HALF_EVEN
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
sys.path.insert(0,str(ROOT/'src'))
import run_backtest as b

def read(p):return list(csv.DictReader(io.StringIO(p.read_text())))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,rows):b.write_csv(OUT/name,rows)
TARGETS=[date(2026,10,d) for d in [2,9,16,23,30]]

def predict(raw,target,cal):
    origin=target-timedelta(days=7);stamp=b.origin_at(origin)
    history={date.fromisoformat(r['observation_date']):float(r['SP500']) for r in raw
        if r['SP500'] not in ('','.') and b.START<=date.fromisoformat(r['observation_date'])<origin}
    assert all(b.close_at(cal,d)<stamp for d in history)
    history=dict(sorted(history.items()));x=b.forecast_inputs(history,cal,origin,target)
    candidates,_=b.build(history,cal)
    train=[z for z in candidates if z['horizon_sessions']==6 and b.training_eligibility(z,origin,cal)[0]]
    coef,_=b.fit(train);er=float(coef[0]+coef[1]*x['momentum'])
    assert x['horizon_sessions']==6
    return history,x,train,coef,er,{'A':x['base'],'B':x['base']*(1+.25*x['momentum']),'C':x['base']*(1+er)}

def monthly(rows,label):
    result=[]
    for m in 'ABC':
        mine=[r for r in rows if r['model']==m];baseline={r['target_date']:r for r in rows if r['model']=='A'}
        es=[r['APE_percent'] for r in mine];deltas=[r['accuracy_score']-baseline[r['target_date']]['accuracy_score'] for r in mine]
        wins=sum(r['APE_percent']==min(s['APE_percent'] for s in rows if s['target_date']==r['target_date']) for r in mine)
        result.append({'sample':label,'model':m,'n':len(mine),'MAPE_percent':statistics.mean(es),
            'median_APE_percent':statistics.median(es),'maximum_APE_percent':max(es),
            'mean_accuracy_score':statistics.mean(r['accuracy_score'] for r in mine),'lowest_error_weeks':wins,
            'beat_A_percent':100*sum(r['APE_percent']<baseline[r['target_date']]['APE_percent'] for r in mine)/len(mine),
            'mean_marks_difference_vs_A':statistics.mean(deltas),'total_marks_difference_vs_A':sum(deltas)})
    return result

def main():
    for d in ['inputs','sources','validation','figures']:(OUT/d).mkdir(exist_ok=True)
    protected=[ROOT/'src/run_backtest.py',ROOT/'docs/model_specifications.md']+list((ROOT/'results').rglob('*.csv'))
    protected_hashes={str(p.relative_to(ROOT)):sha(p) for p in protected}
    rawpath=ROOT/'data/raw/fred_SP500.csv';raw=read(rawpath)
    fullpath=ROOT/'data/raw/fred_SP500_full.csv';full=read(fullpath)
    numeric=lambda rr:{date.fromisoformat(r['observation_date']):r['SP500'] for r in rr if r['SP500'] not in ('','.')}
    prices=numeric(raw);second=numeric(full)
    # Independently retrieved original endpoint consistency; not an independent provider.
    agreement=[{'date':d,'main_CSV_value':v,'full_endpoint_value':second.get(d,''),'match':v==second.get(d)} for d,v in prices.items()]
    assert all(r['match'] for r in agreement)
    write('validation/all_raw_prices_crosscheck.csv',agreement)
    for p in [rawpath,fullpath,ROOT/'data/raw/fred_SP500.csv.metadata.json',ROOT/'data/raw/fred_SP500_full.metadata.json']:
        shutil.copy2(p,OUT/'sources'/p.name)
    shutil.copy2(ROOT/'docs/model_specifications.md',OUT/'inputs/model_specifications.md')
    shutil.copy2(ROOT/'validation/environment.json',OUT/'inputs/environment.json')
    saved=read(ROOT/'results/primary_forecasts.csv');included={r['origin'] for r in saved}
    cal=b.xc.get_calendar('XNYS',start=str(b.START),end=str(b.CUT))
    frozen=[];ledger=[];forecastmap={};checks=[]
    for target in TARGETS:
        history,x,train,c,er,f=predict(raw,target,cal);origin=target-timedelta(days=7)
        forecastmap[target]=f
        frozen.append({'origin_date':origin,'origin_London':x['origin_london'],'origin_UTC':x['origin_utc'],
            'origin_New_York':x['origin_new_york'],'baseline_date':x['base_date'],'baseline_level':x['base'],
            'baseline_close_UTC':x['feature_close_utc'],'lookback_date':x['lookback_date'],
            'lookback_price':history[x['lookback_date']],'momentum_decimal':x['momentum'],
            'target_date':target,'target_close_UTC':x['target_close_utc'],'horizon_sessions':6,
            'training_n':len(train),'latest_training_target':max(z['target_date'] for z in train),
            'C_intercept':float(c[0]),'C_slope':float(c[1]),'C_forecast_return':er,
            'in_original_52':str(origin) in included,**{m+'_forecast':f[m] for m in 'ABC'}})
        write(f'inputs/prices_before_{origin}.csv',[{'date':d,'SP500':v} for d,v in history.items()])
        for t in train:
            assert b.close_at(cal,t['target_date'])<b.origin_at(origin)
            ledger.append({'fitting_origin':origin,'fitting_cutoff':x['origin_london'],
                'training_origin':t['origin'],'feature_date':t['base_date'],'lookback_date':t['lookback_date'],
                'feature_close_UTC':b.close_at(cal,t['base_date']).isoformat(),'target_date':t['target_date'],
                'target_close_UTC':b.close_at(cal,t['target_date']).isoformat(),
                'momentum':t['momentum'],'return':t['return'],'eligible':True})
        # Adversarial current-Friday and future prices, before any scoring actual is introduced.
        attack=[dict(r,SP500='999999.99') if r['observation_date']>=str(origin) and r['SP500'] not in ('','.') else r for r in raw]
        attacked=predict(attack,target,cal)
        assert attacked[-1]==f and (attacked[-3]==c).all()
        if str(origin) in included:
            prior=next(r for r in saved if r['origin']==str(origin))
            assert all(abs(float(prior[m+'_forecast'])-f[m])<1e-9 for m in 'ABC')
        checks.append({'origin':str(origin),'future_price_poisoning':'PASS','all_targets_matured':'PASS',
            'original_52_match':'PASS' if str(origin) in included else 'not in sample'})
    write('forecasts_frozen_before_scoring.csv',frozen);freeze_hash=sha(OUT/'forecasts_frozen_before_scoring.csv')
    write('training_ledger.csv',ledger)
    # ONLY now load evaluation outcomes. The fifth reference is explicitly user-supplied.
    user_reference=json.loads((ROOT/'replays/2026-10-23/scoring_reference.json').read_text())
    actuals={t:Decimal(prices[t]) if t in prices else Decimal(user_reference['actual']) for t in TARGETS}
    provenance=[];result=[];independent=[]
    for target,row in zip(TARGETS,frozen):
        origin=target-timedelta(days=7);f=forecastmap[target];actual=actuals[target]
        verified=target in prices
        provenance.append({'role':'target','date':target,'value':str(actual),
            'status':'matches both original FRED downloads' if verified else 'UNVERIFIED against original sources; prior user-supplied value',
            'source':'fred_SP500.csv and fred_SP500_full.csv' if verified else 'prior chat and replay scoring_reference.json'})
        for key in ['baseline','lookback']:
            d=row['baseline_date' if key=='baseline' else 'lookback_date'];v=row['baseline_level' if key=='baseline' else 'lookback_price']
            assert Decimal(str(v))==Decimal(prices[d])==Decimal(second[d])
            provenance.append({'role':key,'date':d,'value':str(v),'status':'matches both original FRED downloads',
                'source':'fred_SP500.csv and fred_SP500_full.csv'})
        for m in 'ABC':
            e=b.ape(f[m],float(actual));deduction=min(50.,5*e)
            result.append({'model':m,**{k:row[k] for k in ['origin_date','origin_London','origin_UTC','baseline_date','baseline_level','target_date','target_close_UTC','in_original_52']},
                'forecast':f[m],'actual':float(actual),'actual_source_verified':verified,'APE_percent':e,
                'marks_deducted':deduction,'accuracy_score':b.score(e)})
        # Independent Decimal reconstruction; no production feature or label fields reused.
        with localcontext() as ctx:
            ctx.prec=40;p={d:Decimal(v) for d,v in prices.items() if b.START<=d<origin};days=sorted(p)
            base=days[-1];mom=p[base]/p[days[-21]]-1;xy=[]
            for end in days:
                if end.weekday()!=4:continue
                o=end-timedelta(days=7);prior=[d for d in days if d<o]
                if len(prior)<21:continue
                bd=prior[-1];j=days.index(bd)
                if len(cal.sessions_in_range(str(bd),str(end)))-1!=6:continue
                xy.append((p[bd]/p[days[j-20]]-1,p[end]/p[bd]-1))
            xm=sum(x for x,y in xy)/len(xy);ym=sum(y for x,y in xy)/len(xy)
            beta=sum((x-xm)*(y-ym) for x,y in xy)/sum((x-xm)**2 for x,y in xy);alpha=ym-beta*xm
            assert len(xy)==row['training_n']
            assert abs(float(alpha)-row['C_intercept'])<1e-12 and abs(float(beta)-row['C_slope'])<1e-12
            ip={'A':p[base],'B':p[base]*(1+Decimal('.25')*mom),'C':p[base]*(1+alpha+beta*mom)}
            for m,pred in ip.items():
                e=100*abs(pred-actual)/actual;deduct=min(Decimal(50),5*e);score=(50-deduct).quantize(Decimal('.01'),rounding=ROUND_HALF_EVEN)
                rr=next(r for r in result if r['model']==m and r['target_date']==target)
                assert abs(float(pred)-rr['forecast'])<1e-8 and abs(float(e)-rr['APE_percent'])<1e-10
                assert float(score)==rr['accuracy_score']
                independent.append({'target':target,'model':m,'forecast_decimal':str(pred),'APE_decimal':str(e),
                    'deduction_decimal':str(deduct),'score_decimal':str(score),'status':'PASS'})
    for r in result:
        a=next(z for z in result if z['target_date']==r['target_date'] and z['model']=='A')
        r['marks_difference_vs_A']=r['accuracy_score']-a['accuracy_score']
    write('weekly_comparison.csv',result);write('source_verification.csv',provenance)
    write('validation/independent_decimal_checks.csv',independent);write('validation/leakage_checks.csv',checks)
    summary=monthly(result,'October five weeks; conditional on supplied 30-Oct actual')
    verified_summary=monthly([r for r in result if r['actual_source_verified']],'Four FRED-verified targets only')
    write('monthly_summary.csv',summary);write('verified_four_week_summary.csv',verified_summary)
    original=[r for r in read(ROOT/'results/summary.csv') if r['panel']=='primary_six_sessions']
    comparisons=[]
    for r,orig in zip(summary,original):
        comparisons.append({'model':r['model'],'October_MAPE':r['MAPE_percent'],'original_52_MAPE':float(orig['MAPE_pct']),
            'MAPE_difference':r['MAPE_percent']-float(orig['MAPE_pct']),'October_mean_score':r['mean_accuracy_score'],
            'original_52_mean_score':float(orig['mean_accuracy_score_of_50']),
            'October_beat_A_percent':r['beat_A_percent'],'original_52_beat_A_percent':float(orig['beat_A_pct'])})
    write('comparison_with_52.csv',comparisons)
    # Independent aggregate verification using Decimal per-week errors and rounded scores.
    for s in summary:
        rr=[x for x in independent if x['model']==s['model']];es=[Decimal(x['APE_decimal']) for x in rr]
        assert abs(float(sum(es)/len(es))-s['MAPE_percent'])<1e-10
        assert abs(float(statistics.median(es))-s['median_APE_percent'])<1e-10
        assert abs(float(max(es))-s['maximum_APE_percent'])<1e-10
        assert abs(float(sum(Decimal(x['score_decimal']) for x in rr)/len(rr))-s['mean_accuracy_score'])<1e-12
        by_target={x['target']:{y['model']:y for y in independent if y['target']==x['target']} for x in rr}
        wins=sum(Decimal(x['APE_decimal'])==min(Decimal(z['APE_decimal']) for z in by_target[x['target']].values()) for x in rr)
        beats=sum(Decimal(x['APE_decimal'])<Decimal(by_target[x['target']]['A']['APE_decimal']) for x in rr)
        deltas=[Decimal(x['score_decimal'])-Decimal(by_target[x['target']]['A']['score_decimal']) for x in rr]
        assert wins==s['lowest_error_weeks'] and 100*beats/len(rr)==s['beat_A_percent']
        assert abs(float(sum(deltas)/len(rr))-s['mean_marks_difference_vs_A'])<1e-12
        assert abs(float(sum(deltas))-s['total_marks_difference_vs_A'])<1e-12
    assert sha(OUT/'forecasts_frozen_before_scoring.csv')==freeze_hash
    assert all(sha(ROOT/k)==v for k,v in protected_hashes.items())
    metadata={'execution_time_UTC':datetime.now(timezone.utc).isoformat(),'raw_source_metadata':'sources/fred_SP500.csv.metadata.json',
        'raw_sha256':sha(rawpath),'second_endpoint_sha256':sha(fullpath),'model_code_sha256':sha(ROOT/'src/run_backtest.py'),
        'audited_model_code':'research/src/run_backtest.py','specification_sha256':sha(ROOT/'docs/model_specifications.md'),
        'forecast_freeze_sha256':freeze_hash,'30_October_reference':user_reference,
        'current_FRED_check':'sources/fred_live_check.json; page latest observation 29 October; 30 October not independently verified',
        'historical_FRED_release_and_revision_timing':'UNVERIFIED','training_rows_audited':len(ledger),
        'source_crosschecked_numeric_records':len(agreement),'overlap_with_original_52':4}
    (OUT/'sources/source_metadata.json').write_text(json.dumps(metadata,indent=2))
    (OUT/'validation/checks.json').write_text(json.dumps({'independent_predictions_and_scores':f'{len(independent)}/15 PASS',
        'independent_monthly_aggregates':'PASS','future_price_poisoning':'5/5 PASS','matured_training_labels':'PASS',
        'four_existing_backtest_forecasts_match':'PASS','original_models_and_results_unchanged':'PASS',
        'target_actuals_source_verified':'4/5; 30 October unverified','data_vintage_certified':False},indent=2))
    make_outputs(result,summary,verified_summary,frozen,comparisons)
    print(json.dumps(summary,indent=2));print('Verified four-week summary:',json.dumps(verified_summary,indent=2))
    (OUT/'manifest.json').write_text(json.dumps([{'path':str(p.relative_to(OUT)),'sha256':sha(p)} for p in sorted(OUT.rglob('*'))
        if p.is_file() and p.name not in ['manifest.json','execution_log.txt']],indent=2))

def make_outputs(result,summary,verified_summary,frozen,comparisons):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(10.5,5.7))
    colors={'A':'#335C81','B':'#C05B23','C':'#387D58'}
    for m in 'ABC':
        ys=[r['APE_percent'] for r in result if r['model']==m]
        ax.plot(range(5),ys,marker='o',linewidth=2,color=colors[m],label={'A':'A · Unchanged price','B':'B · Fixed momentum','C':'C · Expanding regression'}[m])
    ax.axvspan(3.5,4.4,color='#F5E9CA',alpha=.7,zorder=-1)
    ax.set_xticks(range(5),['2 Oct','9 Oct','16 Oct','23 Oct','30 Oct*']);ax.set_xlim(-.15,4.25)
    ax.set_ylim(bottom=0);ax.set_ylabel('Absolute percentage error (%)');ax.set_xlabel('Forecast target date in 2026')
    ax.set_title('S&P 500 weekly forecast errors in October',loc='left',fontsize=15,pad=16)
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.2);ax.legend(loc='upper left',frameon=False,fontsize=10)
    fig.text(.09,.025,'*30 Oct uses the supplied actual of 7,580.07; not verified against FRED. Four weeks overlap the 52-origin sample.',fontsize=9)
    fig.tight_layout(rect=(0,.07,1,1));fig.savefig(OUT/'figures/weekly_errors.png',dpi=180);fig.savefig(OUT/'figures/weekly_errors.svg');plt.close(fig)
    def table(headers,rr):return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+'\n'.join('| '+' | '.join(str(v) for v in row)+' |' for row in rr)
    weekly=table(['Target','Origin London noon','Baseline date / level','Model','Forecast','Actual','APE %','Deduction','Score /50'],[
        [r['target_date'],str(r['origin_date'])+' 12:00 BST',str(r['baseline_date'])+f" / {r['baseline_level']:,.2f}",r['model'],f"{r['forecast']:,.2f}",f"{r['actual']:,.2f}"+(' *' if not r['actual_source_verified'] else ''),f"{r['APE_percent']:.4f}",f"{r['marks_deducted']:.4f}",f"{r['accuracy_score']:.2f}"] for r in result])
    summ=table(['Model','MAPE %','Median %','Maximum %','Mean score /50','Lowest-error weeks','Beat A','Mean marks vs A','Total marks vs A'],[
        [r['model'],f"{r['MAPE_percent']:.4f}",f"{r['median_APE_percent']:.4f}",f"{r['maximum_APE_percent']:.4f}",f"{r['mean_accuracy_score']:.3f}",r['lowest_error_weeks'],('—' if r['model']=='A' else f"{r['beat_A_percent']:.0f}%"),f"{r['mean_marks_difference_vs_A']:+.3f}",f"{r['total_marks_difference_vs_A']:+.2f}"] for r in summary])
    coefs=table(['Origin','Training n','Latest eligible training target','20-session momentum %','C intercept','C slope','C expected return %','In original 52'],[
        [r['origin_date'],r['training_n'],r['latest_training_target'],f"{100*r['momentum_decimal']:.6f}",f"{r['C_intercept']:.10f}",f"{r['C_slope']:.10f}",f"{100*r['C_forecast_return']:.6f}",r['in_original_52']] for r in frozen])
    compare=table(['Model','October MAPE %','Original 52 MAPE %','October mean score','Original 52 mean score','October / 52 beat A %'],[
        [r['model'],f"{r['October_MAPE']:.4f}",f"{r['original_52_MAPE']:.4f}",f"{r['October_mean_score']:.3f}",f"{r['original_52_mean_score']:.3f}",f"{r['October_beat_A_percent']:.2f} / {r['original_52_beat_A_percent']:.2f}"] for r in comparisons])
    explanations=[]
    for r in frozen:
        actual=next(z['actual'] for z in result if z['target_date']==r['target_date'])
        winner=min((z for z in result if z['target_date']==r['target_date']),key=lambda z:z['APE_percent'])['model']
        explanations.append(f"- **{r['target_date']}: {winner} wins.** Baseline-to-target realised return was {100*(actual/r['baseline_level']-1):+.4f}%; past momentum was {100*r['momentum_decimal']:+.4f}%. B forecast a return of {25*r['momentum_decimal']:+.4f}%, while C forecast {100*r['C_forecast_return']:+.4f}%. These observed directions and sizes explain the ranking arithmetically; they do not establish the cause of the market move.")
    report=f'''# October 2026 S&P 500 model comparison

This retrospective comparison preserves the audited A/B/C specifications and original 52-origin results. It generates no binding November forecast. **Five-week statistics are conditional on the user-supplied 30 October actual of 7,580.07, which remains unverified against the original sources.** Four weeks overlap the original test sample, so October is not an independent out-of-sample evaluation.

## Methods and source verification

Each origin is the preceding Friday at 12:00 Europe/London. All five origins are in BST, equal to 11:00 UTC and 07:00 New York. Each baseline is the preceding Thursday and each horizon contains six US exchange sessions. Targets close at 20:00 UTC; that is 21:00 London for 2–23 October and 20:00 London on 30 October after the UK DST change. Calendar timestamps are saved in the CSVs.

A is unchanged price. B uses F=P(1+0.25m), m=P[t]/P[t−20]−1 in exchange-session intervals. C uses F=P(1+a+bm), with intercept and slope estimated on expanding six-session weekly labels from the existing five-year input boundary. At each origin the price data are truncated first and labels are included only if their target close precedes that origin. No parameter search, revised factor, alternate window or October-driven optimisation is performed. The expanding fit can use earlier October outcomes only once matured; forbidding that would change the existing model.

All baseline levels, lookback levels, historical training input prices and the first four actual target closes were reconciled to both original FRED CSV downloads. Agreement between two FRED endpoints establishes consistency, not independent-provider validation. Source metadata, hashes and raw copies are retained in `sources/`; per-level checks are in `source_verification.csv` and `validation/all_raw_prices_crosscheck.csv`.

The current FRED page still reports 29 October as latest; the original CSV ends 28 October. Neither verifies 30 October. That row therefore uses the previously supplied 7,580.07 only for scoring and is visibly marked (*). No fabricated FRED row is inserted. Four-week source-verified aggregates are also saved separately. Historical intraday FRED publication timestamps and revisions remain unverified: this is a reconstruction conditional on prior official-close availability, not a certified FRED-at-noon vintage replay.

## Five weekly periods

{weekly}

*30 October actual is user-supplied and unverified against the project's original source. Forecasts and coefficients were saved before the scoring reference was read. This separates calculations, but does not claim that the analyst had never seen the historical outcomes. APE=100×|F−actual|/actual; deduction=min(50,5×APE); score=round(50−deduction,2). Use full-precision forecasts for calculations; displayed levels are rounded to two decimals. Scores are averaged after per-week rounding, as in the existing implementation.

## Weekly errors

![Weekly absolute percentage errors](figures/weekly_errors.png)

The shaded fifth point depends on the unverified actual; the preceding four points are already in the 52-origin evaluation.

## Five-week summary

{summ}

A ties itself and is not counted as beating itself. Lowest-error counts include ties if any (none occur here). Marks differences are model score minus A score, using the rounded weekly scores. These are descriptive comparisons for five overlapping-horizon periods, not significance tests.

## Coefficients and overlap

{coefs}

The origins 25 September, 2 October, 9 October and 16 October are already included in the 52-origin primary backtest. The 23 October origin is absent, because the original source snapshot lacked its 30 October target. The replay already examined that outcome separately, so even the fifth row should not be presented as a newly blinded test. No rows were appended to or removed from the original 52-origin evaluation.

## Why the rankings differ by week

{chr(10).join(explanations)}

On 2 October, the index rose modestly: both upward adjustments improved on A, and C's larger upward adjustment was closest. On 9 October, C's positive intercept helped with the rise; B's almost-zero negative momentum adjustment was slightly worse than A. On 16 and 23 October, the index fell despite positive momentum: B extrapolated upward most strongly and performed worst; C's smaller upward adjustment still hurt relative to A. On 30 October, conditional on the supplied actual, negative momentum moved B toward the decline while C's positive intercept outweighed its negative momentum term and pushed its forecast upward.

These are explanations from the model arithmetic and realised values. Trend continuation, reversal, earnings news, macro announcements or changes in risk appetite could be economic hypotheses, but no causal/event attribution was investigated here. In particular, a positive regression intercept can help during rising weeks without demonstrating useful momentum predictability.

## October versus the original 52 origins

{compare}

The comparisons share four observations; differences cannot be interpreted as independent confirmation or a statistically reliable change in performance. C was narrowly best by MAPE in the original 52; A is best on the five October weeks, while B wins the fifth week but has the worst monthly mean. A single winning week does not justify switching to B. The source-verified four-week subset also ranks A first by mean error (see `verified_four_week_summary.csv`), so the provisional choice does not rely on the unverified fifth actual.

**Recommendation: retain Model A as the provisional default, with C as the challenger.** October does not warrant changing coefficients or the model choice. The sample is small, mostly reused and includes an unverified actual. Future refinements require a separately defined development process and genuinely new forward evaluation; do not relabel already inspected October outcomes as independent validation.

## Verification and reproduction

All 15 forecasts and scores were independently rebuilt with Decimal arithmetic from the raw source values, including independently constructed training rows and centered-sum OLS. Monthly means, medians, maxima and average scores were also independently checked. Five future-price poisoning checks passed, all training labels preceded their origins, and the four overlapping forecasts matched saved backtest values exactly within numerical tolerance. All original model/specification/evaluation files passed unchanged-hash checks. Full test outputs are in `validation/`.

Run from the project root: `python3 research/october_comparison/calculate.py`. Existing pinned dependencies live in `research/vendor` and `research/requirements.txt`; chart generation additionally uses matplotlib (version saved in `validation/chart_environment.json`). The script writes only into this output directory. Sources: FRED SP500 https://fred.stlouisfed.org/series/SP500 ; original download https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500 ; XNYS calendar from exchange_calendars. The marking formula is from the supplied UCL IFTE0007 brief already extracted in `research/docs/coursework_extracted.txt`.
'''
    (OUT/'REPORT.md').write_text(report)
    (OUT/'validation/chart_environment.json').write_text(json.dumps({'matplotlib':matplotlib.__version__},indent=2))
if __name__=='__main__':main()

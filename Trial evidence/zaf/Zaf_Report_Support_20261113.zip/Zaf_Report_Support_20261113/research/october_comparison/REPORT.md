# October 2026 S&P 500 model comparison

This retrospective comparison preserves the audited A/B/C specifications and original 52-origin results. It generates no binding November forecast. **Five-week statistics are conditional on the user-supplied 30 October actual of 7,580.07, which remains unverified against the original sources.** Four weeks overlap the original test sample, so October is not an independent out-of-sample evaluation.

## Methods and source verification

Each origin is the preceding Friday at 12:00 Europe/London. All five origins are in BST, equal to 11:00 UTC and 07:00 New York. Each baseline is the preceding Thursday and each horizon contains six US exchange sessions. Targets close at 20:00 UTC; that is 21:00 London for 2–23 October and 20:00 London on 30 October after the UK DST change. Calendar timestamps are saved in the CSVs.

A is unchanged price. B uses F=P(1+0.25m), m=P[t]/P[t−20]−1 in exchange-session intervals. C uses F=P(1+a+bm), with intercept and slope estimated on expanding six-session weekly labels from the existing five-year input boundary. At each origin the price data are truncated first and labels are included only if their target close precedes that origin. No parameter search, revised factor, alternate window or October-driven optimisation is performed. The expanding fit can use earlier October outcomes only once matured; forbidding that would change the existing model.

All baseline levels, lookback levels, historical training input prices and the first four actual target closes were reconciled to both original FRED CSV downloads. Agreement between two FRED endpoints establishes consistency, not independent-provider validation. Source metadata, hashes and raw copies are retained in `sources/`; per-level checks are in `source_verification.csv` and `validation/all_raw_prices_crosscheck.csv`.

The current FRED page still reports 29 October as latest; the original CSV ends 28 October. Neither verifies 30 October. That row therefore uses the previously supplied 7,580.07 only for scoring and is visibly marked (*). No fabricated FRED row is inserted. Four-week source-verified aggregates are also saved separately. Historical intraday FRED publication timestamps and revisions remain unverified: this is a reconstruction conditional on prior official-close availability, not a certified FRED-at-noon vintage replay.

## Five weekly periods

| Target | Origin London noon | Baseline date / level | Model | Forecast | Actual | APE % | Deduction | Score /50 |
|---|---|---|---|---|---|---|---|---|
| 2026-10-02 | 2026-09-25 12:00 BST | 2026-09-24 / 7,704.13 | A | 7,704.13 | 7,722.72 | 0.2407 | 1.2036 | 48.80 |
| 2026-10-02 | 2026-09-25 12:00 BST | 2026-09-24 / 7,704.13 | B | 7,711.26 | 7,722.72 | 0.1483 | 0.7417 | 49.26 |
| 2026-10-02 | 2026-09-25 12:00 BST | 2026-09-24 / 7,704.13 | C | 7,717.47 | 7,722.72 | 0.0680 | 0.3400 | 49.66 |
| 2026-10-09 | 2026-10-02 12:00 BST | 2026-10-01 / 7,666.45 | A | 7,666.45 | 7,811.54 | 1.8574 | 9.2869 | 40.71 |
| 2026-10-09 | 2026-10-02 12:00 BST | 2026-10-01 / 7,666.45 | B | 7,666.41 | 7,811.54 | 1.8579 | 9.2893 | 40.71 |
| 2026-10-09 | 2026-10-02 12:00 BST | 2026-10-01 / 7,666.45 | C | 7,679.38 | 7,811.54 | 1.6919 | 8.4596 | 41.54 |
| 2026-10-16 | 2026-10-09 12:00 BST | 2026-10-08 / 7,765.36 | A | 7,765.36 | 7,659.44 | 1.3829 | 6.9143 | 43.09 |
| 2026-10-16 | 2026-10-09 12:00 BST | 2026-10-08 / 7,765.36 | B | 7,809.77 | 7,659.44 | 1.9627 | 9.8133 | 40.19 |
| 2026-10-16 | 2026-10-09 12:00 BST | 2026-10-08 / 7,765.36 | C | 7,783.88 | 7,659.44 | 1.6247 | 8.1234 | 41.88 |
| 2026-10-23 | 2026-10-16 12:00 BST | 2026-10-15 / 7,744.06 | A | 7,744.06 | 7,623.68 | 1.5790 | 7.8951 | 42.10 |
| 2026-10-23 | 2026-10-16 12:00 BST | 2026-10-15 / 7,744.06 | B | 7,771.00 | 7,623.68 | 1.9325 | 9.6623 | 40.34 |
| 2026-10-23 | 2026-10-16 12:00 BST | 2026-10-15 / 7,744.06 | C | 7,761.09 | 7,623.68 | 1.8024 | 9.0120 | 40.99 |
| 2026-10-30 | 2026-10-23 12:00 BST | 2026-10-22 / 7,663.43 | A | 7,663.43 | 7,580.07 * | 1.0997 | 5.4986 | 44.50 |
| 2026-10-30 | 2026-10-23 12:00 BST | 2026-10-22 / 7,663.43 | B | 7,653.31 | 7,580.07 * | 0.9662 | 4.8310 | 45.17 |
| 2026-10-30 | 2026-10-23 12:00 BST | 2026-10-22 / 7,663.43 | C | 7,675.31 | 7,580.07 * | 1.2564 | 6.2821 | 43.72 |

*30 October actual is user-supplied and unverified against the project's original source. Forecasts and coefficients were saved before the scoring reference was read. This separates calculations, but does not claim that the analyst had never seen the historical outcomes. APE=100×|F−actual|/actual; deduction=min(50,5×APE); score=round(50−deduction,2). Use full-precision forecasts for calculations; displayed levels are rounded to two decimals. Scores are averaged after per-week rounding, as in the existing implementation.

## Weekly errors

![Weekly absolute percentage errors](figures/weekly_errors.png)

The shaded fifth point depends on the unverified actual; the preceding four points are already in the 52-origin evaluation.

## Five-week summary

| Model | MAPE % | Median % | Maximum % | Mean score /50 | Lowest-error weeks | Beat A | Mean marks vs A | Total marks vs A |
|---|---|---|---|---|---|---|---|---|
| A | 1.2319 | 1.3829 | 1.8574 | 43.840 | 2 | — | +0.000 | +0.00 |
| B | 1.3735 | 1.8579 | 1.9627 | 43.134 | 1 | 40% | -0.706 | -3.53 |
| C | 1.2887 | 1.6247 | 1.8024 | 43.558 | 2 | 40% | -0.282 | -1.41 |

A ties itself and is not counted as beating itself. Lowest-error counts include ties if any (none occur here). Marks differences are model score minus A score, using the rounded weekly scores. These are descriptive comparisons for five overlapping-horizon periods, not significance tests.

## Coefficients and overlap

| Origin | Training n | Latest eligible training target | 20-session momentum % | C intercept | C slope | C expected return % | In original 52 |
|---|---|---|---|---|---|---|---|
| 2026-09-25 | 192 | 2026-09-18 | 0.370390 | 0.0016164194 | 0.0310282237 | 0.173134 | True |
| 2026-10-02 | 193 | 2026-09-25 | -0.001957 | 0.0016865162 | 0.0304097654 | 0.168592 | True |
| 2026-10-09 | 194 | 2026-10-02 | 2.287498 | 0.0016897525 | 0.0304013778 | 0.238518 | True |
| 2026-10-16 | 195 | 2026-10-09 | 1.391769 | 0.0017816719 | 0.0299890538 | 0.219905 | True |
| 2026-10-23 | 196 | 2026-10-16 | -0.528288 | 0.0017050091 | 0.0293495736 | 0.154996 | False |

The origins 25 September, 2 October, 9 October and 16 October are already included in the 52-origin primary backtest. The 23 October origin is absent, because the original source snapshot lacked its 30 October target. The replay already examined that outcome separately, so even the fifth row should not be presented as a newly blinded test. No rows were appended to or removed from the original 52-origin evaluation.

## Why the rankings differ by week

- **2026-10-02: C wins.** Baseline-to-target realised return was +0.2413%; past momentum was +0.3704%. B forecast a return of +0.0926%, while C forecast +0.1731%. These observed directions and sizes explain the ranking arithmetically; they do not establish the cause of the market move.
- **2026-10-09: C wins.** Baseline-to-target realised return was +1.8925%; past momentum was -0.0020%. B forecast a return of -0.0005%, while C forecast +0.1686%. These observed directions and sizes explain the ranking arithmetically; they do not establish the cause of the market move.
- **2026-10-16: A wins.** Baseline-to-target realised return was -1.3640%; past momentum was +2.2875%. B forecast a return of +0.5719%, while C forecast +0.2385%. These observed directions and sizes explain the ranking arithmetically; they do not establish the cause of the market move.
- **2026-10-23: A wins.** Baseline-to-target realised return was -1.5545%; past momentum was +1.3918%. B forecast a return of +0.3479%, while C forecast +0.2199%. These observed directions and sizes explain the ranking arithmetically; they do not establish the cause of the market move.
- **2026-10-30: B wins.** Baseline-to-target realised return was -1.0878%; past momentum was -0.5283%. B forecast a return of -0.1321%, while C forecast +0.1550%. These observed directions and sizes explain the ranking arithmetically; they do not establish the cause of the market move.

On 2 October, the index rose modestly: both upward adjustments improved on A, and C's larger upward adjustment was closest. On 9 October, C's positive intercept helped with the rise; B's almost-zero negative momentum adjustment was slightly worse than A. On 16 and 23 October, the index fell despite positive momentum: B extrapolated upward most strongly and performed worst; C's smaller upward adjustment still hurt relative to A. On 30 October, conditional on the supplied actual, negative momentum moved B toward the decline while C's positive intercept outweighed its negative momentum term and pushed its forecast upward.

These are explanations from the model arithmetic and realised values. Trend continuation, reversal, earnings news, macro announcements or changes in risk appetite could be economic hypotheses, but no causal/event attribution was investigated here. In particular, a positive regression intercept can help during rising weeks without demonstrating useful momentum predictability.

## October versus the original 52 origins

| Model | October MAPE % | Original 52 MAPE % | October mean score | Original 52 mean score | October / 52 beat A % |
|---|---|---|---|---|---|
| A | 1.2319 | 1.4478 | 43.840 | 42.761 | 0.00 / 0.00 |
| B | 1.3735 | 1.4541 | 43.134 | 42.730 | 40.00 / 46.15 |
| C | 1.2887 | 1.4260 | 43.558 | 42.869 | 40.00 / 57.69 |

The comparisons share four observations; differences cannot be interpreted as independent confirmation or a statistically reliable change in performance. C was narrowly best by MAPE in the original 52; A is best on the five October weeks, while B wins the fifth week but has the worst monthly mean. A single winning week does not justify switching to B. The source-verified four-week subset also ranks A first by mean error (see `verified_four_week_summary.csv`), so the provisional choice does not rely on the unverified fifth actual.

**Recommendation: retain Model A as the provisional default, with C as the challenger.** October does not warrant changing coefficients or the model choice. The sample is small, mostly reused and includes an unverified actual. Future refinements require a separately defined development process and genuinely new forward evaluation; do not relabel already inspected October outcomes as independent validation.

## Verification and reproduction

All 15 forecasts and scores were independently rebuilt with Decimal arithmetic from the raw source values, including independently constructed training rows and centered-sum OLS. Monthly means, medians, maxima and average scores were also independently checked. Five future-price poisoning checks passed, all training labels preceded their origins, and the four overlapping forecasts matched saved backtest values exactly within numerical tolerance. All original model/specification/evaluation files passed unchanged-hash checks. Full test outputs are in `validation/`.

Run from the project root: `python3 research/october_comparison/calculate.py`. Existing pinned dependencies live in `research/vendor` and `research/requirements.txt`; chart generation additionally uses matplotlib (version saved in `validation/chart_environment.json`). The script writes only into this output directory. Sources: FRED SP500 https://fred.stlouisfed.org/series/SP500 ; original download https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500 ; XNYS calendar from exchange_calendars. The marking formula is from the supplied UCL IFTE0007 brief already extracted in `research/docs/coursework_extracted.txt`.

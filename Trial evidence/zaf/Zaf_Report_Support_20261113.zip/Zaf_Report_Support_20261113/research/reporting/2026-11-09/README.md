# Reporting consolidation for 6 to 8 November tasks

Completed on 9 November 2026 using existing saved evidence. No earlier completion date is claimed. This folder contains reporting outputs only. All original model, trial and historical files remain unchanged. No realised trial accuracy, final model selection or binding 13 November forecast has been generated.

## Start here

- REPORT.md summarises the audit outcome and provisional recommendation.
- COURSEWORK_DRAFT.md provides a 1,598-word draft of methodology, mechanisms, workflow, validation, limitations and findings. It stays below the brief's 2,400-word ceiling including tables/headings. It is not the final submission report.
- CONSOLIDATED_TRIALS.md and consolidated_trials.json identify each authoritative record, exact cutoff/target, A–D levels, calculation/issuance times and classification.
- HISTORICAL_RESULTS.md and historical_metrics.json contain independently reconstructed primary and sensitivity statistics, periods and rankings.
- AUDIT_AND_GAPS.md documents provenance, approvals, timing limitations, archive exceptions and missing submission items.
- EVIDENCE_INDEX.md and evidence_inventory.json map the research and record original file sizes, permissions and hashes.
- WORKFLOW.md contains the labelled Mermaid workflow and actual evidence-log locations.
- REFERENCES_AND_DECLARATIONS.md supplies references and group-completion declaration text.
- manifest_audit.json, manifest_exceptions.json and manifest_exception_analysis.json retain every manifest result and explain failures without repairing originals.
- primary_manifest_checks.json and trial_calculation_checks.json establish 439 passing primary trial manifest entries and 16 independent calculations from saved coefficients.
- source_metadata_inventory.json preserves the source-metadata audit inventory. Exact publication timestamps remain unknown where the original records lack them.
- audit_results.json, historical_recalculation_checks.json and word_count.json record verification scope and counts. SHA256.json covers this reporting package.

## Reproduction

From the project root, use the established Python 3.14 runtime, with bytecode disabled:

```
PYTHONDONTWRITEBYTECODE=1 /opt/anaconda3/bin/python3.14 research/reporting/2026-11-09/consolidate.py
PYTHONDONTWRITEBYTECODE=1 /opt/anaconda3/bin/python3.14 research/reporting/2026-11-09/verify_report.py
```

These scripts write only to their reporting directory. For a new audit, copy the scripts into a new sibling dated reporting directory first; retain this package and its checksums. Consolidate rebuilds the core inventories, trial tables and historical aggregates. Editorial Markdown and exception interpretation are retained reporting outputs rather than generated forecasts. No network or AI account is required. Standard-library arithmetic suffices; the runtime path may need adapting on another machine.

Review the authoritative source paths rather than top-level scheduled placeholders. Do not rerun legacy forecasting scripts against frozen directories. For final submission, build a curated portable evidence ZIP and verify source permissions and relative paths. This reporting directory is not that final ZIP.

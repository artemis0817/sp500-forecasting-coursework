# Historical results and robustness

Aggregates independently recalculated from saved full-precision forecasts and actuals using Decimal arithmetic. All errors are percentages.

| Sample | Model | n | Origin period | MAPE | Median | Maximum | MAPE rank |
|---|---|---|---|---|---|---|---|
| 52 primary | A | 52 | 2025-07-18 to 2026-10-16 | 1.447796 | 1.386506 | 4.229546 | 2 |
| 52 primary | B | 52 | 2025-07-18 to 2026-10-16 | 1.454056 | 1.228327 | 4.271151 | 3 |
| 52 primary | C | 52 | 2025-07-18 to 2026-10-16 | 1.425992 | 1.273781 | 4.084476 | 1 |
| 52 open Fridays | A | 52 | 2025-10-03 to 2026-10-16 | 1.590042 | 1.386506 | 4.530967 | 2 |
| 52 open Fridays | B | 52 | 2025-10-03 to 2026-10-16 | 1.657139 | 1.574742 | 5.238225 | 3 |
| 52 open Fridays | C | 52 | 2025-10-03 to 2026-10-16 | 1.588556 | 1.364655 | 4.405723 | 1 |
| 52 delayed | A | 52 | 2025-07-18 to 2026-10-16 | 1.601455 | 1.310842 | 5.691035 | 2 |
| 52 delayed | B | 52 | 2025-07-18 to 2026-10-16 | 1.671840 | 1.306816 | 6.267029 | 3 |
| 52 delayed | C | 52 | 2025-07-18 to 2026-10-16 | 1.600850 | 1.354428 | 5.524159 | 1 |
| 59 primary | A | 59 | 2024-01-05 to 2025-06-20 | 1.828480 | 1.502889 | 12.203789 | 2 |
| 59 primary | B | 59 | 2024-01-05 to 2025-06-20 | 1.833404 | 1.277063 | 11.398569 | 4 |
| 59 primary | C | 59 | 2024-01-05 to 2025-06-20 | 1.807673 | 1.544192 | 12.407936 | 1 |
| 59 primary | D | 59 | 2024-01-05 to 2025-06-20 | 1.831260 | 1.599841 | 12.173234 | 3 |
| 59 extra_release_lag | D | 59 | 2024-01-05 to 2025-06-20 | 1.827240 | 1.452939 | 12.408565 | 1 |
| 59 optimistic_same_day | D | 59 | 2024-01-05 to 2025-06-20 | 1.852013 | 1.621497 | 12.008147 | 1 |
| 59 trailing104 | D | 59 | 2024-01-05 to 2025-06-20 | 1.824179 | 1.619610 | 12.521467 | 1 |

C ranks first on MAPE in the two primary panels. On 52 origins, median ranks B/C/A and maximum-error ranks C/A/B. On 59 origins, median ranks B/A/C/D and maximum-error ranks B/D/A/C. Different loss criteria change the ranking. D has no evaluated row in the original 52 panel and must not be assigned one.

The 52 origins are filtered weekly Fridays, not daily observations or consecutive Fridays. The 59-origin evaluation ends before the 52-origin evaluation begins, but used data already exposed in earlier training research. These are not independent untouched experiments. Six-session weekly returns can overlap. October reuses four of the 52 cases; the four live trials overlap strongly. Do not sum these samples as independent evidence.

The 52-panel paired block bootstrap gives C−A mean APE −0.021804 percentage points with descriptive 95% interval [−0.092054, 0.047828]. In the 59 panel, D−C is +0.023588, interval [−0.073652, 0.120703] with four-observation blocks; eight-observation blocks do not change the qualitative conclusion. These are uncertainty diagnostics, not proof of equivalence or superiority.

D has a negative yield coefficient at every primary fit, yet is worse than C in both chronological halves and both yield-direction subsets. Its leave-one-out D−C mean error remains positive. None of its alternative lag/window variants beats primary C. Extra lag weakens median yield-slope magnitude from about 0.03106 to 0.00879. No best-looking sensitivity is adopted.

October four verified targets rank A/C/B by MAPE (1.264999/1.296753/1.475330%). Five-week aggregates rank A/C/B (1.231944/1.288687/1.373504%, approximately); consult original monthly_summary.csv for precise values. The original October report marks its 30 October actual as user-supplied. Later Trial 1 FRED evidence corroborates 7,580.07, but cannot retroactively provide historical noon publication evidence or change that report. The 23 October replay is the same fifth case, not an extra independent test.

Legacy 52-row results remain in results/legacy_run and the top-level backtest package. Their mixed-horizon model conventions differ from the corrected exact-six-session primary protocol; they are archived lineage, not additional evidence or a substitute ranking. Legacy MAPE A/B/C is 1.590042/1.657139/1.584699%.

Sources: research/results/summary.csv and paired_block_bootstrap.csv; research/treasury_extension/results/summary.csv, paired_uncertainty.csv, subperiods.csv; research/pit_audit/AUDIT_REPORT.md; research/october_comparison/REPORT.md; research/replays/2026-10-23/REPLAY_REPORT.md.

# Consolidated frozen trial records

All dates are in 2026. All cutoffs are 12:00 GMT and targets 21:00 GMT. No target actuals or realised scores are populated.

| Trial / origin | Cutoff UTC | Target UTC | A | B | C | D | Actual issuance UTC | Timing status |
|---|---|---|---|---|---|---|---|---|
| 1 / 2026-11-02 | 2026-11-02T12:00:00Z | 2026-11-09T21:00:00Z | 7580.07 | 7545.07 | 7587.69 | 7586.23 | None | Unissued late retrospective replay; no complete pre-cutoff snapshot |
| 2 / 2026-11-03 | 2026-11-03T12:00:00Z | 2026-11-10T21:00:00Z | 7541.40 | 7485.00 | 7546.43 | 7560.34 | 2026-11-03T10:21:31.820164+00:00 | Prospectively issued before noon with approved fallback; vintage caveats |
| 3 / 2026-11-04 | 2026-11-04T12:00:00Z | 2026-11-11T21:00:00Z | 7568.92 | 7508.42 | 7573.50 | 7593.19 | 2026-11-04T12:05:10.293385+00:00 | Post-cutoff issuance using pre-cutoff captures under revised protocol; late under original noon-issuance rule |
| 4 / 2026-11-05 | 2026-11-05T12:00:00Z | 2026-11-12T21:00:00Z | 7688.62 | 7660.74 | 7697.25 | 7707.16 | 2026-11-05T12:05:32.541792+00:00 | Post-cutoff issuance using pre-cutoff captures under revised protocol; late under original noon-issuance rule |

Trial 1 has a frozen/hash-recorded replay, not an issued forecast. Trial 2’s unissued replay label describes its precursor, not its later approved issuance. Trials 3/4 were forward forecasts relative to their targets, but must not be described as issued at noon. Local timestamps are not independent notarisation. The original approval messages’ send times are unavailable.

- Trial 1: `/Users/zafirahmunawar/Desktop/SP500_Coursework/research/live_trials/2026-11-02/runs/20261102T193625570832Z_replay/forecasts.json`; SHA-256 `036006c05dae12bba532d1abdc31baa4e0f13e6bd317af9db588e7263d00395f`; approval recorded `None`.
- Trial 2: `/Users/zafirahmunawar/Desktop/SP500_Coursework/research/live_trials/2026-11-03/issued/20261103T102131669838Z/forecasts.json`; SHA-256 `31684b9b36ea183a8b17b4f55930fe04d6b14da0c1e36dc326e5a17f824c846a`; approval recorded `2026-11-03T10:21:31.670058+00:00`.
- Trial 3: `/Users/zafirahmunawar/Desktop/SP500_Coursework/research/live_trials/2026-11-04/issued/forecasts.json`; SHA-256 `63206e5546d2d36bd25c6a171000b7f2ffaaf5b1194d9354427aea5195ad5f76`; approval recorded `2026-11-04T12:05:10.281697+00:00`.
- Trial 4: `/Users/zafirahmunawar/Desktop/SP500_Coursework/research/live_trials/2026-11-05/issued/forecasts.json`; SHA-256 `a38ff820822a6ef419a56c3e681746a7b819559e50af7856cc94ebab1ee5df9f`; approval recorded `2026-11-05T12:05:32.440155+00:00`.

# References and declaration templates

These references identify sources already used in the saved research. Links were not newly retrieved during this consolidation. Cite their original retained retrieval dates and payloads. Do not use this draft as evidence of current web availability.

- UCL (2026), IFTE0007 Group Coursework 2026/27, supplied Group Coursework 26-27.docx. Local extraction: research/docs/coursework_extracted.txt. Defines the market, 2,400-word limit, scoring, deadlines and evidence requirements.
- S&P Dow Jones Indices, S&P 500 index definition. https://www.spglobal.com/spdji/en/indices/equity/sp-500/ . The official price-index close is the marking reference. A failed direct retrieval is not a successful raw snapshot.
- Federal Reserve Bank of St. Louis, S&P 500 [SP500], sourced from S&P Dow Jones Indices. https://fred.stlouisfed.org/series/SP500 . Historical raw evidence: research/data/raw/ and trial-specific frozen responses. Actual URLs are in source metadata.
- Federal Reserve Board via FRED, Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity [DGS10]. https://fred.stlouisfed.org/series/DGS10 . Retained raw evidence: research/treasury_extension/data/ and trial source snapshots.
- Federal Reserve Board, H.15 Selected Interest Rates and release information. https://www.federalreserve.gov/releases/h15/ and https://www.federalreserve.gov/releases/h15/about.htm . Supports the declared timing proxy, not complete historical intraday certification.
- Yahoo Finance, S&P 500 (^GSPC) historical data. https://finance.yahoo.com/quote/%5EGSPC/history/ . Historical Close rows captured before the respective Trial 2–4 cutoffs. Per-trial approval required.
- Financial Times / Markit Digital, S&P 500 historical data. https://markets.ft.markitdigital.com/data/indices/tearsheet/historical?s=INX%3AIOM . Separate-provider corroboration with dates and payloads retained.
- NYSE, Holidays and Trading Hours. https://www.nyse.com/markets/hours-calendars . Actual computations use the saved XNYS calendar and pinned exchange_calendars version.
- Federal Reserve Bank of St. Louis, FRED API Real-Time Periods. https://fred.stlouisfed.org/docs/api/fred/realtime_period.html . Date vintages alone do not establish publication by noon.
- Group research records (2026), research/pit_audit/AUDIT_REPORT.md, research/treasury_extension/REPORT.md and research/october_comparison/REPORT.md. These are internally generated empirical results, not independent financial-source authorities.

## AI use declaration for group completion

Codex assisted with project inspection, source retrieval, Python calculations, audit checks, evidence preservation and report drafting. Saved instructions required strict cutoffs, unchanged models, no invented timestamps and explicit approval. Independent numerical checks and adversarial tests were used. Detected issues included stale source responses, historical timestamp alignment defects, unresolved vintages and archive-manifest exceptions. Group members must verify the financial reasoning, calculations, references and final text. Exact model/version identifiers should be added only where supported by retained session evidence; this package does not establish them.

## Contribution statement for group completion

Add each student's required identifier, actual tasks, checks performed, presentation role and approval. Do not claim the proposed responsibilities were completed until confirmed. Source-substitution and issuance approvals in the current evidence are chat-user approvals, not a signed record of every group member's agreement.

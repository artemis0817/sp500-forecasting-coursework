from pathlib import Path
from decimal import Decimal,localcontext
import json,hashlib,re,collections
O=Path(__file__).resolve().parent;ROOT=O.parents[2]
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
trials=load(O/'consolidated_trials.json');audit=load(O/'manifest_audit.json');results=[];counts=[]
for t in trials:
 p=Path(t['forecast_file']).parent;fs=load(p/'forecasts.json')
 candidates=[p/'inputs.json',p/'model_inputs.json',p/'candidate_evidence/model_inputs.json',p/'validated_replay_evidence/model_inputs.json']
 inputs=next((x for x in candidates if x.exists()),None)
 if inputs is None:
  found=list(p.rglob('model_inputs.json'));assert len(found)==1;inputs=found[0]
 v=load(inputs)
 with localcontext() as ctx:
  ctx.prec=50
  base=Decimal(str(v['base']));mom=base/Decimal(str(v['lookback_level']))-1;z=Decimal(str(v['yield_level']))-Decimal(str(v['yield_lookback_level']))
  for f in fs:
   ret=Decimal(str(f['intercept']))+Decimal(str(f['momentum_beta']))*mom+Decimal(str(f['yield_beta']))*z
   level=base*(1+ret);difference=abs(level-Decimal(str(f['forecast_full_precision'])))
   assert difference<Decimal('1e-8') and level.quantize(Decimal('.01'))==Decimal(f['forecast_level'])
   results.append({'trial':t['trial'],'model':f['model'],'independent_from_saved_inputs_and_coefficients':str(level),'difference':str(difference),'rounded_match':True,'scope':'Calculation check with frozen coefficients; no OLS refit or new forecast'})
 relevant=[r for r in audit if r['manifest']==str((p/'SHA256.json').relative_to(ROOT))];assert relevant and all(r['status']=='PASS' for r in relevant)
 counts.append({'trial':t['trial'],'manifest_entries':len(relevant),'all_pass':True,'input_path':str(inputs)})
(O/'trial_calculation_checks.json').write_text(json.dumps(results,indent=2));(O/'primary_manifest_checks.json').write_text(json.dumps(counts,indent=2))
inv=load(O/'evidence_inventory.json');assert all((ROOT/n).is_file() and sha(ROOT/n)==v['sha256'] for n,v in inv.items())
s=(O/'COURSEWORK_DRAFT.md').read_text();words=len(s.split());conservative=len(re.findall(r"\b[\w]+(?:[’'-][\w]+)*\b",s));assert max(words,conservative)<2400
(O/'word_count.json').write_text(json.dumps({'file':'COURSEWORK_DRAFT.md','whitespace_count_including_tables_headings':words,'regex_count_including_tables_headings':conservative,'brief_limit':2400,'remaining_using_larger_count':2400-max(words,conservative),'note':'Final word-processor count must be checked after cover forecast, references, final analysis and captions are integrated. Other files are supporting research, not automatic evidence-only appendix content.'},indent=2))
print('Trial checks',len(results),'Manifest counts',counts,'Word counts',words,conservative,'Originals unchanged',len(inv))

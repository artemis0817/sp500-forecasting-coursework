# Reporting execution record

Actual audit date 9 November 2026. This is a factual action summary, not a verbatim platform transcript or independently timestamped log.

1. Searched the existing project for reports, manifests, trial evidence, specifications, schedules and coursework requirements. Read the documents skill for brief inspection. Read the spreadsheet skill while assessing historical CSV data; no workbook was authored.
2. Read the saved coursework extraction and checked the original DOCX XML for the 2,400-word limit. Inspected historical primary, sensitivity, October, replay, Treasury-extension and point-in-time reports and row-level data.
3. Located authoritative trial records and issuance receipts. Read approval records and preserved classification differences. No network retrieval occurred.
4. Ran consolidate.py at 18:28:54–18:28:55 UTC. It inventoried originals, checked manifests and independently calculated historical error statistics using Decimal. All 48 comparisons passed.
5. Investigated every broad-manifest exception. All 256 non-bytecode missing-path entries have matching bytes elsewhere. Seven bytecode entries differ or are absent. Saved exact path/hash results without altering originals.
6. Wrote the coursework draft, consolidated tables, source/approval audit, model comparison, workflow, evidence index, references and missing-items checklist inside this reporting folder.
7. An initial reporting verification stopped because Trial 2 uses inputs.json rather than model_inputs.json. Corrected only the new reporting verifier's input-file lookup. The subsequent run passed all 16 fixed-coefficient forecast calculations and primary manifests. No original data or model was changed.
8. Checked the main draft word count and reverified original file preservation. No model refit, trial issuance, outcome retrieval, scoring, final model selection or binding forecast occurred.

Reproducible tool inputs are the saved reporting Python scripts. Exact input paths and hashes are in the inventories. Original historical tool logs and trial-specific test logs are indexed in WORKFLOW.md.

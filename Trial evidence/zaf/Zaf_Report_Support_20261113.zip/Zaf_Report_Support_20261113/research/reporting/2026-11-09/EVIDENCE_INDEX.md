# Evidence index

All paths below are relative to the project root. The exhaustive machine-readable inventory is evidence_inventory.json, with paths, sizes, permissions and current SHA-256. Duplicate hashes indicate repeated bytes, not additional independent evidence.

| Evidence family | Authoritative location | Use and limits |
|---|---|---|
| Brief | Group Coursework 26-27.docx; research/docs/coursework_extracted.txt | Requirements, 2,400 words, scoring and submission |
| Original legacy project | sp500_backtest/; research/originals/; research/results/legacy_run/ | Preserved lineage; superseded conventions |
| Corrected A/B/C backtest | research/src/; research/results/; research/data/; research/docs/; research/validation/ | 52 primary origins, sensitivities, code and source snapshots |
| Point-in-time audit | research/pit_audit/ | Corrections, row ledgers, tests, pre-audit copies; nested manifest exceptions disclosed |
| October replay | research/replays/2026-10-23/ | Single-week retrospective replay; overlaps October comparison |
| October comparison | research/october_comparison/ | Four source-verified targets and conditional fifth; four overlap primary52 |
| Treasury extension | research/treasury_extension/ | Separate 59-origin panel, D variants, scenarios, timeline, raw data and tests |
| Frozen shared historical code | research/live_trials/evidence/historical/ | Isolated reusable copy; includes inherited manifests |
| Trial 1 | research/live_trials/2026-11-02/runs/20261102T193625570832Z_replay/ | Authoritative unissued retrospective record |
| Trial 1 validation | research/live_trials/2026-11-02/validation_runs/20261102T210714284545Z/ | Independent numeric and timing audit; earlier incomplete attempt remains distinct |
| Trial 2 issuance | research/live_trials/2026-11-03/issued/20261103T102131669838Z/ | Authoritative issued values; receipt under issued/receipts/ |
| Trial 2 provenance | research/live_trials/2026-11-03/source_substitution/; post_cutoff_validation/ | Raw fallback evidence, unissued precursor, later reproduction; blocked attempt under workflow_v2_runs/ |
| Trial 3 | research/live_trials/2026-11-04/issued/; issuance_receipt.json | Authoritative issuance; preparation and candidate originals retained separately |
| Trial 4 | research/live_trials/2026-11-05/issued/; issuance_receipt.json | Authoritative issuance; preparation/candidate/validation originals retained |
| Source rules | research/live_trials/policies/fallback_source_hierarchy_PROPOSED_2026-11-03.md | Proposal only; per-trial approval records govern |
| Existing descriptive PDF/workbook | SP500_Backtesting_Group_Summary.pdf; SP500 historial data.xlsx; SP500_Backtesting_MAPE_Comparison.csv | Inventory only; primary machine-readable evidence governs numerical summaries |

No final report PDF, submission slides, final binding forecast package or ready submission ZIP was located. Existing backtest summary material is not a final coursework submission.

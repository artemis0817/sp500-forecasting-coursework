# S&P 500 forecasting methodology and research findings

## Status and research objective

This draft consolidates research completed before the binding forecast decision. It contains no final submission forecast. We seek a transparent forecast of the official S&P 500 price-index closing level, measured in index points rather than an ETF, futures contract or total-return series. The coursework’s binding information cutoff is 13 November 2026 at 12:00 GMT, with target 20 November at 21:00 GMT and submission by 17:00 GMT on 13 November (UCL, 2026). A final approved point forecast must later appear on the report’s first page and match the evidence record.

Our provisional recommendation is to retain unchanged price, Model A, as the operational benchmark and default, while keeping Model C as a challenger. C has slightly lower historical mean error, but the advantage is small and uncertain. This is a provisional research judgement, not the final model selection or a binding forecast. Model D remains an exploratory comparison despite its authorised inclusion in the four trials.

## Market data and information boundary

The S&P Dow Jones Indices price-index definition determines the instrument. FRED SP500 supplies the historical daily closing-price series. FRED DGS10 supplies the US ten-year constant-maturity Treasury yield from Federal Reserve H.15, in percent per annum. Source files, exact endpoints, retrieval times, observation dates and SHA-256 hashes are retained separately from processed modelling data. Scheduled market close, publication, retrieval, calculation and issuance are different events.

The latest eligible equity close is determined using the actual XNYS calendar and timezone-aware Europe/London and America/New_York timestamps. Treasury eligibility follows the existing conservative proxy of the next federal business day at 16:15 New York time, with documented holiday exclusions. This is an assumed release boundary, not proof of each historical FRED publication. Treasury changes use five nonmissing observation intervals, which can differ from five equity sessions.

For Trials 2–4, FRED lagged the expected latest equity close. Separately captured Yahoo Finance historical Close rows, corroborated by FT historical rows, supplied only the missing observation with explicit per-trial approval. They represent the same price index, not adjusted total-return values. Capturing a value before noon establishes an observed-by bound for that trial; it does not establish its exact first-publication time. Separate providers can share underlying feeds, so corroboration is not independent price formation. Historical revisions and exact first-availability times remain unverified. The proposed standing fallback hierarchy has not received group approval.

## Factors and economic mechanisms

Let P be the last eligible close, m = P[t]/P[t−20] − 1, and z = Y[u] − Y[u−5]. Momentum is a decimal return over twenty equity-session intervals. The yield factor is in percentage points, so a 25-basis-point change equals 0.25. Every forecast is F = P(1+r).

| Model | Six-session return mapping | Estimated parameters | Interpretation and risk |
|---|---|---|---|
| A | r = 0 | None | No predictable short-horizon change; least estimation risk, but ignores trends and changing conditions. |
| B | r = 0.25m | None; fixed coefficient | Partial continuation through gradual information diffusion or investor behaviour; reversals can amplify errors. |
| C | r = a + bm | Intercept and momentum slope | Learns the historical momentum relationship; estimation noise and regime instability can overwhelm weak signal. |
| D | r = a + bm + gz | Intercept and two slopes | Rising yields may raise discount rates and borrowing costs; extra parameter and publication assumptions increase uncertainty. |

C and D use unchanged expanding ordinary least squares with at least 52 matured Friday-origin, exact-six-session training rows. No new factor selection, regularisation, parameter search or October-based tuning was introduced. Re-estimation follows the fixed rule and includes earlier outcomes only after they mature. A and B require no fitted coefficients. The live trials transfer Friday-trained relationships to Monday–Thursday origins, an untested day-of-week generalisation.

D’s expected negative yield coefficient is economically plausible but not causal. Rising yields may instead signal stronger growth, while recession fears can reduce both yields and equities. In the historical adverse scenario, a 25-basis-point decline in yields alongside a 3% equity decline caused D to predict upward and incur 4.2415% error. This is an assumed scenario, not an outcome or a November forecast.

## Agent workflow and human responsibility

The agent inspected the saved research and brief, retrieved dated source responses, invoked Python calculations, checked timestamps and independently reconstructed numerical results. It escalated stale FRED observations for human source approval, retained blocked attempts and replay records, and sought separate approval before formal issuance. Raw source responses, model inputs, coefficients, test logs and version hashes make the calculations inspectable without an AI account.

The workflow is research goal → source retrieval → eligibility and integrity checks → Python factor and forecast calculations → independent validation → human approval → frozen output. Source failure or unknown required availability returns the workflow to a human decision rather than silent substitution. The group remains responsible for the financial argument, source permissions, model selection, final forecast, contribution statement and submission. Recorded approval times are the agent’s actual recording times; original message-send timestamps were unavailable.

## Historical validation and findings

Time-ordered evaluation compares forecasts with the actual index close using APE = 100 × |F−Actual|/Actual. MAPE averages these errors. Accuracy marks are 50 − min(50,5×APE), with the final score rounded to two decimals. The historical implementation evaluates full-precision forecasts and averages rounded weekly scores. This convention should be distinguished from the coursework’s binding two-decimal point forecast.

| Evaluation | Model | MAPE % | Median APE % | Maximum APE % |
|---|---|---:|---:|---:|
| 52 origins | A | 1.447796 | 1.386506 | 4.229546 |
| 52 origins | B | 1.454056 | 1.228327 | 4.271151 |
| 52 origins | C | 1.425992 | 1.273781 | 4.084476 |
| 59 origins | A | 1.828480 | 1.502889 | 12.203789 |
| 59 origins | B | 1.833404 | 1.277063 | 11.398569 |
| 59 origins | C | 1.807673 | 1.544192 | 12.407936 |
| 59 origins | D | 1.831260 | 1.599841 | 12.173234 |

The 52 primary origins span 18 July 2025–16 October 2026, targeting 25 July 2025–23 October 2026. They are filtered weekly Fridays, not daily or consecutive-Friday observations. The separate 59-origin comparison spans 5 January 2024–20 June 2025, targeting 12 January 2024–27 June 2025. Its evaluation dates are disjoint from the 52, but it uses previously exposed training history and shared research choices. Neither panel is pristine prospective evidence. Weekly six-session returns can overlap and expanding fits share training observations.

C ranks first by MAPE in both primary panels, but B has the lowest median error. In the 59 panel, C also has the largest maximum error. The 52-panel paired block bootstrap estimates C−A mean APE at −0.021804 percentage points, with a descriptive 95% interval of −0.092054 to 0.047828. For 59 origins, D−C is +0.023588, interval −0.073652 to 0.120703. Neither interval establishes superiority. D’s negative slope is stable in sign but does not establish predictive gains.

Open-Friday and delayed-input sensitivity panels leave A and C very close. D’s additional-lag, optimistic same-day and trailing-104 variants do not beat primary C. Changing the lag materially changes the yield coefficient, exposing dependence on timing assumptions. October comparisons favour A by mean error but reuse four observations from the 52-origin test. The fifth October actual was originally user-supplied and subsequently corroborated by a later FRED snapshot. That later evidence cannot certify earlier availability. October, its single-week replay and the original test must not be counted as separate independent confirmations.

## Live trials and audit results

Trial 1 was calculated on 2 November at 19:36 GMT without a complete noon snapshot and remains an unissued retrospective replay. Trial 2 was approved, issued and frozen on 3 November at approximately 10:21 GMT. Trials 3 and 4 were issued on 4 and 5 November at approximately 12:05 GMT under explicit instructions to calculate after noon from pre-cutoff captures. They were forward forecasts relative to their target dates, but late under the initial requirement to issue by noon. They must not be described as pre-noon issuances.

All four use 198 matured C/D training rows through the 30 October outcome. Existing validation records report 36 passing tests across five suites, plus independent Decimal forecasts, timestamp checks, future-value poisoning, immature-label exclusion, truncated-history replay and negative availability controls. The earlier audit corrected 36 historical summer cutoffs and 197 delayed-sensitivity target timestamps without changing numerical forecasts. Passing tests demonstrate the exercised code behaviour, not complete historical publication provenance.

The consolidation independently reproduced 48 historical summary statistics and verified all four primary trial manifests. Broader archive inspection found copied-manifest path gaps and Python-bytecode exceptions, documented separately. Local read-only files and hashes detect accidental changes but are not independently notarised or owner-resistant storage. No live realised error has been populated. Trial 1’s target is due on 9 November at 21:00 GMT, after this consolidation’s execution; the other targets follow on 10–12 November.

## Limitations and provisional conclusion

Small differences in average error are not reliable economic dominance. Regime changes, shocks after cutoff, factor endogeneity, Friday-to-weekday transfer, unknown historical vintages and source substitution constrain interpretation. Earlier evaluation results have already influenced research preferences, creating selection exposure even without coefficient tuning. Four strongly overlapping trials cannot establish statistical superiority and must remain separate from retrospective evidence.

A offers the simplest implementation and lowest estimation burden. C’s small average-error advantage justifies retaining it as a challenger, while D’s extra complexity has not earned promotion. The group should make and document the final selection under the assignment’s information boundary. This draft deliberately leaves that decision and the binding point forecast outstanding.

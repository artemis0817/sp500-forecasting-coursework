"""Read-only research consolidation. Writes only beside this reporting script."""
from pathlib import Path
from datetime import datetime,timezone
from decimal import Decimal
import csv,json,hashlib,statistics,collections,re
O=Path(__file__).resolve().parent; ROOT=O.parents[2]; R=ROOT/'research'; L=R/'live_trials'
now=lambda:datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def rows(p):
 with p.open() as f:return list(csv.DictReader(f))
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2,default=str)+'\n')
def table(headers,rs):return '\n'.join(['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(str(v) for v in r)+' |' for r in rs])+'\n'
def inventory():
 return {str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)} for p in ROOT.rglob('*') if p.is_file() and not any(x in p.parts for x in ['vendor','__pycache__','.git','.codex','.agents','reporting']) and p.name!='.DS_Store' and not p.name.startswith('~$')}
start=now();before=inventory();dump('evidence_inventory.json',before)
# Every saved research manifest is checked against its own stated paths.
checks=[];unsupported=[]
for rel in before:
 p=ROOT/rel
 if p.name not in ('SHA256.json','manifest.json'):continue
 try:x=load(p)
 except Exception as e:unsupported.append({'path':rel,'reason':str(e)});continue
 if isinstance(x,list):entries=x
 elif 'files' in x and isinstance(x['files'],list):entries=x['files']
 elif isinstance(x,dict) and all(isinstance(v,str) and re.fullmatch('[0-9a-f]{64}',v) for v in x.values()):entries=[{'path':k,'sha256':v} for k,v in x.items()]
 else:unsupported.append({'path':rel,'reason':'Unsupported manifest structure'});continue
 for e in entries:
  if not isinstance(e,dict) or 'path' not in e or 'sha256' not in e:unsupported.append({'path':rel,'reason':'Entry lacks path/hash'});continue
  dest=p.parent/e['path'];status='MISSING' if not dest.is_file() else 'PASS' if sha(dest)==e['sha256'] else 'MISMATCH'
  checks.append({'manifest':rel,'recorded_path':e['path'],'resolved_path':str(dest),'status':status,'expected_sha256':e['sha256'],'actual_sha256':sha(dest) if dest.is_file() else None})
dump('manifest_audit.json',checks);dump('manifest_exceptions.json',{'nonpassing':[x for x in checks if x['status']!='PASS'],'unsupported':unsupported})
# Authoritative records, rather than obsolete scheduled placeholder files.
paths=[L/'2026-11-02/runs/20261102T193625570832Z_replay',L/'2026-11-03/issued/20261103T102131669838Z',L/'2026-11-04/issued',L/'2026-11-05/issued']
trials=[]
for i,p in enumerate(paths,1):
 f=load(p/'forecasts.json');info={'trial':i,'origin_date':f'2026-11-{i+1:02}','cutoff_utc':f'2026-11-{i+1:02}T12:00:00Z','target_utc':f'2026-11-{i+8:02}T21:00:00Z','forecasts':{v['model']:v['forecast_level'] for v in f},'forecast_file':str(p/'forecasts.json'),'forecast_sha256':sha(p/'forecasts.json'),'actual_target':None,'APE':None}
 if i==1:info.update(issuance_utc=None,calculation_utc=f[0]['actual_execution_utc'],approval_utc=None,classification='Unissued late retrospective replay; no complete pre-cutoff snapshot',strict_pre_noon_issuance=False)
 elif i==2:
  c=load(L/'2026-11-03/issued/receipts/20261103T102131669838Z/completion.json');e=c['events_UTC'];info.update(issuance_utc=e['actual_issuance'],freeze_utc=e['evidence_freeze_completed'],calculation_validation_completed_utc=e['calculation_validation_completed'],approval_utc=e['approval_recorded'],classification='Prospectively issued before noon with approved fallback; vintage caveats',strict_pre_noon_issuance=True);assert sha(p/'SHA256.json')==c['issued_manifest_sha256']
 else:
  c=load(p/'issuance.json');rec=load(p.parent/'issuance_receipt.json');info.update(issuance_utc=c['actual_issuance_utc'],freeze_utc=rec['freeze_verified_utc'],calculation_utc=c['candidate_calculated_utc'],approval_utc=c['approval_recorded_utc'],classification='Post-cutoff issuance using pre-cutoff captures under revised protocol; late under original noon-issuance rule',strict_pre_noon_issuance=False);assert sha(p/'SHA256.json')==rec['manifest_sha256']
 assert len(f)==4
 trials.append(info)
dump('consolidated_trials.json',trials)
(O/'CONSOLIDATED_TRIALS.md').write_text('# Consolidated frozen trial records\n\nAll dates are in 2026. All cutoffs are 12:00 GMT and targets 21:00 GMT. No target actuals or realised scores are populated.\n\n'+table(['Trial / origin','Cutoff UTC','Target UTC','A','B','C','D','Actual issuance UTC','Timing status'],[[str(t['trial'])+' / '+t['origin_date'],t['cutoff_utc'],t['target_utc'],*[t['forecasts'][m] for m in 'ABCD'],t['issuance_utc'] or 'None',t['classification']] for t in trials])+'\nTrial 1 has a frozen/hash-recorded replay, not an issued forecast. Trial 2’s unissued replay label describes its precursor, not its later approved issuance. Trials 3/4 were forward forecasts relative to their targets, but must not be described as issued at noon. Local timestamps are not independent notarisation. The original approval messages’ send times are unavailable.\n\n'+ '\n'.join(f"- Trial {t['trial']}: `{t['forecast_file']}`; SHA-256 `{t['forecast_sha256']}`; approval recorded `{t['approval_utc']}`." for t in trials)+'\n')
# Independently rebuild historical error aggregates from frozen full-precision forecasts and actuals.
metrics=[];comparisons=[]
configs=[('52 primary','results/primary_forecasts.csv','ABC',None,'primary_six_sessions'),('52 open Fridays','results/holiday_forecasts.csv','ABC',None,'all_open_fridays'),('52 delayed','results/delayed_forecasts.csv','ABC',None,'one_session_delayed_inputs')]
for variant in ['primary','extra_release_lag','optimistic_same_day','trailing104']:configs.append(('59 '+variant,'treasury_extension/results/all_forecasts.csv','ABCD' if variant=='primary' else 'D',variant,variant))
for name,file,models,variant,key in configs:
 data=[r for r in rows(R/file) if variant is None or r['variant']==variant]
 for m in models:
  errors=[Decimal(100)*abs(Decimal(r[m+'_forecast'])-Decimal(r['actual']))/Decimal(r['actual']) for r in data]
  result={'sample':name,'model':m,'n':len(data),'first_origin':min(r['origin'] for r in data),'last_origin':max(r['origin'] for r in data),'first_target':min(r['target_date'] for r in data),'last_target':max(r['target_date'] for r in data),'MAPE_pct':float(statistics.mean(errors)),'median_APE_pct':float(statistics.median(errors)),'max_APE_pct':float(max(errors)),'source':file}
  metrics.append(result)
  saved=next(r for r in rows(R/('treasury_extension/results/summary.csv' if variant else 'results/summary.csv')) if r['model']==m and r['variant' if variant else 'panel']==key)
  for field in ['MAPE_pct','median_APE_pct','max_APE_pct']:
   diff=abs(result[field]-float(saved[field]));comparisons.append({'sample':name,'model':m,'metric':field,'absolute_difference':diff,'pass':diff<1e-10})
for name in set(x['sample'] for x in metrics):
 group=sorted([x for x in metrics if x['sample']==name],key=lambda x:x['MAPE_pct'])
 for j,x in enumerate(group,1):x['MAPE_rank_within_reported_models']=j
assert all(x['pass'] for x in comparisons)
dump('historical_metrics.json',metrics);dump('historical_recalculation_checks.json',comparisons)
a={r['origin'] for r in rows(R/'results/primary_forecasts.csv')};b={r['origin'] for r in rows(R/'treasury_extension/results/all_forecasts.csv') if r['variant']=='primary'}
assert not a&b
dump('sample_relationships.json',{'52_59_origin_overlap':len(a&b),'52_59_independent_experiments':False,'reason':'Disjoint evaluated origins, shared expanding training histories and prior research exposure; serial/return dependence remains','October_overlap_with_52':4,'live_trials_overlap':True,'no_pooled_effective_sample_size_claim':True})
(O/'HISTORICAL_RESULTS.md').write_text('# Historical results and robustness\n\nAggregates independently recalculated from saved full-precision forecasts and actuals using Decimal arithmetic. All errors are percentages.\n\n'+table(['Sample','Model','n','Origin period','MAPE','Median','Maximum','MAPE rank'],[[x['sample'],x['model'],x['n'],x['first_origin']+' to '+x['last_origin'],*[f"{x[k]:.6f}" for k in ['MAPE_pct','median_APE_pct','max_APE_pct']],x['MAPE_rank_within_reported_models']] for x in metrics])+'\nC ranks first on MAPE in the two primary panels. On 52 origins, median ranks B/C/A and maximum-error ranks C/A/B. On 59 origins, median ranks B/A/C/D and maximum-error ranks B/D/A/C. Different loss criteria change the ranking. D has no evaluated row in the original 52 panel and must not be assigned one.\n\nThe 52 origins are filtered weekly Fridays, not daily observations or consecutive Fridays. The 59-origin evaluation ends before the 52-origin evaluation begins, but used data already exposed in earlier training research. These are not independent untouched experiments. Six-session weekly returns can overlap. October reuses four of the 52 cases; the four live trials overlap strongly. Do not sum these samples as independent evidence.\n\nThe 52-panel paired block bootstrap gives C−A mean APE −0.021804 percentage points with descriptive 95% interval [−0.092054, 0.047828]. In the 59 panel, D−C is +0.023588, interval [−0.073652, 0.120703] with four-observation blocks; eight-observation blocks do not change the qualitative conclusion. These are uncertainty diagnostics, not proof of equivalence or superiority.\n\nD has a negative yield coefficient at every primary fit, yet is worse than C in both chronological halves and both yield-direction subsets. Its leave-one-out D−C mean error remains positive. None of its alternative lag/window variants beats primary C. Extra lag weakens median yield-slope magnitude from about 0.03106 to 0.00879. No best-looking sensitivity is adopted.\n\nOctober four verified targets rank A/C/B by MAPE (1.264999/1.296753/1.475330%). Five-week aggregates rank A/C/B (1.231944/1.288687/1.373504%, approximately); consult original monthly_summary.csv for precise values. The original October report marks its 30 October actual as user-supplied. Later Trial 1 FRED evidence corroborates 7,580.07, but cannot retroactively provide historical noon publication evidence or change that report. The 23 October replay is the same fifth case, not an extra independent test.\n\nLegacy 52-row results remain in results/legacy_run and the top-level backtest package. Their mixed-horizon model conventions differ from the corrected exact-six-session primary protocol; they are archived lineage, not additional evidence or a substitute ranking. Legacy MAPE A/B/C is 1.590042/1.657139/1.584699%.\n\nSources: research/results/summary.csv and paired_block_bootstrap.csv; research/treasury_extension/results/summary.csv, paired_uncertainty.csv, subperiods.csv; research/pit_audit/AUDIT_REPORT.md; research/october_comparison/REPORT.md; research/replays/2026-10-23/REPLAY_REPORT.md.\n')
# Per-source raw metadata inventory without replacing unknown publication times.
source_entries=[]
for rel in before:
 if rel.endswith('.metadata.json') and ('live_trials/2026-11-' in rel or '/data/raw/' in rel or '/sources/' in rel or '/treasury_extension/data/' in rel):
  try:source_entries.append({'metadata_path':rel,'metadata':load(ROOT/rel)})
  except Exception:pass
dump('source_metadata_inventory.json',source_entries)
after=inventory();changed=[k for k,v in before.items() if k not in after or after[k]['sha256']!=v['sha256']]
assert not changed
dump('audit_results.json',{'started_utc':start,'completed_utc':now(),'inventoried_original_files':len(before),'unchanged_original_files':len(before),'changed':changed,'manifest_entry_status_counts':dict(collections.Counter(x['status'] for x in checks)),'unsupported_manifests':len(unsupported),'historical_metric_comparisons':len(comparisons),'historical_metric_checks_passed':all(x['pass'] for x in comparisons),'scope':'Read-only byte integrity and independent aggregate calculations; existing model test logs reviewed, model suites not rerun. No network retrieval, new forecasts, or realised live scoring.','excluded_inventory':'vendor dependencies, bytecode, .git/.codex/.agents, reporting output, .DS_Store and Office lock files','current_UTC':now()})
print(json.dumps(load(O/'audit_results.json'),indent=2))

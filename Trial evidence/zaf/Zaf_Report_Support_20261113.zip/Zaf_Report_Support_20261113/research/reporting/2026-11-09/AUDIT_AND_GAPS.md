# Provenance audit and remaining submission work

This consolidation was executed on 9 November 2026, after the requested 6–8 November reporting window. No completion on those earlier dates is claimed. No separate 6–8 November milestone checklist was found in the inspected project; scope follows the user's task list. The original DOCX brief confirms a 2,400-word main-report ceiling and the submission requirements below.

## Integrity and preservation

The reporting audit inventoried 2,498 original project evidence files and verified them unchanged before and after the work. Exclusions are listed in audit_results.json. It independently reproduced 48 MAPE, median and maximum-error comparisons. It inspected existing test evidence rather than rerunning scripts that write historical results.

There are 5,012 passing manifest-entry checks, 257 missing-path checks and six mismatching checks across nested archives. These counts include duplicate references and are not counts of independent files. All four authoritative trial package manifests pass, including the Trial 2 issuance receipt and Trial 3/4 receipt anchors.

Of the exceptions, 256 are paths in eight copies of the pre-audit manifest whose referenced data were not copied into the local before/ directory. Matching SHA-256 bytes exist elsewhere in the project, with locations listed in manifest_exception_analysis.json. The remaining seven concern compiled Python bytecode: six mismatches and one omission. These do not establish changes to forecast values or model source. They do mean that an unqualified claim that every inherited nested manifest verifies would be false. No manifest or original file was repaired or deleted. Future submission packaging should explicitly resolve the references or label inherited manifests as archival, without rewriting frozen evidence.

## Source and approval findings

- Trial 1 uses a post-noon FRED snapshot, with the 30 October baseline and newest training outcome unavailable in the earlier saved price snapshot. First availability remains unverified. The original pending approval status is retained. Do not describe it as a formally issued live forecast.
- Trial 2 has a preserved blocked attempt, a validated replay precursor, approval recorded at 10:21:31.670058 GMT, issuance at 10:21:31.820164 and freeze at 10:21:31.912724. Yahoo was captured at 10:12:27.808565 GMT and FT at 10:12:34.266633. Pre-noon source substitution was specifically authorised. Later validation exactly reproduced all four stored forecasts.
- Trial 3 has separate source approval and formal issuance approval. Yahoo/FT pre-noon captures support 3 November Close 7,568.92. Actual issuance was 4 November 12:05:10.293385 GMT. Trial 4 similarly supports 4 November Close 7,688.62 and issuance on 5 November 12:05:32.541792 GMT. These comply with their revised post-noon instructions, not the earlier pre-noon issuance rule.
- Approvals are user-in-chat records, not independently authenticated group signatures. Original message-send timestamps are null; actual approval recording times are retained. Group ratification and named responsibilities remain outstanding.
- DGS10 consistently retains the original conservative publication-lag proxy. Exact intraday Treasury observation times and FRED processing delays remain unknown. Pre-cutoff raw captures support availability of live input values, not each historical training origin's vintage.
- FRED's stale latest row is observed. Its exact cause is not established by the preserved records; successful stale responses suggest publication/distribution lag rather than a total retrieval failure. Do not infer a fixed universal FRED delay.
- The fallback hierarchy remains proposed, not a standing group-approved policy. Trial-specific approvals do not approve future use.
- HTTP Last-Modified and Date headers are preserved where returned. They are not automatically first-publication times. Observation close times are calendar times, not provider timestamps.
- Sources carry provider rights. Licence and redistribution permission are not certified. Review raw HTML/data redistribution for the final evidence ZIP and supply clearly labelled permitted sample inputs if needed, as the brief allows. Keep private frozen originals intact.

## Model and validation findings

Model D is the explicitly authorised fourth live comparison, with two factors and an intercept. The historical extension recommended against promoting it as the selected model. These are compatible statuses, not a licence to invent a different Model D. A/B/C/D specifications, Friday training, minimum 52 rows, exact-six-session target rule, momentum coefficient 0.25 and Treasury observation lag are unchanged. All live C/D estimates use 198 matured rows through the 30 October target, so their coefficients coincide across trials.

Existing test logs document future-price/yield poisoning, immature outcomes, truncated history, independent Decimal OLS, chronology, holidays/DST, source hash failures and negative availability cases. Publication and historical-vintage checks remain UNVERIFIED even where numerical checks pass. Non-failing pandas and ResourceWarnings remain in logs. Model-version hashes substitute for a missing Git commit. Local hashes are integrity evidence, not proof of contemporaneous public issuance.

Some top-level live-trial status files remain old scheduled placeholders. Use the authoritative paths in consolidated_trials.json and the issuance receipts. This report does not rewrite those originals.

## Missing or pending submission items

1. Group-approved final model selection with rationale and named sign-off. This reporting package supplies only a provisional recommendation.
2. Binding 13 November dataset, information-boundary audit, approved two-decimal forecast for 20 November, and matching cover/evidence record. Intentionally not generated here.
3. Official target outcomes and separate later evaluation for Trials 1–4. Do not score before publication. Retain full-precision research scoring separately from any scoring of issued rounded forecasts.
4. Group-approved future fallback hierarchy, or explicit case-specific approval on the binding run if needed.
5. Named members, identifiers, contribution statement and final AI-use declaration. Exact model ID is not established in the saved evidence; do not invent it.
6. Final English report PDF within 2,400 words, with standard references and unique point forecast on its first page. The supplied Markdown is a research draft, not a submission-ready binding report. Evidence-only appendix, if used, is limited to four pages and must not contain new analysis.
7. Seven-minute presentation PDF/PowerPoint, coordinated member roles and three-minute Q&A preparation. Include a frozen-input agent walkthrough or recording. No completed submission deck or walkthrough recording was located.
8. Curated evidence ZIP containing redistributable snapshots, executable calculations, software versions, instructions, actual short transcript/screenshots, final record and README. Verify it on a clean machine without an AI subscription. Existing local absolute paths and nested manifest gaps require packaging review. No ready final submission ZIP was found.
9. Credential/secret and licence review of the curated ZIP. No credentials were requested or printed in this audit; this is not a claim of an exhaustive secret scan.
10. Submission through the module channel by 13 November at 17:00 GMT and presentation on 17 November. Neither action has been performed.

## Reproduction and source hierarchy

Use the authoritative trial paths in consolidated_trials.json. For historical aggregates use research/results/primary_forecasts.csv and the two sensitivity files, and research/treasury_extension/results/all_forecasts.csv. Their originating sources and model scripts remain frozen. The source metadata inventory records preserved URLs, timestamps and limitations; missing fields are not filled with invented publication stamps. Current internet downloads are unnecessary for this audit and would not improve historical timing proof.

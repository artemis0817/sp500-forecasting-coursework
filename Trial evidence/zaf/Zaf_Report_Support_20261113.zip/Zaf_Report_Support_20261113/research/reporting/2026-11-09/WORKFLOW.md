# Agent workflow and responsibility

```mermaid
flowchart TD
    A[Research goal and strict information cutoff] --> B[Inspect saved research and retrieve source responses]
    B --> C[Check instrument dates publication evidence and hashes]
    C --> D{Inputs eligible and source approved?}
    D -- No --> E[Preserve blocked attempt and request human decision]
    E --> C
    D -- Yes --> F[Python factors and unchanged models A to D]
    F --> G[Independent Decimal calculations and leakage tests]
    G --> H{Validation acceptable?}
    H -- No --> I[Separate correction record and disclose limitations]
    I --> G
    H -- Yes --> J[Human reviews candidates and timing caveats]
    J --> K[Explicit approval recorded]
    K --> L[Issue with actual timestamp and freeze hashes]
    L --> M[Evaluate separately only after official target publication]
```

For Trials 3–4, the calculation stage follows noon while the input-capture boundary remains noon. Trial 1 is a retrospective exception. This diagram describes the evidenced session-based workflow, not an unattended service. Human approval cannot retrospectively make a late forecast pre-noon or prove unknown publication history.

## Actual tool evidence

- Historical research instructions, decisions and checks: research/docs/research_transcript.md and research/validation/execution_log.txt.
- Treasury extension decisions: research/treasury_extension/RESEARCH_LOG.md and results/execution_log.txt.
- Original live workflow: research/live_trials/agent_execution_log.md and per-run execution_log.json.
- Trial 2: source_substitution raw retrieval metadata, issued approval/issuance files and post_cutoff_validation test logs.
- Trials 3–4: preparation capture.py, captured payloads and metadata, validate_candidates.py, candidate test_logs, recorded approvals and issuance receipts. Trial 4 also has candidate_execution.log.
- This consolidation used filesystem search/read tools and Python. It parsed saved forecast records, read the original DOCX XML to confirm the word limit, recomputed historical errors with Decimal and compared SHA-256 manifests. It did not retrieve new market data, run new forecast models or rerun issuance.

This is an index to actual saved evidence, not a verbatim export of all chat tool calls. No complete independently timestamped platform transcript is certified. Include a short authentic transcript or screenshots with the final submission rather than presenting this reconstruction as the original conversation.

## Group completion

Assign members to source/timing review, model/calculation review, reproducibility/evidence packaging, and financial argument/presentation coordination. These are proposed responsibilities, not claims about work by unnamed students. All members must understand the selected model, approve the final submission and contribute to the presentation.

Common-current-input diagnostic only: both equations use Zaf frozen baseline and 20-session reference prices, transformed according to each original model. Coefficients are unchanged. This removes tiny endpoint price differences but does not equalise training histories, samples, labels, weekdays or horizons. It is not a new trial forecast, common-training experiment, attribution of individual effects, or evidence of predictive superiority.

| trial | zaf_C_common_inputs | artemis_OLS_common_inputs | gap_after_common_inputs |
|---|---|---|---|
| 1 | 7587.69 | 7627.42 | 39.73 |
| 2 | 7546.43 | 7591.49 | 45.06 |
| 3 | 7573.50 | 7633.60 | 60.10 |
| 4 | 7697.25 | 7712.85 | 15.60 |

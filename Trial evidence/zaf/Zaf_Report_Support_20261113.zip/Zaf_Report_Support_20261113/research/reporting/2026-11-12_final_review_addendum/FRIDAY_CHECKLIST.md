# Friday 13 November — decisions and execution checklist

- [ ] Before capture: group approves one exact model specification and rationale, named operator/checker/approver/submitter, and fallback-source policy. Resolve B/C spreadsheet naming and Artemis comparability. Do not retune to four realised trials.
- [ ] Capture eligible raw index and any required factor data before 12:00 GMT; preserve actual retrieval times, URLs, publication evidence and hashes. Confirm 12 November daily Close and appropriate Treasury lag. Block uncertain required inputs for human decision.
- [ ] Enforce 13 November 12:00 GMT information cutoff. Final target is official S&P 500 price-index close 20 November 21:00 GMT. Verify calendar/horizon and fully matured training labels using the approved method.
- [ ] Generate the binding point forecast tomorrow only; run independent numerical, chronology, maturity, poisoning, negative-availability and integrity checks. No post-cutoff releases/revisions in inputs.
- [ ] Obtain explicit human/group approval of exact value and model. Record true calculation, approval, issuance and freeze times; distinguish input cutoff from later execution. Do not backdate.
- [ ] Freeze raw/processed data, code/dependencies, inputs/coefficients, precise and two-decimal forecast, logs, validations and checksums; preserve corrections separately.
- [ ] Finalise report PDF within 2,400 words; unique forecast on cover, references, AI declaration and member contribution statement. Evidence-only appendix at most four pages; new analysis belongs in report.
- [ ] Finalise seven-minute presentation and three-minute Q&A roles, plus agent workflow demonstration/recording. Recheck rubric details.
- [ ] Curate final evidence ZIP including binding forecast; verify extraction and offline reproduction, source rights and credential exclusion. The trial-sharing ZIPs alone are not the final binding package.
- [ ] Reconcile definitive actual verification if available; retain pending labels otherwise. Approve treatment of retrospective Trial 1 and post-noon Trials 3/4.
- [ ] Confirm all final filenames, member details, contributions and responsible submitter. Submit report, slides and evidence together by Friday 13 November 17:00 GMT; preserve submission receipt. Presentation 17 November per saved brief.

Unresolved: final model/group ratification; standing fallback policy; official actual references; historical vintages; final report/deck/recording/contributions; binding evidence and submission receipt. No binding forecast was generated in this review.

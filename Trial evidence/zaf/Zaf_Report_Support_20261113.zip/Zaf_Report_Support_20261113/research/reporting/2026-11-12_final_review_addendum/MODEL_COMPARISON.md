# Artemis and Zaf model comparison from actual frozen files

Source: four unchanged Artemis archives in ../Artemis/, their run scripts, forecast_record.json, design matrices, source manifests and validation outputs; Zaf's original code and copied trial manifests. Claims concern the supplied files, not unseen work or later group decisions. artemis_comparison_records.json records exact paths, versions, inputs, coefficients and source statements.

## Specifications that explain different predictions

| Dimension | Artemis in supplied files | Zaf |
|---|---|---|
| Random walk | Yahoo chart API unrounded raw Close | FRED or approved Yahoo two-decimal historical Close; identical displayed baselines |
| Momentum | log(P[t]/P[t−20]) over observed rows | P[t]/P[t−20]−1 over actual XNYS session intervals |
| Regression label | log(target/base) | target/base−1 |
| Forecast mapping | base * exp(predicted log return) | base * (1 + predicted simple return) |
| Momentum coefficient | Fitted per trial with intercept | B fixed 0.25, no OLS. C fitted slope and intercept |
| Second factor | log(VIX[u]/VIX[u−5]), Cboe official VIX CLOSE | D: DGS10 yield difference in percentage points, conservative release lag |
| Training span | Three-year rolling window; minimum 100; 155 rows each trial | Expanding from fixed 2021 boundary; minimum 52; 198 rows each trial |
| Origin weekday | Monday/Tuesday/Wednesday/Thursday to match each trial | Friday-origin training retained for every trial |
| Historical horizon | Next same-weekday date; prior available close fallback up to four calendar days | Exactly six XNYS sessions; ineligible holiday cases excluded |
| Historical clock | 12:00 UTC origins all year; targets nominal date at 16:00 NY | 12:00 Europe/London with DST; actual exchange close timestamps |
| Price history | Yahoo chart raw Close for entire series | FRED historical prices with one approved latest Yahoo supplement in Trials 2–4 |
| Publication treatment | After-cutoff downloads, date filtering, assumed earlier availability | Trial 1 late replay; Trials 2–4 captured pre-noon; historical vintages still unknown |
| Runtime | Python 3.12.14, numpy 2.3.5, pandas 3.0.1 | Python 3.14, numpy 2.5.4, pandas 3.1.0, exchange_calendars 4.13.2 |

The four live targets coincide (9–12 November, 21:00 GMT), and both use an origin-to-target interval of 177 hours. That does not make historical training horizons identical. Artemis's code does not impose an exact-six-exchange-session filter or an early-close calendar; holiday fallback target timestamps retain the nominal date. Its noon UTC history is 13:00 London in BST. These are methodological differences, not proof of leakage or a quantified cause of every forecast gap. Zaf’s audited calendar logic differs. The API’s tiny baseline floating-point differences are visible but do not plausibly account for the large regression-level gaps by themselves.

## Trial-specific Artemis evidence

| Trial | Actual generation UTC (not proven issuance) | Training first / last origin | Latest label | Holiday target fallbacks | Momentum OLS forecast | VIX OLS forecast |
|---|---|---|---|---|---|---|
| 1 | 2026-11-02T22:06:28.174013+00:00 | 2023-11-06 / 2026-10-19 | 2026-10-26 | 14 | 7627.42 | 7626.17 |
| 2 | 2026-11-03T16:25:36.396688+00:00 | 2023-11-07 / 2026-10-20 | 2026-10-27 | 0 | 7591.49 | 7591.16 |
| 3 | 2026-11-04T15:35:44.801652+00:00 | 2023-11-08 / 2026-10-21 | 2026-10-28 | 3 | 7633.60 | 7647.59 |
| 4 | 2026-11-05T15:39:12.759133+00:00 | 2023-11-09 / 2026-10-22 | 2026-10-29 | 8 | 7712.85 | 7709.03 |

All supplied Artemis snapshots are after noon. Trials 1–3 explicitly say retrospective reconstruction; Trial 4 says cutoff-filtered afternoon run. Date filtering alone is not historical availability proof. No separate formal human issuance receipt was identified inside these archives; generated timestamps must not be silently labelled issuance. Their forecast records list group approval pending. This does not establish whether approval exists elsewhere.

| Trial | Artemis momentum intercept | Artemis momentum slope | Artemis VIX intercept | Artemis VIX momentum slope | Artemis VIX slope |
|---|---|---|---|---|---|
| 1 | 0.005636768084631624 | -0.03167066133465402 | 0.0055716621569328354 | -0.026810367619910146 | 0.004956329399947375 |
| 2 | 0.004994859460223048 | -0.0535046384852771 | 0.005000378931231478 | -0.05388799351094103 | -0.00043340589502939824 |
| 3 | 0.006148404299653787 | -0.07266164968518699 | 0.005964906256057826 | -0.05889624969124576 | 0.014219759066598517 |
| 4 | 0.003350803558488177 | 0.01403082926134866 | 0.003177509437671952 | 0.022697759544403028 | 0.01089862183712366 |

Zaf coefficients (same in all four trials because the 198-row eligible sample is unchanged):

| Model | Intercept | Momentum slope | Yield slope |
|---|---|---|---|
| A | 0.0 | 0.0 | 0.0 |
| B | 0.0 | 0.25 | 0.0 |
| C | 0.0015511880393786525 | 0.029567571499616106 | 0.0 |
| D | 0.0017884990839572338 | 0.025837241161382248 | -0.024935344605322866 |

The sign and level of the fitted slopes differ because the return transformation, labels, weekday and estimation sample differ. The second factors measure different economic mechanisms: volatility/risk sentiment versus interest-rate discounting. This comparison identifies concrete differences; it does not perform a controlled attribution or endorse either method.

## Recommended distinct names

| Owner/model | Suggested descriptive name |
|---|---|
| Zaf A | Unchanged price benchmark |
| Zaf B | Fixed 0.25 × 20-session simple momentum (not OLS) |
| Zaf C | Expanding Friday six-session simple-return momentum OLS |
| Zaf D | Expanding Friday momentum + lagged DGS10-change OLS |
| Artemis momentum | Three-year matched-weekday log-return momentum OLS |
| Artemis VIX | Three-year matched-weekday log-return momentum + VIX-log-change OLS |

The group spreadsheet labels need discussion: by Zaf's requested mapping, “Momentum20 only OLS” contains Model B and “OLS MODEL NO.2” contains C. The former is misleading because Zaf B does not fit OLS. Artemis's “Momentum20 only OLS” actually does fit OLS, and is closer in structure to Zaf C, though still not the same specification. Model D is absent from that three-row sheet but fully included here. No workbook labels or other members' files were changed in this task.

## Uncertainties

Exact historical publication and value vintages remain unverified for both teams. Zaf's pre-noon live captures provide stronger trial-date observed-by evidence for Trials 2–4, not a certification of all historical training inputs. Artemis raw prices can include later observations; the original code filters them by date but cannot establish earlier availability from a late download. Some original Artemis scripts use fixed local snapshot locations; archive contents must be placed in their expected comparison/ layout before replay. The included Artemis ZIPs are preserved, not repackaged or repaired. No team is declared statistically superior and no final model is selected.

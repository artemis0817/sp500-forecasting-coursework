# 12 November final pre-submission review

Prepared 2026-11-12T21:18:29.768303+00:00; no binding forecast or model selection has been made. All four actuals are secondary-source corroborated; definitive official-reference confirmation remains pending. Trial 1 is retrospective/unissued. Trial 2 was issued before noon. Trials 3/4 were issued after noon under explicitly approved execution protocols using pre-noon captures; they do not meet the original pre-noon issuance rule.

## Trial 4
| model | forecast | actual | signed_error | absolute_error | APE_pct | score_of_50 | rank |
|---|---|---|---|---|---|---|---|
| A | 7688.62 | 7592.40 | 96.22 | 96.22 | 1.267320 | 43.66 | 2 |
| B | 7660.74 | 7592.40 | 68.34 | 68.34 | 0.900111 | 45.50 | 1 |
| C | 7697.25 | 7592.40 | 104.85 | 104.85 | 1.380986 | 43.10 | 3 |
| D | 7707.16 | 7592.40 | 114.76 | 114.76 | 1.511512 | 42.44 | 4 |

## All trial results
| trial | model | forecast | actual | APE_pct | score_of_50 | rank |
|---|---|---|---|---|---|---|
| 1 | A | 7580.07 | 7549.94 | 0.399076 | 48.00 | 2 |
| 1 | B | 7545.07 | 7549.94 | 0.064504 | 49.68 | 1 |
| 1 | C | 7587.69 | 7549.94 | 0.500004 | 47.50 | 4 |
| 1 | D | 7586.23 | 7549.94 | 0.480666 | 47.60 | 3 |
| 2 | A | 7541.40 | 7520.93 | 0.272174 | 48.64 | 1 |
| 2 | B | 7485.00 | 7520.93 | 0.477733 | 47.61 | 3 |
| 2 | C | 7546.43 | 7520.93 | 0.339054 | 48.30 | 2 |
| 2 | D | 7560.34 | 7520.93 | 0.524004 | 47.38 | 4 |
| 3 | A | 7568.92 | 7619.38 | 0.662259 | 46.69 | 3 |
| 3 | B | 7508.42 | 7619.38 | 1.456286 | 42.72 | 4 |
| 3 | C | 7573.50 | 7619.38 | 0.602149 | 46.99 | 2 |
| 3 | D | 7593.19 | 7619.38 | 0.343729 | 48.28 | 1 |
| 4 | A | 7688.62 | 7592.40 | 1.267320 | 43.66 | 2 |
| 4 | B | 7660.74 | 7592.40 | 0.900111 | 45.50 | 1 |
| 4 | C | 7697.25 | 7592.40 | 1.380986 | 43.10 | 3 |
| 4 | D | 7707.16 | 7592.40 | 1.511512 | 42.44 | 4 |

## Qualified forward-issued Trials 2–4
| model | mean_APE_pct | average_score | wins |
|---|---|---|---|
| A | 0.733917 | 46.33 | 1 |
| B | 0.944710 | 45.28 | 1 |
| C | 0.774063 | 46.13 | 0 |
| D | 0.793082 | 46.03 | 1 |

The all-four mixed-status and strict pre-noon-only aggregates are separate in AGGREGATE_ACCURACY.csv. Three forward-issued observations are not three timely-noon issuances. Forecast windows strongly overlap; none of these tiny samples establishes statistical superiority. Mixing retrospective and prospective results without labels would misrepresent the evidence.

## Historical and provisional selection assessment
C's primary52 MAPE 1.425992% versus A 1.447796% is a small advantage. On primary59 C 1.807673% versus A 1.828480%. Origins respectively 18 July 2025–16 October 2026 and 5 January 2024–20 June 2025. See HISTORICAL_CONTEXT.md for medians, maxima and sensitivity panels. Separate evaluation dates do not make the research independent: training exposure, repeated specification choices, six-session overlap and reused October cases matter. The 52-panel C-minus-A uncertainty interval crosses zero. D adds yield timing and estimation uncertainty without a historical advantage over C.

Keep A as provisional default and C as challenger for group discussion. A avoids parameter estimation and has the simplest reproducible implementation. C has modest historical mean gains but greater estimation sensitivity and does not uniformly improve tail errors. The new short trial rankings do not warrant retuning or automatic selection. B's fixed trend extrapolation is different from OLS and can benefit from particular price directions without establishing robustness.

Artemis momentum-only OLS is a plausible alternative specification, not a replica of Zaf C. It estimates log returns on rolling three-year matched-weekday samples (155 rows); Zaf C uses expanding simple returns with Friday origins and exact-six-session labels (198 rows). Sources, holiday fallback and historical clocks differ. Artemis VIX OLS is not Zaf D's yield regression. No equivalent longer audited Artemis backtest or complete pre-noon publication evidence is established by the supplied archives; do not elevate its four reconstructed forecasts to independent prospective validation. The common-current-input diagnostic retains substantial forecast differences after price endpoints are equalised, so endpoint rounding alone cannot explain the gaps. It does not identify each methodological contribution.

Naming proposals for group approval: B = Fixed 0.25 × 20-session simple momentum; C = Expanding Friday six-session simple-return momentum OLS; Artemis = Three-year matched-weekday log-return momentum OLS. Correct the misleading workbook mapping during final editorial sign-off; do not relabel frozen outputs or merge their scores.

## Provenance and submission readiness
The four frozen packages and previous evaluations passed manifest checks. Prior historical inventory exceptions remain documented: inherited references and compiled bytecode exceptions were not repaired. Source first-publication and historical vintage evidence remains incomplete. User approvals do not establish a standing group fallback policy. The six Zaf sharing files were pushed in commit 49c254f2a5a213afbaef9ff96f235b1adbe76bc9; local origin/main matches at review time, but this is not a fresh remote fetch. Sharing archives have offline reproduction evidence, not a clean-machine dependency-install certification. This review is local, not submitted or uploaded.

The existing coursework draft is 1,598 whitespace-counted words against the rubric's 2,400-word maximum before integration. Do not append this whole research addendum to the submission; integrate concise findings and recount narrative tables/captions. Group must sign off model, fallback policy, treatment of post-noon trials, definitive/indicative actual status and final submission artifacts. No completed final report/deck/binding evidence is certified here.

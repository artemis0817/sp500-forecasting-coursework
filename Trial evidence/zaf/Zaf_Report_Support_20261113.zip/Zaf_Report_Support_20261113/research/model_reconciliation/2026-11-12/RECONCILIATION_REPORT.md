# Zaf C versus Artemis Momentum20-only OLS

## Conclusion
All eight requested original forecasts reproduce at full-precision tolerance <1e-8 index points and exactly to two decimals. Zaf's unchanged portable code also reproduces all 16 A–D forecasts; the unchanged Artemis scripts reproduce all 12 archived model forecasts. There is no unexplained numerical gap after specification alignment. Under identical 198-row samples, features, labels and simple-return mapping, coefficients and forecasts match exactly in this runtime for all four trials. This is an offline reconciliation, not issuance or new prospective evidence.

| Trial | Zaf C | Artemis momentum OLS | Artemis minus Zaf, points |
|---|---|---|---|
| 1 | 7587.69 | 7627.42 | 39.731836 |
| 2 | 7546.43 | 7591.49 | 45.060395 |
| 3 | 7573.50 | 7633.60 | 60.099119 |
| 4 | 7697.25 | 7712.85 | 15.595793 |

## Raw inputs and provenance
The common data are EACH trial's frozen Zaf FRED history, plus its single approved latest Yahoo Close for Trials 2–4. No subsequent downloads or realised November trial outcomes are used. These are four cutoff-specific datasets, not one later vintage applied backwards. Zaf's usable history starts 1 November 2021; Artemis Yahoo chart history begins in November 2016. Extra earlier Artemis history is outside its three-year fitting window.

There are 1,255 / 1,256 / 1,257 / 1,258 overlapping nonmissing observations. Every overlapping value agrees to two decimals. The largest raw difference is 0.000234375 points (Yahoo floating representation versus decimal hundredths). Neither source has missing expected exchange sessions within the common span. FRED blank holiday rows and Yahoo null/duplicate counts are separately recorded in RAW_SERIES_AUDIT.json; missing holiday rows are not missing trading sessions. PRICE_SERIES_COMPARISON.csv lists every date and value, including nonoverlapping history. Original raw payloads and exact provenance are retained under archive/ and artemis/; SOURCE_PROVENANCE.json identifies manifest paths, URLs, hashes and Artemis retrieval timestamps. Post-cutoff chart rows are excluded.

Trial 1 is a retrospective replay. Trials 2–4 Zaf captures precede their noon cutoffs, but historical publication times and vintage revisions are unverified. Artemis snapshots are after noon. Scheduled market-close timestamps establish outcome maturity under a calendar proxy, not proof of publisher availability or vintage eligibility. No strict historical-publication certification is claimed.

## Declared reconciliation order
Starting with Artemis: (1) substitute the complete Zaf price series; (2) change both predictor and response from log to simple returns and use 1+r rather than exp(r); (3) use the expanding 2021 boundary instead of three rolling years; (4) change matched weekdays to Fridays; (5) enforce exchange-session lookbacks and Europe/London historical noon/actual close clocks; (6) exclude closed nominal targets and all labels that are not exactly six exchange sessions. Each subsequent row changes only that declared factor or coherent convention bundle. Return-transform step changes predictor, outcome and level mapping together, not three separately attributed effects. The 2021 data boundary has the original 20-session warm-up; no extra earlier Yahoo data is supplied to the expanding fit.

| Step | Trial 1 | Trial 2 | Trial 3 | Trial 4 |
|---|---|---|---|---|
| 0_original_artemis | 7627.42 | 7591.49 | 7633.60 | 7712.85 |
| 1_common_price_series | 7627.42 | 7591.49 | 7633.60 | 7712.85 |
| 2_simple_returns | 7629.86 | 7593.27 | 7633.48 | 7714.42 |
| 3_expanding_window | 7612.84 | 7572.92 | 7609.09 | 7700.33 |
| 4_friday_origins | 7603.74 | 7566.52 | 7594.42 | 7712.07 |
| 5_exchange_calendar_and_London_clock | 7603.74 | 7566.52 | 7594.42 | 7712.07 |
| 6_exact_six_sessions_no_holiday_fallback | 7587.69 | 7546.43 | 7573.50 | 7697.25 |

### Incremental effects in index points
Positive means the change raises the forecast. These differences telescope to each original Artemis-to-Zaf gap using unrounded values.

| Change | Trial 1 | Trial 2 | Trial 3 | Trial 4 |
|---|---|---|---|---|
| 1_common_price_series | +0.000143 | +0.000127 | -0.000004 | -0.000178 |
| 2_simple_returns | +2.439365 | +1.781819 | -0.120499 | +1.577554 |
| 3_expanding_window | -17.023429 | -20.350048 | -24.397547 | -14.092644 |
| 4_friday_origins | -9.094626 | -6.397821 | -14.667936 | +11.744827 |
| 5_exchange_calendar_and_London_clock | +0.000000 | +0.000000 | +0.000000 | +0.000000 |
| 6_exact_six_sessions_no_holiday_fallback | -16.053289 | -20.094472 | -20.913133 | -14.825352 |

Data substitution changes each forecast by less than 0.0002 points. On this path, the training window, weekday and six-session eligibility drive most of the gap; return transformations contribute smaller changes. The weekday effect reverses sign in Trial 4. These are controlled code comparisons, not causal claims about markets or additive effects independent of order.

ORDER_DEPENDENCE.csv explicitly reverses the return/window order, keeping the other assumptions fixed. Changing returns first gives +2.439365 points in Trial 1; changing returns after expanding the window gives +3.183182. Interaction differences range from about 0.64 to 2.16 points in magnitude across trials. Both paths reach the same endpoint. Other permutations were not exhaustively tested; effects must not be presented as uniquely attributable shares.

## Labels, implementation issues and parity
Artemis's original 155-row fits contain 44 / 31 / 33 / 38 non-six-session labels, with realised horizons ranging 4–6 (Trial 2: 5–6). Holiday fallback occurs in 14 / 0 / 3 / 8 rows. Its nominal next-week target timestamp can differ from the actual prior-close date used; it also records 16:00 New York for early closes. These are material alignment/metadata limitations if the claimed specification is exactly six exchange sessions. They are not proof that future outcomes entered these observed fits: every included realised outcome closes before the respective cutoff.

Under the final Friday specification, the broad sample has 256 rows; removing 58 non-six-session/closed-target cases leaves the original 198. First origin is 3 December 2021, last origin 23 October 2026, latest outcome 30 October. Calendar/clock alignment alone changes no forecasts in these snapshots, since both noon conventions precede the same US daily close. That zero numerical effect does not make UTC noon and London noon interchangeable metadata.

Artemis's momentum-only training builder also requires a valid VIX feature even though VIX is not a regressor. The independent price-only reconstruction matches all original 155-row samples numerically, so this gate has no material effect here; it is an unnecessary dependency that could alter membership if VIX data were missing. Its dropping null prices and shifting by 20 observed rows could span more than 20 exchange sessions in incomplete data. No such missing-session case occurs in the common span; the aligned implementation rejects a deliberately deleted session.

Parity checks compare an independently built bridge ledger with the original Zaf calendar/feature builder. Membership, feature and response arrays are identical; the original Zaf fit and Artemis least-squares expression on the aligned matrix return identical coefficients and levels. A separate 50-digit Decimal centered-sums calculation agrees to <1e-10 in coefficients. This is an adapted identical-specification test, not a claim that the unchanged Artemis end-to-end pipeline implements Zaf's specification.

All 28 stage-specific future-price poisoning and maturity checks pass. Four explicit immature-label injections are rejected and four missing-session tests block. No future trial target is used. Tests cannot remove the historical source-publication/vintage uncertainty. Runtime versions differ from Artemis's original environment, but the archived forecasts reproduce within the stated tolerances.

An initial isolated replay failed while recording its snapshot path because the original Artemis script expects snapshots beneath its own folder. Recreating that expected directory layout resolved it without modifying source bytes. Failed-run files are retained separately. No regression arithmetic bug was identified. Original scripts remain location-dependent, and moving archives without their layout can break execution.

## Shared specification proposed for group decision
For a shared **momentum-only OLS candidate**, adopt the existing Zaf C specification as the baseline to consider: unadjusted S&P 500 price-index closes; one approved frozen source series; 20 exchange-session simple-return momentum; simple-return response; intercept plus one OLS slope; expanding window from the established 2021 boundary after warm-up; Friday origins; exact-six-session outcomes; minimum 52 matured observations; timezone-aware noon cutoff and actual exchange closes; documented availability and fallback policy. Re-estimation is permitted only under those fixed rules, never based on selecting the best result from these four trials.

This choice has an existing 52/59-origin audit trail, direct level interpretation, a larger sample and a Friday training schedule that matches the forthcoming Friday origin. Trade-offs: older regimes can dilute recent relationships; Friday-only filtering discards data; simple returns are not time-additive and unconstrained linear forecasts can be implausible in extremes; existing historical publication evidence remains incomplete. Rolling log-return OLS is defensible as a separately specified challenger with greater regime responsiveness, but a smaller sample and additional window sensitivity. Log-to-level exp(predicted log return) is the archived convention, not an estimated conditional arithmetic-mean correction.

Do not automatically select C over the random-walk default. If the group adopts Artemis's rolling/log variant or a hybrid, rerun the same time-ordered historical origins and target definitions, mature-label and availability tests, independent numerical checks, calendar/holiday/DST cases, missing-data tests and predeclared robustness analyses. Compare paired losses against A and existing C; retain overlap/selection-exposure caveats. Do not choose a window/transform by the four realised November outcomes. These reconciliation scripts deliberately do not read evaluation scores.

**Exact approval required:** approve (or reject) the proposed shared OLS specification above, the authoritative price-source/fallback and historical-availability conventions, and whether this candidate or Model A becomes the binding group model. If choosing another OLS definition, approve its complete return/window/weekday/horizon rules and historical revalidation before issuance. Record the decision and named sign-off; do not rename or merge existing outputs. Zaf B must remain labelled Fixed 0.25 × 20-session Momentum, not OLS.

## Evidence and preservation
COMPARISON.csv contains full-precision intercepts, slopes, native and simple predicted returns, levels, increments, samples and cutoffs. Each stage has its training ledger and exclusions. PARITY_TESTS.json and results/ADDITIONAL_TESTS.json record parity/negative tests. 349 original/nested archive members match their ZIP bytes, and 2,450 existing trial/report/archive files were verified unchanged. comparison.zip and originals were not edited. No Git operation or binding forecast was performed. Hashes certify file integrity, not contemporaneous public availability. See README.md for offline reproduction.

The documented offline wrapper was successfully executed in a fresh sibling folder. Comparison tables, parity tests, raw audits, order diagnostics and cutoff tests are byte-identical. Original Artemis 155-row memberships and saved feature/label values also match the independent reconstruction (1e-11 tolerance for the archived 12-decimal CSV). See results/CROSS_RUN_REPRODUCTION.json.

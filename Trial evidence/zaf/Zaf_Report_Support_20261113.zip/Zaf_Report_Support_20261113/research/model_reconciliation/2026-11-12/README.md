# Isolated model reconciliation

Read RECONCILIATION_REPORT.md, COMPARISON.csv and PARITY_TESTS.json. This package uses only comparison.zip snapshots. It is not a live run, issuance, scoring exercise or group model approval.

- archive/: exact extracted comparison.zip entries.
- artemis/: exact nested Artemis archive entries.
- working/: byte-identical original Artemis scripts executed with copies of packaged raw snapshots in their expected local layout. Newly generated records here are diagnostic replays, not original issuance.
- results/: original reproductions, raw-series differences/provenance, full-precision stage fits, training/exclusion ledgers, order-dependence diagnostics and tests.
- failed_attempt_*: retained initial path-layout failure, not valid final results.
- original_hashes.json: hashes of pre-existing files before work.
- SHA256.json: this package's file hashes, excluding the manifest itself.

Run from the project root with the already validated project dependencies:

```sh
PYTHONPATH=research/vendor PYTHONDONTWRITEBYTECODE=1 /opt/anaconda3/bin/python3.14 research/model_reconciliation/2026-11-12/run_offline.py independent_recheck
```

The destination must not already exist. This executes packaged Zaf and Artemis originals, the sequential bridge, parity/negative tests and report generation. It does not fetch data, use realised trial scores, issue a forecast or access GitHub. Python 3.14 with the pinned dependencies in archive/Zaf/requirements.txt is required; archive/Zaf/reproduce.py provides portable model reproduction. Set the interpreter path for another machine. The wrapper expects the existing project layout and source comparison.zip; local absolute provenance paths identify originals. Different run timestamps are expected; numerical outputs should match within 1e-8 points and coefficients within 1e-10. Test only on preserved snapshots; do not silently replace historical data with a fresh download.

Method: Artemis original → common Zaf prices → simple returns → expanding window → Friday origins → exchange calendar/London clock → exact-six-session outcomes. Effects depend on this order. The limited reverse-order return/window test demonstrates interactions. Identical-spec parity means aligned data, row membership, return transformations and output mapping; it does not imply unchanged models were originally identical. Scheduled-close maturity is tested; true historical publication/vintage availability remains unverified.

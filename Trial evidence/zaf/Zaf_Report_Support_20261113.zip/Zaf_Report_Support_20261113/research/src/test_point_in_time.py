"""Adversarial PIT tests: do not treat forecast accuracy as evidence against leakage."""
import unittest,copy,math,ast,json
from datetime import date,datetime,timedelta,timezone
from zoneinfo import ZoneInfo
import run_backtest as b
from audit_point_in_time import read,A,old_module

class PointInTimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,_=b.load_prices();cls.cal=b.xc.get_calendar('XNYS',start=str(b.START),end=str(b.CUT))
        cls.rows,_=b.build(cls.p,cls.cal);cls.pool=[r for r in cls.rows if r['horizon_sessions']==6]
        cls.tests=cls.pool[-52:];cls.old=old_module()
        cls.before=read(A/'before/results/primary_forecasts.csv')
        cls.adversarial=[]
    @classmethod
    def tearDownClass(cls):
        b.write_csv(A/'validation/adversarial_results_52.csv',sorted(cls.adversarial,key=lambda r:r['origin']))

    def predict(self,r,pool=None,prices=None):
        return b.evaluate([r],self.pool if pool is None else pool,'test',self.p if prices is None else prices,cal=self.cal)[0]

    def test_01_actual_frequency_and_original_timezone_failure_detected(self):
        self.assertEqual(len(self.tests),52)
        for r in self.before:self.assertEqual(date.fromisoformat(r['origin']).weekday(),4)
        bad=[r for r in self.before if datetime.fromisoformat(r['origin_utc']).astimezone(b.LONDON).hour!=12]
        self.assertGreater(len(bad),0) # The old test suite explicitly allowed this error.
        for r in self.tests:
            stamp=datetime.fromisoformat(r['origin_utc']).astimezone(b.LONDON)
            self.assertEqual((stamp.weekday(),stamp.hour,stamp.minute),(4,12,0))

    def test_02_every_feature_window_uses_past_exchange_sessions(self):
        sessions=[s.date() for s in self.cal.sessions]
        for r in self.tests:
            stamp=b.origin_at(r['origin']);prior=self.cal.schedule[self.cal.schedule['close']<stamp]
            self.assertEqual(r['base_date'],prior.index[-1].date())
            j=sessions.index(r['base_date']);self.assertEqual(r['lookback_date'],sessions[j-20])
            for d in sessions[j-20:j+1]:self.assertLess(b.close_at(self.cal,d),stamp)
            self.assertAlmostEqual(r['momentum'],self.p[r['base_date']]/self.p[r['lookback_date']]-1,places=14)

    def test_03_every_training_row_independent_timestamp_oracle(self):
        for r in self.tests:
            ts=b.origin_at(r['origin']);eligible=[]
            for t in self.pool:
                expected=b.close_at(self.cal,t['target_date'])<ts
                got,_=b.training_eligibility(t,r['origin'],self.cal)
                self.assertEqual(expected,got)
                if got:
                    self.assertLess(b.close_at(self.cal,t['base_date']),b.origin_at(t['origin']))
                    eligible.append(t)
            pred=self.predict(r);self.assertEqual(pred['train_n'],len(eligible))
            coef,_=b.fit(eligible)
            self.assertEqual(float(coef[0]),pred['intercept']);self.assertEqual(float(coef[1]),pred['beta'])

    def test_04_all_52_future_price_and_unmatured_label_poisoning(self):
        keys=['A_forecast','B_forecast','C_forecast','intercept','beta','train_n']
        oldrows,_=self.old.build(self.p,self.cal);oldpool=[r for r in oldrows if r['horizon_sessions']==6]
        oldlookup={r['origin']:r for r in oldpool}
        for r in self.tests:
            original=self.predict(r);ts=b.origin_at(r['origin'])
            # Includes the current Friday's not-yet-closed price, not just later dates.
            altered={d:v*(3.17+(d.toordinal()%13)/7) if b.close_at(self.cal,d)>=ts else v for d,v in self.p.items()}
            # Features are rebuilt using only altered prices; target placeholder cannot affect forecast.
            inputs=b.forecast_inputs(altered,self.cal,r['origin'],r['target_date']);inputs['actual']=altered[r['target_date']]
            altered_pool=[]
            for t in self.pool:
                z=dict(t,base=altered[t['base_date']],momentum=altered[t['base_date']]/altered[t['lookback_date']]-1)
                z['return']=altered[t['target_date']]/altered[t['base_date']]-1
                altered_pool.append(z)
            changed=self.predict(inputs,altered_pool,altered)
            poisoned=[];n=0
            for t in self.pool:
                z=dict(t)
                if b.close_at(self.cal,t['target_date'])>=ts:
                    z['return']=10000.+n;z['momentum']=-7000.-n;n+=1
                poisoned.append(z)
            poison_result=self.predict(r,poisoned)
            # Check the old implementation too, not only repaired code.
            op=self.old.evaluate([oldlookup[r['origin']]],oldpool,'old',self.p)[0]
            oldpoison=[dict(t,**{'return':10000.}) if t['target_date']>=r['origin'] else t for t in oldpool]
            oq=self.old.evaluate([oldlookup[r['origin']]],oldpoison,'old',self.p)[0]
            for k in keys:
                self.assertEqual(original[k],changed[k]);self.assertEqual(original[k],poison_result[k]);self.assertEqual(op[k],oq[k])
            # Remove all future prices and all ineligible labels entirely.
            prefix={d:v for d,v in self.p.items() if b.close_at(self.cal,d)<ts}
            prefix_inputs=b.forecast_inputs(prefix,self.cal,r['origin'],r['target_date']);prefix_inputs['actual']=1.
            eligible=[t for t in self.pool if b.close_at(self.cal,t['target_date'])<ts]
            truncated=self.predict(prefix_inputs,eligible,prefix)
            for k in keys:self.assertEqual(original[k],truncated[k])
            self.adversarial.append({'origin':r['origin'],'future_prices_perturbed':len(self.p)-len(prefix),
                'unmatured_labels_poisoned':n,'max_forecast_or_coefficient_change':max(abs(original[k]-changed[k]) for k in keys),
                'future_price_test':'PASS','unmatured_label_test':'PASS','prefix_only_test':'PASS','old_code_label_test':'PASS'})

    def test_05_unresolved_labels_and_spoofed_timestamps(self):
        r=self.tests[20];original=self.predict(r)
        mature=next(t for t in self.pool if b.training_eligibility(t,r['origin'],self.cal)[0])
        unresolved=dict(mature,**{'return':None})
        self.assertFalse(b.training_eligibility(unresolved,r['origin'],self.cal)[0])
        self.assertFalse(b.training_eligibility(dict(mature,target_date=None),r['origin'],self.cal)[0])
        future=next(t for t in self.pool if t['target_date']>=r['origin'])
        spoof=dict(future,target_close_utc='1999-01-01T00:00:00+00:00',**{'return':1e8})
        self.assertFalse(b.training_eligibility(spoof,r['origin'],self.cal)[0])
        changed=self.predict(r,self.pool+[unresolved,spoof])
        for k in ['C_forecast','intercept','beta','train_n']:self.assertEqual(original[k],changed[k])

    def test_06_same_day_close_excluded_and_matured_holdout_can_enter(self):
        saw_same=False;saw_matured=False;holdout={r['origin'] for r in self.tests}
        for r in self.tests:
            for t in self.pool:
                yes,_=b.training_eligibility(t,r['origin'],self.cal)
                if t['target_date']==r['origin']:self.assertFalse(yes);saw_same=True
                if t['origin'] in holdout and yes:
                    self.assertLess(b.close_at(self.cal,t['target_date']),b.origin_at(r['origin']));saw_matured=True
        self.assertTrue(saw_same and saw_matured)

    def test_07_DST_mismatch_weeks_and_holidays(self):
        for day,utc_hour,ny_hour in [('2026-03-13',12,8),('2026-03-27',12,8),('2026-04-10',11,7),('2025-10-31',12,8),('2026-01-16',12,7)]:
            ts=b.origin_at(date.fromisoformat(day));self.assertEqual(ts.astimezone(timezone.utc).hour,utc_hour)
            self.assertEqual(ts.astimezone(b.NEW_YORK).hour,ny_hour)
        x=b.forecast_inputs(self.p,self.cal,date(2025,11,28),date(2025,12,5))
        self.assertEqual(x['base_date'],date(2025,11,26));self.assertEqual(x['horizon_sessions'],6)
        x=b.forecast_inputs(self.p,self.cal,date(2025,11,21),date(2025,11,28))
        self.assertEqual(x['horizon_sessions'],5)
        self.assertEqual(b.close_at(self.cal,date(2025,11,28)).astimezone(b.NEW_YORK).hour,13)
        with self.assertRaises(ValueError):b.forecast_inputs(self.p,self.cal,date(2026,3,27),date(2026,4,3))
        x=b.forecast_inputs(self.p,self.cal,date(2026,7,3),date(2026,7,10))
        self.assertEqual(x['base_date'],date(2026,7,2));self.assertEqual(x['horizon_sessions'],5)

    def test_08_missing_latest_close_rejected_not_silently_stale(self):
        r=self.tests[10];missing=dict(self.p);del missing[r['base_date']]
        with self.assertRaises(ValueError):b.forecast_inputs(missing,self.cal,r['origin'],r['target_date'])

    def test_09_negative_control_detects_intentional_leaky_fit(self):
        r=self.tests[20];ts=b.origin_at(r['origin'])
        valid=[t for t in self.pool if b.close_at(self.cal,t['target_date'])<ts]
        future=next(t for t in self.pool if b.close_at(self.cal,t['target_date'])>=ts)
        poisoned=dict(future,**{'return':10.})
        a,_=b.fit(valid+[future]);z,_=b.fit(valid+[poisoned])
        self.assertGreater(float(max(abs(a-z))),1e-5)
        (A/'validation/leaky_negative_control.json').write_text(json.dumps({'intentionally_leaky_coefficient_change':float(max(abs(a-z))),
            'test':'PASS: poison changes intentionally leaky coefficients; production filter excludes row'},indent=2))

    def test_10_no_scaler_feature_search_or_hyperparameter_search_in_model_path(self):
        tree=ast.parse((b.ROOT/'src/run_backtest.py').read_text())
        calls=[ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)]
        for name in ['StandardScaler','MinMaxScaler','GridSearchCV','RandomizedSearchCV','rolling','shift']:
            self.assertFalse(any(name in c for c in calls))
        for r in self.tests:
            out=self.predict(r);self.assertEqual(out['B_forecast'],r['base']*(1+.25*r['momentum']))

if __name__=='__main__':unittest.main(verbosity=2)

"""Independent calendar/timestamp audit of old and corrected rolling forecasts."""
from pathlib import Path
import csv,io,json,importlib.util,collections
from datetime import datetime,time,timedelta,timezone,date
from zoneinfo import ZoneInfo
import run_backtest as b
A=b.ROOT/'pit_audit'
def read(path):return list(csv.DictReader(io.StringIO(path.read_text())))
def old_module():
    spec=importlib.util.spec_from_file_location('before_backtest',A/'before/src/run_backtest.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def main():
    prices,_=b.load_prices();cal=b.xc.get_calendar('XNYS',start=str(b.START),end=str(b.CUT))
    old=old_module();oldrows,_=old.build(prices,cal);oldpool=[r for r in oldrows if r['horizon_sessions']==6]
    corrected,_=b.build(prices,cal);pool=[r for r in corrected if r['horizon_sessions']==6]
    originals=read(A/'before/results/primary_forecasts.csv');new=read(b.ROOT/'results/primary_forecasts.csv')
    holdout={r['origin'] for r in originals};audit=[];training=[];used_holdout=0
    sessions=[x.date() for x in cal.sessions]
    for r,n in zip(originals,new):
        day=date.fromisoformat(r['origin']);stamp=datetime.combine(day,time(12),ZoneInfo('Europe/London'))
        oldstamp=datetime.fromisoformat(r['origin_utc']);used=date.fromisoformat(r['base_date'])
        prior=cal.schedule[cal.schedule['close']<stamp];latest=prior.index[-1].date()
        look=date.fromisoformat(r['lookback_date']);target=date.fromisoformat(r['target_date'])
        feature=cal.schedule.loc[str(used),'close'].to_pydatetime()
        lookstamp=cal.schedule.loc[str(look),'close'].to_pydatetime()
        end=cal.schedule.loc[str(target),'close'].to_pydatetime()
        all_known=all(cal.schedule.loc[str(d),'close']<stamp for d in sessions[sessions.index(look):sessions.index(used)+1])
        included=[];original_count=0
        for t in pool:
            tf=cal.schedule.loc[str(t['base_date']),'close'].to_pydatetime()
            tt=cal.schedule.loc[str(t['target_date']),'close'].to_pydatetime()
            train_origin=datetime.combine(t['origin'],time(12),ZoneInfo('Europe/London'))
            # Independent eligibility oracle; no production training_eligibility call.
            eligible=(tt<stamp and tf<train_origin and tf<stamp and t['return'] is not None)
            old_included=t['target_date']<day
            production,why=b.training_eligibility(t,day,cal)
            assert eligible==production==old_included
            assert tf<train_origin and t['lookback_date']<t['base_date']
            if eligible:included.append(t)
            if old_included:original_count+=1
            is_heldout=str(t['origin']) in holdout
            if eligible and is_heldout:used_holdout+=1
            training.append({'forecast_origin_timestamp':stamp.isoformat(),'forecast_origin_utc':stamp.astimezone(timezone.utc).isoformat(),
                'training_origin_timestamp':train_origin.isoformat(),'training_feature_date':t['base_date'],
                'training_feature_timestamp':tf.isoformat(),'training_lookback_date':t['lookback_date'],
                'training_lookback_timestamp':b.close_at(cal,t['lookback_date']).isoformat(),
                'training_target_date':t['target_date'],'training_target_timestamp':tt.isoformat(),
                'feature_value':t['momentum'],'target_return':t['return'],
                'feature_available_at_own_origin':tf<train_origin,'target_closed_before_fit':tt<stamp,
                'old_date_filter_included':old_included,'parameter_fitting_eligible':eligible,
                'production_filter_included':production,'eligibility_reason':why,
                'training_row_is_heldout_origin':is_heldout,
                'FRED_publication_timestamp':'UNVERIFIED','value_vintage':'current retrieval; historical vintage unverified'})
        assert original_count==int(r['train_n'])==int(n['train_n'])
        audit.append({'forecast_origin_timestamp':stamp.isoformat(),'forecast_origin_utc':stamp.astimezone(timezone.utc).isoformat(),
            'forecast_origin_new_york':stamp.astimezone(ZoneInfo('America/New_York')).isoformat(),
            'original_forecast_origin_timestamp':oldstamp.isoformat(),
            'original_origin_in_London':oldstamp.astimezone(ZoneInfo('Europe/London')).isoformat(),
            'original_is_Friday_noon_London':oldstamp.astimezone(ZoneInfo('Europe/London')).hour==12 and day.weekday()==4,
            'correction_minutes':(stamp-oldstamp).total_seconds()/60,
            'latest_eligible_price_date':latest,'actual_price_date_used':used,
            'used_most_recent_calendar_close':used==latest,'price_close_timestamp_utc':feature.isoformat(),
            'price_close_timestamp_New_York':feature.astimezone(ZoneInfo('America/New_York')).isoformat(),
            'hours_since_baseline_close':(stamp-feature).total_seconds()/3600,
            'lookback_price_date':look,'lookback_close_timestamp':lookstamp.isoformat(),
            'momentum_session_intervals':sessions.index(used)-sessions.index(look),
            'all_21_window_prices_closed_before_origin':all_known,
            'target_date':target,'target_timestamp_utc':end.isoformat(),
            'target_timestamp_New_York':end.astimezone(ZoneInfo('America/New_York')).isoformat(),
            'sessions_baseline_to_target':sessions.index(target)-sessions.index(used),
            'sessions_closing_after_origin_to_target':len(cal.schedule[(cal.schedule['close']>stamp)&(cal.schedule['close']<=end)]),
            'training_rows_included':len(included),'training_rows_excluded':len(pool)-len(included),
            'latest_included_training_target_timestamp':max(b.close_at(cal,t['target_date']) for t in included).isoformat(),
            'original_and_corrected_forecasts_equal':all(float(r[f'{m}_forecast'])==float(n[f'{m}_forecast']) for m in 'ABC'),
            'historical_FRED_availability':'UNVERIFIED','historical_FRED_revision_status':'UNVERIFIED'})
    b.write_csv(A/'results/origin_audit_52.csv',audit)
    b.write_csv(A/'results/training_row_audit.csv',training)
    # Audit BOTH sensitivity panels, including corrected lag-label timestamp metadata.
    panel_audits=[];panel_training=[];old_lag_bad=0
    for label,lag in [('holiday',False),('delayed',True)]:
        rows=read(b.ROOT/f'results/{label}_forecasts.csv')
        candidates=pool
        if lag:
            lagrows,_=b.build(prices,cal,lag=1);candidates=[];days=list(prices)
            for r in lagrows:
                td=days[r['base_index']+6]
                if r['target_close_utc']!=b.close_at(cal,td).isoformat():old_lag_bad+=1
                candidates.append(dict(r,original_target_close_utc=r['target_close_utc'],
                    target_date=td,target_close_utc=b.close_at(cal,td).isoformat(),
                    actual=prices[td],horizon_sessions=6,**{'return':prices[td]/r['base']-1}))
        for r in rows:
            day=date.fromisoformat(r['origin']);ts=b.origin_at(day)
            included=[]
            for t in candidates:
                yes,why=b.training_eligibility(t,day,cal,lag)
                target_ts=b.close_at(cal,t['target_date'])
                assert t['target_close_utc']==target_ts.isoformat()
                expected=target_ts<ts
                if lag:
                    prior=cal.schedule[cal.schedule['close']<ts].index[-1].date()
                    expected=expected and target_ts<b.close_at(cal,prior)
                assert yes==expected
                if yes:
                    assert target_ts<ts;included.append(t)
                panel_training.append({'panel':label,'forecast_origin_timestamp':ts.isoformat(),
                    'training_origin':t['origin'],'training_feature_timestamp':b.close_at(cal,t['base_date']).isoformat(),
                    'training_target_date':t['target_date'],'training_target_timestamp':target_ts.isoformat(),
                    'old_target_timestamp':t.get('original_target_close_utc',t['target_close_utc']),
                    'old_target_timestamp_matches_date':t.get('original_target_close_utc',t['target_close_utc'])==target_ts.isoformat(),
                    'parameter_fitting_eligible':yes,'reason':why})
            latest=cal.schedule[cal.schedule['close']<ts].index[-1].date()
            used=date.fromisoformat(r['base_date'])
            assert len(included)==int(r['train_n'])
            coef,_=b.fit(included)
            assert abs(coef[0]-float(r['intercept']))<1e-12 and abs(coef[1]-float(r['beta']))<1e-12
            panel_audits.append({'panel':label,'forecast_origin_timestamp':ts.isoformat(),'latest_eligible_price_date':latest,
                'actual_price_date_used':used,'intentional_older_price_scenario':lag,
                'used_most_recent_close':latest==used,'target_date':r['target_date'],'sessions_to_target':r['horizon_sessions'],
                'all_included_labels_closed_before_origin':True,'train_n':len(included)})
    b.write_csv(A/'results/sensitivity_origin_audit.csv',panel_audits)
    b.write_csv(A/'results/sensitivity_training_row_audit.csv',panel_training)
    before=read(A/'before/results/summary.csv');after=read(b.ROOT/'results/summary.csv');comparison=[]
    for a,z in zip(before,after):
        for metric in ['n','MAPE_pct','median_APE_pct','max_APE_pct','beat_A_pct','mean_accuracy_score_of_50']:
            comparison.append({'panel':a['panel'],'model':a['model'],'metric':metric,'before':a[metric],'after':z[metric],
                               'difference':float(z[metric])-float(a[metric])})
    b.write_csv(A/'results/metrics_before_after.csv',comparison)
    intervals=collections.Counter((date.fromisoformat(n['origin'])-date.fromisoformat(r['origin'])).days for r,n in zip(originals,originals[1:]))
    summary={'heldout_origins':len(audit),'all_Fridays':all(date.fromisoformat(r['origin']).weekday()==4 for r in originals),
        'frequency':'weekly Friday candidates; filtered exact-six-session subset, not daily',
        'gaps_calendar_days':dict(intervals),'old_noon_London_mismatches':sum(not r['original_is_Friday_noon_London'] for r in audit),
        'old_correct_noon_London':sum(r['original_is_Friday_noon_London'] for r in audit),
        'all_latest_baselines_correct':all(r['used_most_recent_calendar_close'] for r in audit),
        'baseline_weekdays':dict(collections.Counter(date.fromisoformat(r['base_date']).strftime('%A') for r in originals)),
        'primary_training_candidate_rows_audited':len(training),
        'primary_included_rows_audited':sum(r['parameter_fitting_eligible'] for r in training),
        'primary_excluded_rows_audited':sum(not r['parameter_fitting_eligible'] for r in training),
        'included_previously_matured_heldout_rows':used_holdout,
        'same_day_training_targets_excluded':sum(r['training_target_date']==datetime.fromisoformat(r['forecast_origin_timestamp']).date() for r in training),
        'sensitivity_training_candidate_rows_audited':len(panel_training),
        'old_delayed_training_target_timestamp_mismatches':old_lag_bad,
        'all_primary_forecasts_unchanged':all(r['original_and_corrected_forecasts_equal'] for r in audit),
        'all_panel_metrics_unchanged':all(r['difference']==0 for r in comparison),
        'FRED_point_in_time_certified':False,'binding_forecast_generated':False}
    (A/'results/audit_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Fixed-spec historical replay. Target outcome is introduced ONLY after forecast freeze."""
from pathlib import Path
import csv,io,json,hashlib,shutil
from decimal import Decimal,localcontext,ROUND_HALF_EVEN
from datetime import date,datetime,time,timezone,timedelta
import run_backtest as b
OUT=b.ROOT/'replays/2026-10-23'
ORIGIN=date(2026,10,23);TARGET=date(2026,10,30)

def rows(path):return list(csv.DictReader(io.StringIO(path.read_text())))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def forecast_only(raw,cal):
    # Exact saved values, filtered BEFORE building features or regression labels.
    stamp=b.origin_at(ORIGIN)
    history={date.fromisoformat(r['observation_date']):float(r['SP500']) for r in raw
             if r['SP500'] not in ('','.') and b.START<=date.fromisoformat(r['observation_date'])
             and b.close_at(cal,date.fromisoformat(r['observation_date']))<stamp}
    history=dict(sorted(history.items()))
    x=b.forecast_inputs(history,cal,ORIGIN,TARGET)
    assert x['base_date']==date(2026,10,22) and max(history)==date(2026,10,22)
    assert x['horizon_sessions']==6
    candidates,excluded=b.build(history,cal)
    train=[r for r in candidates if r['horizon_sessions']==6 and b.training_eligibility(r,ORIGIN,cal)[0]]
    assert all(b.close_at(cal,t['target_date'])<stamp for t in train)
    coef,_=b.fit(train)
    ret=float(coef[0]+coef[1]*x['momentum'])
    forecasts={'A':x['base'],'B':x['base']*(1+.25*x['momentum']),'C':x['base']*(1+ret)}
    return history,x,train,excluded,coef,ret,forecasts

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    protected=[b.ROOT/'src/run_backtest.py',b.ROOT/'docs/model_specifications.md']+list((b.ROOT/'results').rglob('*.csv'))
    original_hashes={str(p.relative_to(b.ROOT)):sha(p) for p in protected}
    raw=rows(b.ROOT/'data/raw/fred_SP500.csv')
    cal=b.xc.get_calendar('XNYS',start=str(b.START),end=str(b.CUT))
    history,x,train,excluded,coef,ret,forecasts=forecast_only(raw,cal)
    timestamp=datetime.now(timezone.utc).isoformat()
    frozen={'execution_timestamp_utc':timestamp,'status':'retrospective replay, not a forecast issued on origin date',
        'forecast_origin_London':x['origin_london'],'forecast_origin_UTC':x['origin_utc'],
        'forecast_origin_New_York':x['origin_new_york'],'latest_price_date':str(x['base_date']),
        'latest_price_close_UTC':x['feature_close_utc'],'latest_price':x['base'],
        'lookback_date':str(x['lookback_date']),'lookback_price':history[x['lookback_date']],
        'momentum_20_sessions':x['momentum'],'target_date':str(TARGET),
        'target_close_UTC':x['target_close_utc'],'horizon_sessions':x['horizon_sessions'],
        'training_rows':len(train),'latest_training_target_date':str(max(t['target_date'] for t in train)),
        'C_intercept_decimal_return':float(coef[0]),'C_momentum_slope':float(coef[1]),
        'C_forecast_return_decimal':ret,'C_forecast_return_percent':100*ret,
        'forecasts':forecasts,'raw_source_sha256':sha(b.ROOT/'data/raw/fred_SP500.csv'),
        'model_source_sha256':sha(b.ROOT/'src/run_backtest.py'),
        'specifications_sha256':sha(b.ROOT/'docs/model_specifications.md'),
        'historical_FRED_availability_verified':False}
    # Freeze forecast evidence before loading any scoring outcome.
    freeze=OUT/'forecast_frozen_before_scoring.json'
    freeze.write_text(json.dumps(frozen,indent=2));freeze_hash=sha(freeze)
    b.write_csv(OUT/'inputs_available_by_market_close.csv',[{'date':d,'SP500':v} for d,v in history.items()])
    b.write_csv(OUT/'training_rows.csv',[dict(t,feature_timestamp=b.close_at(cal,t['base_date']).isoformat(),
        target_timestamp=b.close_at(cal,t['target_date']).isoformat(),fit_eligible=True) for t in train])
    b.write_csv(OUT/'origin_eligibility_log.csv',excluded)
    shutil.copy2(b.ROOT/'docs/model_specifications.md',OUT/'model_specifications_snapshot.md')
    membership={name:any(r['origin']==str(ORIGIN) for r in rows(b.ROOT/f'results/{name}_forecasts.csv')) for name in ['primary','holiday','delayed']}
    # Outcome supplied by user, used only AFTER frozen forecasts exist. Never added to training data.
    actual=Decimal('7580.07')
    (OUT/'scoring_reference.json').write_text(json.dumps({'target_date':str(TARGET),'actual':str(actual),
        'source':'User-provided closing level in this chat; not independently verified against S&P DJI',
        'role':'post-forecast scoring only','forecast_frozen_sha256':freeze_hash},indent=2))
    scored=[]
    for m,f in forecasts.items():
        e=b.ape(f,float(actual));deduction=min(50.,5*e)
        scored.append({'model':m,'forecast_index_level':f,'forecast_display_2dp':f'{f:.2f}',
            'actual_user_supplied':float(actual),'APE_percent':e,'marks_deducted':deduction,
            'marks_deducted_display_2dp':f'{deduction:.2f}','accuracy_score_out_of_50':b.score(e)})
    b.write_csv(OUT/'forecast_scores.csv',scored)
    # Independent implementation: raw CSV -> Decimal prices -> eligible weekly labels.
    # It does not reuse production features, coefficients, training rows or fit().
    with localcontext() as ctx:
        ctx.prec=40
        p={date.fromisoformat(r['observation_date']):Decimal(r['SP500']) for r in raw
           if r['SP500'] not in ('','.') and b.START<=date.fromisoformat(r['observation_date'])<ORIGIN}
        days=sorted(p);base=days[-1];look=days[-21];mom=p[base]/p[look]-1
        independent_train=[]
        cutoff=datetime.combine(ORIGIN,time(12),b.LONDON)
        for end in days:
            if end.weekday()!=4:continue
            stamp=cal.schedule.loc[str(end),'close'].to_pydatetime()
            if stamp>=cutoff:continue
            start=end-timedelta(days=7)
            before=[d for d in days if d<start]
            if len(before)<21:continue
            bd=before[-1];j=days.index(bd)
            count=len(cal.sessions_in_range(str(bd),str(end)))-1
            if count!=6:continue
            independent_train.append((p[bd]/p[days[j-20]]-1,p[end]/p[bd]-1))
        xs,ys=zip(*independent_train);xm=sum(xs)/len(xs);ym=sum(ys)/len(ys)
        beta=sum((xx-xm)*(yy-ym) for xx,yy in independent_train)/sum((xx-xm)**2 for xx in xs)
        alpha=ym-beta*xm;er=alpha+beta*mom
        independent={'A':p[base],'B':p[base]*(1+Decimal('.25')*mom),'C':p[base]*(1+er)}
        assert len(independent_train)==len(train)
        assert abs(float(alpha)-coef[0])<1e-12 and abs(float(beta)-coef[1])<1e-12
        checks=[]
        for r in scored:
            m=r['model'];f=independent[m];error=100*abs(f-actual)/actual;deduct=min(Decimal(50),5*error)
            score=(50-deduct).quantize(Decimal('.01'),rounding=ROUND_HALF_EVEN)
            assert abs(float(f)-forecasts[m])<1e-8
            assert abs(float(error)-r['APE_percent'])<1e-10
            assert abs(float(deduct)-r['marks_deducted'])<1e-10
            assert float(score)==r['accuracy_score_out_of_50']
            checks.append({'model':m,'independent_forecast':str(f),'independent_APE_percent':str(error),
                'independent_deduction':str(deduct),'independent_score':str(score),'status':'PASS'})
    b.write_csv(OUT/'independent_decimal_checks.csv',checks)
    # Poison every future CSV price, including the origin-Friday close; output must be invariant.
    poisoned=[dict(r,SP500='987654.32') if r['observation_date']>=str(ORIGIN) and r['SP500'] not in ('','.') else r for r in raw]
    alt=forecast_only(poisoned,cal)
    assert alt[-1]==forecasts and (alt[-3]==coef).all()
    # Inject the target with an extreme fictional test value; it must still be discarded.
    # This value is a test fixture, not an observation or an alternative actual.
    injected=forecast_only(raw+[{'observation_date':str(TARGET),'SP500':'1234567.89'}],cal)
    assert injected[-1]==forecasts and (injected[-3]==coef).all()
    assert sha(freeze)==freeze_hash
    assert all(sha(b.ROOT/path)==value for path,value in original_hashes.items())
    checks={'independent_Decimal_regression_and_scores':'PASS','future_price_poisoning':'PASS',
        'target_value_injection_does_not_change_forecast':'PASS','forecast_freeze_unchanged_after_scoring':'PASS',
        'original_model_and_evaluation_files_unchanged':'PASS','training_count':len(train),
        'latest_training_target':str(max(t['target_date'] for t in train)),
        'target_2026_10_23_excluded_from_training':not any(t['target_date']==ORIGIN for t in train),
        'membership_in_existing_52_origin_panels':membership,'independent_C_intercept':str(alpha),
        'independent_C_beta':str(beta),'independent_C_return':str(er)}
    (OUT/'validation.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(frozen,indent=2));print(json.dumps(scored,indent=2));print(json.dumps(checks,indent=2))
    lines=['| Model | Forecast | APE | Marks deducted | Score /50 |','|---|---:|---:|---:|---:|']
    for r in scored:lines.append(f"| {r['model']} | {r['forecast_index_level']:,.2f} | {r['APE_percent']:.6f}% | {r['marks_deducted']:.6f} | {r['accuracy_score_out_of_50']:.2f} |")
    report=f'''# Historical replay for 23 October 2026

This retrospective calculation uses the existing models without retuning. It is not a forecast actually issued on 23 October and does not generate the binding November forecast. The original 52-origin evaluation and model specifications remain unchanged.

Origin: **{x['origin_london']}**, equivalent to {x['origin_utc']} and {x['origin_new_york']}. Target: **30 October 2026 official S&P 500 price-index close**, {x['target_close_utc']} (16:00 New York; 20:00 London, following the UK clock change). There are **six exchange sessions** from the baseline to the target: 23, 26, 27, 28, 29 and 30 October.

## Inputs and forecasts

Latest eligible price: **22 October 2026, {x['base']:,.2f}**, from the saved FRED SP500 CSV. That session closed at {x['feature_close_utc']}, 15 hours before the cutoff. The 20-session lookback is **{x['lookback_date']}**, price **{history[x['lookback_date']]:,.2f}**. Momentum is {x['momentum']:.12f}, or **{100*x['momentum']:.8f}%**.

A uses the unchanged baseline. B uses F=P(1+0.25m). C uses F=P(1+a+bm), with the existing intercept-plus-momentum expanding OLS specification, exactly six-session weekly training labels and the original five-year start boundary.

C used **{len(train)} matured training observations**. The latest included target is **{max(t['target_date'] for t in train)}**. The 23 October closing outcome is excluded because it was still in the future at that day's noon cutoff. Every included feature and target close timestamp is recorded in `training_rows.csv`.

- Intercept a: **{float(coef[0]):.12f}** in decimal return units.
- Momentum slope b: **{float(coef[1]):.12f}**, multiplying decimal 20-session momentum.
- Forecast return a+bm: **{ret:.12f}**, or **{100*ret:.8f}%**.

## Scoring after forecast generation

Scoring uses **7,580.07**, the actual supplied by the user. It has not been independently verified against S&P DJI in this replay, and was not added to the saved market data or supplied to the forecasting function. The JSON forecast record was saved and hashed before the script introduced this scoring value. This procedural separation does not claim that the user-supplied outcome was unknown to the analyst; the unchanged specifications determine the forecast.

{chr(10).join(lines)}

APE = 100 × |F−actual| / actual. Deduction = min(50, 5×APE). Score = round(50−deduction, 2). Calculations use full-precision forecasts, with two-decimal levels shown only for presentation, consistent with the existing backtest. Only the final score is rounded for marking; the deduction above retains six decimal places.

## Independent verification and sample membership

A separate Decimal calculation rebuilt weekly training data directly from the raw CSV, estimated intercept/slope through centered sums, and recomputed all forecasts, errors, deductions and rounded scores. All matched: forecast tolerance 1e−8 index points; APE/deduction tolerance 1e−10. Altering all prices dated on/after 23 October and inserting an extreme target-date test value left forecasts and coefficients unchanged. Original specification/code/evaluation files were hash-checked unchanged.

**This origin is not in the existing 52-origin primary evaluation sample**, which ends at origin 16 October and target 23 October. It is also absent from the holiday and delayed panels. The original saved data lacked the 30 October actual, so this origin could not be scored then. This replay is saved separately and does not append or reselect the 52-origin sample.

## Remaining data timing limitations

The input CSV was retrieved on 31 October, so this is a reconstruction from current-vintage historical values. Exchange close times show the relevant market sessions had ended, but do not prove that the specific FRED observations and their exact retrieved vintages were available at the historical cutoff. Historical intraday FRED release timestamps and revisions remain unverified for both feature prices and training outcomes. Therefore the replay is conditional on prior official-close availability, not a certified historical FRED-only replay. The user-supplied scoring value is separately labelled, not claimed to be independently authenticated official evidence.

Source: FRED SP500, https://fred.stlouisfed.org/series/SP500 ; original source URL, retrieval timestamp and raw SHA-256 remain in `research/data/raw/fred_SP500.csv.metadata.json`. The calendar uses the project's pinned exchange_calendars XNYS schedule. No new financial data were downloaded or substituted.

## Reproduce

From the project root: `python3 research/src/replay_2026_10_23.py`. The script imports the existing model helpers, builds training using only the truncated input history, freezes forecasts and then scores them. Results, frozen forecast, training ledger, filtered inputs, validation and a specification snapshot are saved in this directory.
'''
    (OUT/'REPLAY_REPORT.md').write_text(report)
    (OUT/'manifest.json').write_text(json.dumps({'generated_at_utc':datetime.now(timezone.utc).isoformat(),
        'files':[{'path':p.name,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in ['manifest.json','execution_log.txt']],
        'replay_script_sha256':sha(Path(__file__))},indent=2))
if __name__=='__main__':main()

from pathlib import Path
import csv,io
R=Path(__file__).resolve().parents[1]
def read(p):return list(csv.DictReader(io.StringIO((R/p).read_text())))
s=read('results/summary.csv');p=read('results/primary_forecasts.csv');last=p[-1]
lines=['| Model | Mean APE | Median APE | Maximum APE | Beat A | Mean score /50 |','|---|---:|---:|---:|---:|---:|']
for x in s[:3]:
 lines.append(f"| {x['model']} | {float(x['MAPE_pct']):.4f}% | {float(x['median_APE_pct']):.4f}% | {float(x['max_APE_pct']):.4f}% | {'— (self)' if x['model']=='A' else format(float(x['beat_A_pct']),'.2f')+'%'} | {float(x['mean_accuracy_score_of_50']):.2f} |")
table='\n'.join(lines)
text=f'''# S&P 500 exploratory historical forecasting report

Research date: 31 October 2026. Instrument: S&P 500 price index, index points. Intended eventual target: official S&P Dow Jones Indices close on 20 November 2026; eventual information cutoff: 13 November 2026 at 12:00 GMT. **This report contains no binding forecast and is not the final coursework submission.**

## Findings and provisional recommendation

Expanding-window regression C has the lowest primary mean absolute percentage error (MAPE), 1.4260%, versus 1.4478% for unchanged-price A. Its advantage is only 0.0218 percentage points of error, approximately 0.11 average accuracy marks out of 50. Fixed momentum B is slightly worse than A. The evidence does not establish a dependable benefit from fitting the regression. Retain A as the provisional operational default and C as a challenger; this is a research recommendation, not a November point forecast.

The key unresolved limitation is historical publication timing: this is a current-vintage backtest conditional on public availability of the preceding market close, not a certified FRED-at-noon vintage replay. Its limitation must accompany any presentation of the results.

## Data and boundary

FRED SP500 identifies daily closing **price-index** observations sourced from S&P Dow Jones Indices; dividends are excluded [1]. The requested window was 30 October 2021 through 30 October 2026. The preserved CSV download at 12:57:01 UTC on 31 October 2026 contained observations through 28 October. Two alternative CSV requests had the same endpoint. The independently preserved FRED series page, retrieved at 12:57:02 UTC, supplied 29 October at 7,720.39, explicitly labelled in a separate supplement. It reports an update on 30 October at 10:12 CDT (15:12 UTC). No 30 October price was retrieved or imputed.

The combined sample has 1,254 closes, 1 November 2021–29 October 2026. All expected XNYS sessions within that range are present; all 50 blank CSV records fall outside exchange sessions. The calendar and observed prices agree, including the special 9 January 2025 closure. This is a calendar consistency check, not a separate verification of every level directly against S&P DJI. The S&P index page defines the requested instrument [2]; final marking must use the specified official reference rather than an ETF or futures proxy.

Raw bytes, request URLs, UTC retrieval timestamps, response headers, SHA-256 hashes and software versions are saved locally. FRED redistribution restrictions must be respected when assembling the eventual evidence ZIP. Retrieval time is not historical publication time: neither latest-vintage snapshots nor a one-day lag proves what FRED held at every past noon.

## Models and economic rationale

Let P_t be the last close before the origin, and m_t=P_t/P_(t−20)−1, with 20 actual trading-session intervals. Returns are decimal simple returns; the output is an index level.

- **A:** F=P_t. New short-horizon information is difficult to predict; setting expected return to zero provides a transparent benchmark. It is a forecasting rule, not proof that prices follow a random walk.
- **B:** F=P_t(1+0.25m_t). Positive momentum assumes gradual information incorporation or persistent flows. The coefficient is a prespecified illustrative fraction of the prior move, not an estimated structural effect. It can fail when recent moves reverse or news dominates.
- **C:** Estimate r_(t,t+6)=a+b m_t by ordinary least squares with an intercept on expanding historical six-session weekly observations. Then F=P_t(1+a+b m_t). The intercept permits drift, and the slope is unconstrained. Estimated slopes across primary forecasts were approximately 0.018–0.040, far below 0.25. A small gain may reflect drift rather than predictive momentum; no intercept-only ablation was prespecified or tested here.

There are no extra factors, subjective adjustments or coefficients selected using held-out errors. OLS targets squared return error, whereas the coursework scores absolute percentage error; these objectives need not favour the same model. A momentum mechanism is an economic hypothesis, not a demonstrated causal relationship.

## Rolling-origin design and holidays

Following the point-in-time audit, each origin is Friday at **12:00 Europe/London** (11:00 UTC in BST; 12:00 UTC in GMT); it precedes the US regular open. The target is the next calendar Friday's exchange close, normally six sessions after Thursday's close. The NYSE calendar identifies holidays and early closes [3,4]. Closed Friday targets are excluded, not silently moved to Thursday. Early-close Fridays remain valid targets at their actual exchange closing time.

The primary panel reserves the most recent 52 eligible **exactly six-session** origins: 18 July 2025–16 October 2026, with targets 25 July 2025–23 October 2026. It spans more than one calendar year because shortened weeks are excluded. Across the full candidate history, 49 shorter weeks and nine closed Friday targets are logged separately; four origins lack factor history and the latest target lacks retrieved data. The first held-out regression has 144 matured training observations. Every fitted label has a target close before that origin; a target closing later on the origin Friday is excluded. Twenty-session features use only earlier closes.

Parameters refit sequentially; an earlier test outcome can enter a later fit once it has matured. This is legitimate online out-of-sample prediction, not an embargo on all test-period labels forever. The seven original examples were already visible during inspection, so this is not a claim of completely unseen evaluation or preregistration. Specifications were locked before the new full comparison and no coefficient was chosen from held-out rankings.

## Accuracy and robustness

APE=100×|F−A|/A. Per-origin coursework accuracy score=round(max(0,50−5×APE),2), as specified in the supplied brief [5]. The table averages individual rounded scores; it is not an award of coursework marks. Ties do not count as beating A.

{table}

A four-observation circular moving-block bootstrap (5,000 resamples, fixed seed) gives a descriptive 95% interval for C minus A mean APE of **−0.0921 to +0.0478 percentage points**. For B minus A it is −0.2635 to +0.2385. Both include zero. The intervals account only approximately for dependence in the ordered eligible sample; irregular calendar spacing, model selection and regime shifts limit inference.

Two prespecified sensitivity panels use identical dates across models within each panel:

| Panel | Origins | A MAPE | B MAPE | C MAPE |
|---|---:|---:|---:|---:|
| All eligible open Fridays | 52 | 1.5900% | 1.6571% | 1.5886% |
| One-session older inputs | Same primary 52 | 1.6015% | 1.6718% | 1.6009% |

The open-Friday panel covers 3 October 2025–16 October 2026 and includes ten five-session horizons. C is trained on six-session labels and its expected return is scaled by h/6; B remains fixed at 0.25. This extension is an explicit linear-horizon assumption. Its different date composition means the change in MAPE cannot be attributed solely to holidays.

The delayed-input panel uses the preceding-but-one session for prices and momentum, refits C on six-session returns from similarly lagged feature dates, excludes training outcomes dated on or after the last pre-origin session, and scales C to the resulting seven-session horizon. It tests sensitivity to stale inputs, not exact historical FRED release times. C's numerical advantage over A almost disappears in both panels.

Worst primary errors are 4.2295% for A and 4.0845% for C (target 17 April 2026), and 4.2712% for B (7 August 2026). In the holiday panel B reaches 5.2382% error on 28 November 2025. These failures remain in the metrics. An adverse scenario is a sudden earnings, inflation or policy surprise reversing a recent trend; momentum then extrapolates in the wrong direction. No probability or prediction interval for the November target has been estimated.

## Inspectable example and checks

For the historical origin {last['origin']} only, the baseline close was {float(last['base']):,.2f} on {last['base_date']}; 20-session momentum was {100*float(last['momentum']):.6f}%. A predicted {float(last['A_forecast']):,.2f}; B predicted {float(last['B_forecast']):,.2f}. C used a={float(last['intercept']):.9f}, b={float(last['beta']):.9f}, and predicted {float(last['C_forecast']):,.2f}. The realised target on {last['target_date']} was {float(last['actual']):,.2f}. All calculations retain full precision until display or score rounding.

Six automated tests passed. They independently rebuild primary OLS and predictions with Decimal arithmetic; recompute all nine summary rows; verify holiday/early-close handling, score caps and minimum training; check temporal ordering; perturb future prices to confirm earlier forecasts are unchanged; and reconcile the existing examples and legacy benchmark predictions. All 156 rolling OLS fits also agree with independent centered-sum calculations. The original seven-week baseline/actual prices and factor dates agree with FRED to displayed precision. Numerical validation does not prove historical data availability.

The subsequent point-in-time audit found 36 summer origins had been stamped one hour late and corrected them without changing forecasts or metrics; its ten adversarial tests passed. It also corrected delayed-training target timestamps and documents that the exposed evaluation set cannot be treated as untouched for future model selection. See `../pit_audit/AUDIT_REPORT.md`. Earlier corrections include enforcing true six-session training, explicit calendars, fixed GMT origins, raw snapshot preservation, input validation and individual score rounding. The original script's score formula itself was correct. Its old “six-session” regression actually mixes holiday horizons; the separately saved legacy run demonstrates the resulting difference. Full details are in the project audit and validation outputs.

## Agent workflow and responsibility

```mermaid
flowchart LR
 G[Goal and cutoff] --> D[FRED snapshots and coursework brief]
 D --> T[Python and exchange calendar]
 T --> M[Agent freezes models and evaluates origins]
 M --> V[Independent calculations and timing tests]
 V --> R[Qualified research recommendation]
 R --> H[Group reviews evidence and owns final submission]
```

The agent inspected sources, retrieved snapshots, resolved the CSV/page discrepancy, executed models, checked calculations and documented its recommendation. AI-use declaration: OpenAI Codex performed these tasks; the precise underlying model identifier was not exposed in the task record. No independent human review or group contribution is claimed. Group members must supply their own contribution statement and approve the eventual submission. The final forecast, report cover value, slides and evidence record remain future work at the authorised cutoff.

## References

[1] S&P Dow Jones Indices LLC, *S&P 500 [SP500]*, via FRED, retrieved 31 October 2026. https://fred.stlouisfed.org/series/SP500 . Download: https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500&cosd=2021-10-30&coed=2026-10-30 . Saved source and metadata accompany this report.

[2] S&P Dow Jones Indices, *S&P 500 index overview*, accessed 31 October 2026. https://www.spglobal.com/spdji/en/indices/equity/sp-500/ . Used for instrument definition, not an independent daily-history check.

[3] NYSE, *Holidays and Trading Hours*, retrieved 31 October 2026. https://www.nyse.com/markets/hours-calendars . Current official holiday and early-close guidance; historical session implementation uses [4].

[4] exchange_calendars contributors, *exchange_calendars*, version 4.13.2, XNYS calendar. https://github.com/gerrymanoim/exchange_calendars . Local calendar snapshot and package versions retained.

[5] UCL, *Group Coursework — AI Agent Market Forecasting, IFTE0007 2026/27*, supplied Word document. Original preserved; full text extracted locally.
'''
(R/'docs/research_report.md').write_text(text)
print('Report words including references:',len(text.split()))

# S&P 500 exploratory research — 31 October 2026

Start with [the research report](docs/research_report.md). No binding November forecast has been generated. Original project files remain untouched; the corrected implementation is `src/run_backtest.py`.

## Reproduce offline
From the project root, using Python 3.14 (the run used 3.14.6):

```sh
python3 research/src/run_backtest.py
python3 sp500_backtest/backtest_sp500.py --prices research/data/raw/fred_SP500.csv --output research/results/legacy_run
python3 research/src/test_backtest.py
```

The local `research/vendor` folder contains the installed dependencies, which the scripts explicitly load. For a clean environment, install the pinned dependencies with `python3 -m pip install --target research/vendor -r research/requirements.txt`. This requires internet; once installed the calculations and checks need no network, account or AI subscription. Binary wheels in vendor are specific to this Mac/Python version: reinstall from requirements on a different platform. The scripts write results only inside `research` and never make the November forecast.

Optional `python3 research/src/retrieve_sources.py` downloads to a NEW timestamped snapshot folder; it does not replace the frozen research inputs or automatically extend the analysis boundary. Do not substitute new data and call the result the original run.

## Files
- `data/raw/`: unchanged download bytes plus URL, response headers, timestamps and SHA-256 metadata. Multiple CSV requests were preserved to investigate stale endpoints.
- `sources/`: raw FRED and NYSE HTML and metadata.
- `data/processed/`: combined prices, separately labelled 29 October webpage supplement, exchange schedule.
- `data/snapshots/2026-10-31/`: dated copy of frozen raw sources and processed inputs with hashes.
- `docs/model_specifications.md`: protocol saved before evaluation, formulas and exclusions.
- `docs/research_report.md`: findings, sensitivity, mechanism, limitations and sources.
- `docs/project_audit.md`: inspection and corrections.
- `docs/research_transcript.md`: concise agent/tool/action record; not a verbatim chat export.
- `docs/coursework_extracted.txt`: text of the original brief, including score and requirements.
- `results/`: forecasts, per-origin errors/scores, summary, uncertainty, training pool and all-origin exclusion log. The legacy results are separately labelled.
- `validation/`: six tests, independent calculations, environment, raw-data quality and example reconciliation.
- `originals/`: original readable coursework/code/CSV files preserved unchanged. Initial inventory also records OS/cache files.

## Interpretation and limits
The primary results assume the previous session's official close was publicly available at Friday 12:00 GMT. They are **not certified as reproducible from FRED at each historical cutoff**. Current-vintage data lack historical publication timestamps. The saved FRED page was updated after noon on 30 October; the one-session delayed panel is a sensitivity scenario, not a substitute for vintage proof. See the report before using the findings.

The CSV ends 28 October; the saved FRED HTML supplies 29 October at 7,720.39. There is no 30 October observation in the retrieved sources. Latest scored target is 23 October. All raw and processed prices remain local: the source restricts redistribution, so check permissions before including them in a submission ZIP. No ZIP or final submission has been made.

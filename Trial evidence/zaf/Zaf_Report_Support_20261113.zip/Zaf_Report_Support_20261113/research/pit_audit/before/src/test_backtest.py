"""Independent scalar/Decimal calculations and temporal regression tests."""
import unittest,csv,json,statistics,io
from decimal import Decimal,localcontext,ROUND_HALF_EVEN
from datetime import date,timedelta
import run_backtest as b

def read_rows(path):
    return list(csv.DictReader(io.StringIO(path.read_text())))

class BacktestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p,_=b.load_prices();cls.days=list(cls.p)
        cls.cal=b.xc.get_calendar('XNYS',start=str(b.START),end=str(b.CUT))
        cls.candidates,_=b.build(cls.p,cls.cal)
        cls.six=[r for r in cls.candidates if r['horizon_sessions']==6]

    def test_independent_decimal_primary_forecasts(self):
        # Rebuild factor and label values from saved prices, not stored calculated fields.
        p={d:Decimal(str(v)) for d,v in self.p.items()};days=self.days
        rows=read_rows((b.ROOT/'results/primary_forecasts.csv'))
        for r in rows:
            origin=date.fromisoformat(r['origin']);base=max(d for d in days if d<origin)
            target=origin+timedelta(days=7);j=days.index(base)
            x=p[base]/p[days[j-20]]-1
            train=[]
            for t in days:
                o=t-timedelta(days=7)
                if t.weekday()!=4 or t>=origin:continue
                before=[d for d in days if d<o]
                if len(before)<21:continue
                bd=before[-1];k=days.index(bd)
                if days.index(t)-k!=6:continue
                train.append((p[bd]/p[days[k-20]]-1,p[t]/p[bd]-1))
            self.assertEqual(len(train),int(r['train_n']))
            xm=sum(x for x,y in train)/len(train);ym=sum(y for x,y in train)/len(train)
            beta=sum((x-xm)*(y-ym) for x,y in train)/sum((x-xm)**2 for x,y in train)
            alpha=ym-beta*xm
            preds=[p[base],p[base]*(1+Decimal('.25')*x),p[base]*(1+alpha+beta*x)]
            self.assertEqual(days.index(target)-j,6)
            for model,f in zip('ABC',preds):
                self.assertAlmostEqual(float(f),float(r[f'{model}_forecast']),places=8)
                error=100*abs(f-p[target])/p[target]
                self.assertAlmostEqual(float(error),float(r[f'{model}_APE_pct']),places=10)
                sc=max(Decimal(0),50-5*error).quantize(Decimal('.01'),rounding=ROUND_HALF_EVEN)
                self.assertEqual(float(sc),float(r[f'{model}_score']))

    def test_all_summary_metrics(self):
        summary=read_rows((b.ROOT/'results/summary.csv'))
        files={'primary_six_sessions':'primary','all_open_fridays':'holiday','one_session_delayed_inputs':'delayed'}
        for s in summary:
            rows=read_rows((b.ROOT/f"results/{files[s['panel']]}_forecasts.csv"))
            m=s['model'];errs=[100*abs(float(r[f'{m}_forecast'])-float(r['actual']))/float(r['actual']) for r in rows]
            rw=[100*abs(float(r['A_forecast'])-float(r['actual']))/float(r['actual']) for r in rows]
            expected={'MAPE_pct':statistics.mean(errs),'median_APE_pct':statistics.median(errs),
                      'max_APE_pct':max(errs),'beat_A_pct':100*sum(e<a for e,a in zip(errs,rw))/len(errs),
                      'mean_accuracy_score_of_50':statistics.mean(round(max(0,50-5*e),2) for e in errs)}
            self.assertEqual(len(rows),52)
            for k,v in expected.items():self.assertAlmostEqual(v,float(s[k]),places=10)

    def test_no_future_price_affects_forecast(self):
        test=self.six[-20];original=b.evaluate([test],self.six,'test',self.p)[0]
        altered={d:v*(1.2 if d>=test['origin'] else 1.) for d,v in self.p.items()}
        pool,_=b.build(altered,self.cal);pool=[r for r in pool if r['horizon_sessions']==6]
        t=next(r for r in pool if r['origin']==test['origin'])
        changed=b.evaluate([t],pool,'test',altered)[0]
        for k in ['A_forecast','B_forecast','C_forecast','intercept','beta','train_n']:
            self.assertEqual(original[k],changed[k])
        self.assertNotEqual(original['actual'],changed['actual'])

    def test_holidays_and_early_closes(self):
        for d in ['2025-01-09','2026-04-03','2026-06-19','2026-07-03']:
            self.assertNotIn(b.pd.Timestamp(d),self.cal.sessions)
        row=next(r for r in self.candidates if str(r['target_date'])=='2025-11-28')
        self.assertEqual(row['horizon_sessions'],5)
        self.assertTrue(row['target_close_utc'].endswith('18:00:00+00:00'))
        # US Independence Day fell on Saturday: Friday 2026-07-03 is closed.
        self.assertFalse(any(str(r['target_date'])=='2026-07-03' for r in self.candidates))

    def test_timing_score_and_minimum_training(self):
        for e,s in [(0,50),(.1,49.5),(1,45),(10,0),(12,0)]: self.assertEqual(b.score(e),s)
        with self.assertRaises(ValueError):b.fit(self.six[:51])
        for panel in ['primary','holiday','delayed']:
            for r in read_rows((b.ROOT/f'results/{panel}_forecasts.csv')):
                self.assertLess(r['training_latest_target'],r['origin'])
                self.assertLess(r['base_date'],r['origin'])
                self.assertTrue(r['origin_utc'].endswith('12:00:00+00:00'))
                self.assertLessEqual(r['target_date'],str(b.CUT))
                if panel=='delayed':
                    last=max(d for d in self.days if d<date.fromisoformat(r['origin']))
                    self.assertLess(r['training_latest_target'],str(last))

    def test_original_examples_and_secondary_benchmark(self):
        for r in read_rows((b.ROOT/'validation/original_examples_reconciliation.csv')):
            self.assertEqual(r['baseline_matches_FRED'],'True');self.assertEqual(r['actual_matches_FRED'],'True')
            if r['lookback_matches']:self.assertEqual(r['lookback_matches'],'True')
        old=read_rows((b.ROOT/'results/legacy_run/weekly_forecasts.csv'))
        new=read_rows((b.ROOT/'results/holiday_forecasts.csv'))
        self.assertEqual([r['origin'] for r in old],[r['origin'] for r in new])
        for a,c in zip(old,new):
            for x,y in [('random_walk_forecast','A_forecast'),('fixed_momentum_forecast','B_forecast')]:
                self.assertAlmostEqual(float(a[x]),float(c[y]),places=9)

if __name__=='__main__':unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Optional fresh retrieval into a NEW timestamped folder; never overwrite frozen inputs."""
from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json
root=Path(__file__).resolve().parents[1]
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=root/'data/snapshots'/stamp;out.mkdir(parents=True,exist_ok=False)
urls={'fred_SP500.csv':'https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500&cosd=2021-10-30&coed=2026-10-30',
      'fred_series.html':'https://fred.stlouisfed.org/series/SP500',
      'nyse_calendar.html':'https://www.nyse.com/markets/hours-calendars'}
for name,url in urls.items():
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 academic research'}),timeout=60) as response:
        raw=response.read();headers={k:v for k,v in response.headers.items() if k.lower() not in ['set-cookie','cookie','authorization']};resolved=response.url
    (out/name).write_bytes(raw)
    (out/(name+'.metadata.json')).write_text(json.dumps({'url':url,'resolved_url':resolved,
       'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),'sha256':hashlib.sha256(raw).hexdigest(),'headers':headers},indent=2))
print(out)

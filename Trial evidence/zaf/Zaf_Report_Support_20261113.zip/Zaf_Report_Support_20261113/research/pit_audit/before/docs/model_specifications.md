# Frozen exploratory specifications
Decision date: 31 October 2026. Written before new backtest results were calculated. Existing seven-week comparisons were already visible, so this is a newly locked protocol, not a claim that all historical outcomes were previously unseen.

Data: FRED SP500 daily closing price index; requested 2021-10-30 through 2026-10-30; use only retrieved numeric observations. Missing exchange sessions cause failure, not forward filling. No final forecast is produced.

Origins: Friday 12:00 UTC (fixed GMT, not British summer time). Target: next calendar Friday's exchange close. Closed Friday targets are excluded and logged, never silently replaced by Thursday. Early-close Fridays are valid. Primary comparison: latest 52 origins with exactly six exchange sessions from latest pre-origin close to target. At least 52 prior matured six-session weekly observations are required for OLS.

Factor m = P[t]/P[t-20] - 1, indexing actual exchange sessions. Model A: F=P[t]. Model B: F=P[t]*(1+0.25*m), fixed coefficient, no tuning. Model C: OLS with intercept, r6=a+b*m, trained on historical six-session Friday-origin observations whose target close occurred before the current origin. F=P[t]*(1+a+b*m). No sign constraint, clipping, or judgement adjustment. Training expands; earlier held-out outcomes may enter later fits only after maturity, as in live sequential forecasting. Holdout is never used to choose hyperparameters.

Secondary holiday comparison: latest 52 eligible open-Friday targets, including shorter weeks. Fit C on the same six-session training pool; multiply its expected return by h/6 for h sessions. A and B retain their stated formulas. Linear horizon scaling is an explicit additional assumption, not an estimated improvement. Do not use this comparison to tune the primary model.

Availability sensitivity: repeat primary origin dates with the baseline and all training feature baselines delayed one exchange session; train exact six-session returns from those older feature dates, requiring target close date strictly earlier than the latest pre-origin session date (extra conservative delay). Predict h-session returns by h/6 scaling C. A and B formulas unchanged. This is a lag scenario, not proof of historical FRED publication availability. Latest-vintage FRED observations and unknown historical intraday publication times prevent a certified vintage backtest.

Metrics: E=100*abs(F-A)/A. Mean, median, maximum E; strict fraction E_model<E_A (ties do not beat); per-origin score round(max(0,50-5*E),2), plus mean of these rounded scores. Compare on identical origins per panel. Primary selection criterion: lower mean APE, weighed against size, consistency and complexity; no automatic preference for C.

Independent checks: closed-form scalar OLS versus numpy least squares, recalculated metrics, timing/session assertions, future-price perturbation, holiday and score edge tests. Uncertainty: paired moving-block bootstrap of mean loss differences (block 4, seed 20261031, 5000 draws); descriptive only. No claim of iid errors or definitive model superiority.

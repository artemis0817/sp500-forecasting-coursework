# Point in time look ahead bias audit

Audit date: 31 October 2026. Scope: the existing S&P 500 project, its 52 primary held-out forecasts, every candidate regression training row at each origin, and both sensitivity panels. No new prices, coefficients, evaluation dates or binding November forecast were introduced.

## Conclusion

**Two alignment defects were found and corrected.** The original 52 forecasts were weekly Friday forecasts, not daily forecasts, but 36 were timestamped at 13:00 London rather than the requested 12:00. The delayed-input sensitivity also retained inconsistent target timestamps in 197 of its 246 candidate training rows after changing their target dates.

**No future-price or unmatured-label leakage was detected in the audited numerical path.** All 52 primary baselines were the latest exchange close before the correct London cutoff, and all included regression labels had closed before parameter estimation. Correcting the timestamps changes none of the primary or sensitivity forecasts or metrics. This conclusion is conditional on the market-close availability proxy: **historical FRED publication and value vintages remain unverified**, so a fully certified point-in-time replay is not established.

There is also a model-selection limitation. The final 52 observations and sensitivity results have already informed the research recommendation. They are sequentially out of sample for parameter estimation but are no longer an untouched final test of a subsequently selected model. Passing numerical tests cannot repair this or establish historical publication availability.

## Preserved evidence and evaluation frequency

All prior source code, results, documents, validation files, requirements and the prior manifest were copied into `before/` with a SHA-256 inventory before any edit. The separate original `sp500_backtest/backtest_sp500.py` remains unchanged as legacy evidence.

The active pre-audit implementation constructed Fridays using `fri += timedelta(days=7)`, with targets seven calendar days later. It selected the last 52 exactly-six-session cases. Its [original timestamp construction](/Users/zafirahmunawar/Desktop/SP500_Coursework/research/pit_audit/before/src/run_backtest.py:55) explicitly used `timezone.utc`, not `Europe/London`. The older legacy script likewise loops only over Friday targets; it is not a daily-origin test either, though it does not encode timezone-aware origins.

All 52 primary origins are Fridays, from 18 July 2025 to 16 October 2026. Their 51 calendar gaps comprise 42 seven-day, six fourteen-day, two twenty-one-day and one thirty-five-day intervals. **The true frequency is a filtered weekly Friday sample, not daily and not 52 consecutive Fridays.** The six-session primary restriction, holiday-Friday exclusion and separate all-open-Friday sensitivity are retained, not silently replaced with another convention.

The old stored UTC cutoffs translate to 13:00 London on 36 BST dates and 12:00 London on 16 GMT dates. [Corrected origin construction](/Users/zafirahmunawar/Desktop/SP500_Coursework/research/src/run_backtest.py:48) uses `ZoneInfo('Europe/London')`, then converts to UTC and `America/New_York`. The actual November assignment is in GMT, but historical summer origins must respect London daylight saving.

## Audit of each origin and feature

[origin_audit_52.csv](results/origin_audit_52.csv) records the requested forecast origin timestamp, latest eligible price date, actual price date used, target date and exchange-session horizon for every origin. It also records old timestamps, correction minutes, London/New York/UTC conversions, feature dates, target closing times, training counts and unresolved FRED status.

Eligibility is calculated from XNYS exchange **close timestamps**, not a generic business-day calendar or merely a date comparison. The latest scheduled close before each origin is compared with the price actually used. Every primary baseline matches. Fifty are Thursdays; the exceptions are:

| Origin at London noon | Actual baseline | Reason |
|---|---|---|
| 28 November 2025 | Wednesday 26 November | Thanksgiving closed on Thursday |
| 2 January 2026 | Wednesday 31 December 2025 | New Year's Day closed on Thursday |

All 52 primary horizons are six exchange sessions from baseline to target, and all targets are the following calendar Friday. The shortest baseline-to-cutoff time is 15 hours. This establishes that the corresponding exchange session had ended; it does not establish when the exact retrieved index value was first published or revised.

For A, the only input is the baseline level. B and C use `P[t]/P[t−20]−1`, where t−20 means 20 exchange-session intervals. All 21 session dates in every primary window were checked against the cutoff; the formula itself uses only the two endpoints. For training rows, both endpoint timestamps are recorded and the latest feature timestamp precedes that training row's own Friday cutoff. No negative shifts, centered windows, unlagged future rolling windows, fitted normalisers or feature-selection searches occur in the model path. The positive `j+6` in lagged training deliberately builds a future training label; the timestamp maturity gate determines when that label can be used.

[forecast_inputs](/Users/zafirahmunawar/Desktop/SP500_Coursework/research/src/run_backtest.py:55) now builds forecast features without reading the realised target value. It rejects a missing expected latest-session price instead of silently falling back to an older observed price. The surrounding backtest attaches actual outcomes only for evaluation. Unknown target outcomes are excluded from the scored backtest, not manufactured; forecasts can be constructed from a truncated historical input prefix.

Calendar edge tests cover US/UK DST transition mismatches, Good Friday, Independence Day observed closure, Thanksgiving and early closes. For example, London noon is 08:00 New York on 13 March 2026 and 31 October 2025, but 07:00 New York on 10 April 2026. The 28 November 2025 target closes at 13:00 New York; it is not falsely assigned a 16:00 close. A closed Friday target remains excluded under the existing convention. The delayed-input panel deliberately uses an older price; its failure to use the very latest close is a labelled scenario, not a hidden primary-model rule.

## Every Model C training row

[training_row_audit.csv](results/training_row_audit.csv) enumerates **10,244 decisions: 197 candidate rows × 52 origins**. It includes feature and lookback timestamps, training origin, target timestamp, return, old inclusion status, corrected fitting eligibility and exclusion reason.

- **8,823 included row/origin pairs:** every target closed strictly before that forecast origin.
- **1,421 excluded row/origin pairs:** not eligible at that origin.
- **43 same-day target cases:** correctly excluded because Friday's later close was not yet known at noon.
- **1,284 included pairs involving earlier held-out forecasts:** these outcomes had already matured. This is legitimate expanding-window online refitting, not fitting with future test outcomes.

These are row/origin pairs, not 8,823 distinct observations. The old date-only inclusion rule and an independently computed timestamp oracle select exactly the same rows for this sample. [The revised gate](/Users/zafirahmunawar/Desktop/SP500_Coursework/research/src/run_backtest.py:97) explicitly rejects unresolved target dates/values, not-yet-closed targets and unavailable features, and recomputes exchange timestamps rather than trusting supplied metadata. [Evaluation](/Users/zafirahmunawar/Desktop/SP500_Coursework/research/src/run_backtest.py:133) calls this gate before OLS. No scale parameters, selected factors or optimised hyperparameters are estimated outside the eligible data. The intercept and slope are fitted only after filtering.

An additional **23,036 candidate row/origin decisions** cover both sensitivity panels in [the sensitivity ledger](results/sensitivity_training_row_audit.csv). Their inclusion sets were checked against timestamp rules and their fitted coefficients against the saved corrected forecasts. The delayed sensitivity's target-date reassignment now [updates its target timestamp too](/Users/zafirahmunawar/Desktop/SP500_Coursework/research/src/run_backtest.py:187). The 197 previously stale timestamps were metadata errors; the old code selected rows by target date, so they did not alter its fits. The ledger retains old and corrected timestamps.

## Holdout discipline and model selection

Code inspection found no search over coefficients or hyperparameters using the held-out losses. B remains fixed at 0.25. C always uses the same 20-session factor, intercept, expanding estimation rule and minimum training count. Horizon scaling h/6 is deterministic, not fitted. Forecast generation does not read summary metrics or bootstrap output. Previously passed tests compared calculations but did not establish all of these facts.

Nevertheless, the report's preference for retaining A was informed by the same 52 results and their sensitivity panels. Thus **the condition that this final set has never influenced model selection cannot be certified and is not literally true of the research recommendation**. No coefficient was retuned, but selection on evaluation evidence still creates selection bias in claims about the chosen model's future performance. The seven example outcomes were also visible before the first full run, and the protocol was documented in-session rather than independently preregistered.

These distinctions are now explicit. The frozen variants and results remain descriptive exploratory comparisons. Further feature/coefficient/variant choices should be made on earlier development data with an inner chronological validation scheme, followed by genuinely new forward observations. Repartitioning already inspected outcomes would not make them unseen. This audit makes no new performance-driven model choice.

## FRED availability and revisions

FRED identifies SP500 as a daily closing price index sourced from S&P DJI [1]. The exchange calendar and trading-hours documentation establish market close times [2]. These support a prior-session close being economically observable before Friday noon; neither supplies an archived dissemination timestamp for every exact index value.

The preserved FRED page reports 29 October 2026 at 7,720.39 and a series update on 30 October at 10:12 CDT (15:12 London). The saved CSV ends 28 October. This demonstrates a difference between the retrieved FRED surfaces and a series update after noon. **The series update timestamp is not necessarily the first publication time of that particular observation.** It does not prove a fixed one-day lag, nor prove which of the 52 historical observations were or were not available by noon. The one-session lag panel therefore remains only a sensitivity scenario.

Official FRED documentation says ordinary queries default to current real-time information; ALFRED can retrieve information as known at a past period, with real-time parameters expressed as dates [3]. The vintage-date endpoint lists dates on which observations were added or revised [4]. Such a change date alone does not distinguish publication before versus after noon. Vintage observations could help identify value revisions and preceding-day availability, but no authenticated historical SP500 vintage series was retrieved in this audit; an attempt to open the ALFRED SP500 page through the web tool failed. No key was supplied or invented. The available sources do not certify intraday availability across the sample.

Accordingly, **publication status and revision status are UNVERIFIED in every primary audit row**. We do not assume that SP500 never revises, equate today's value with its historical vintage, or infer publication from an observation's date. A rigorous FRED-only replay requires archived releases or timestamped vintage evidence and reconstruction using those values. Numerical future-value perturbation tests cannot detect revisions to already-dated historical inputs. The existing data snapshots are left unchanged.

## Actual automated test results

[Ten new tests passed](validation/point_in_time_tests.txt), in addition to the six original calculation tests rerun after correcting their UTC-only assertion. The new suite explicitly detects the old timezone failure rather than inheriting it.

| Test | Actual coverage/result |
|---|---|
| Frequency and timezone | All 52 Fridays; old 36 local-noon failures detected; corrected local noon passes |
| Feature windows | All 52 baselines/windows checked against exchange close timestamps |
| Training eligibility | Every primary candidate row at every origin compared with an independent timestamp oracle |
| Future-price poisoning | All 52 origins; nonuniform large changes to every close at/after cutoff leave A/B/C and coefficients unchanged |
| Unmatured-label poisoning | All 52 origins; large future returns and feature values leave coefficients/forecasts unchanged; original code's label gate also passes |
| Truncated input replay | All 52 origins; remove all post-cutoff prices and ineligible labels; same forecasts/coefficients |
| Unresolved/spoofed labels | Missing targets/returns and a false historical timestamp attached to a future target are excluded |
| DST and holiday edges | Different US/UK transition dates, observed closures and early closes pass |
| Missing latest price | Raises an error instead of silently using stale data |
| Deliberately leaky negative control | Intentionally including an unmatured label makes poisoning change a coefficient by 0.141916597; test detects the leak |

The table groups multiple assertions within the ten unittest methods; it is not a count of ten scalar assertions. [adversarial_results_52.csv](validation/adversarial_results_52.csv) records each origin's perturbation counts and outcomes. Maximum forecast/coefficient change under permissible future-data attacks is exactly zero. A remaining pandas/calendar deprecation warning is included in the logs and is not a test failure. Tests establish behaviour for the exercised paths, not a universal proof of correctness or data provenance.

## Corrections and before/after metrics

Changes: local-noon timezone construction; calendar-timestamp feature selection and training eligibility; separation of forecast inputs from realised evaluation labels; unresolved-target rejection; consistent delayed-label timestamps; new audit ledgers and adversarial checks. **No factor, coefficient, training sample, held-out origin or target convention changed.**

| Model | Before MAPE | After MAPE | Median APE | Maximum APE | Beat A | Mean score /50 |
|---|---:|---:|---:|---:|---:|---:|
| A | 1.447796% | 1.447796% | 1.386506% | 4.229546% | — | 42.760577 |
| B | 1.454056% | 1.454056% | 1.228327% | 4.271151% | 46.153846% | 42.730000 |
| C | 1.425992% | 1.425992% | 1.273781% | 4.084476% | 57.692308% | 42.869038 |

All displayed metrics, all 52 primary forecasts and all nine panel/model summary rows are unchanged at stored precision. [metrics_before_after.csv](results/metrics_before_after.csv) contains 54 comparisons including all three panels. The summer origin moves one hour earlier, but both times precede the next daily close and follow the same eligible prior close; the old label dates also selected the same matured outcomes. This explains the zero metric changes without dismissing the alignment errors.

## Reproduce and inspect

From the project root, run:

```sh
python3 research/src/run_backtest.py
python3 research/src/audit_point_in_time.py
python3 research/src/test_point_in_time.py
python3 research/src/test_backtest.py
```

Pinned dependencies remain in `research/requirements.txt` and project-local `research/vendor`. `before/` is the immutable pre-audit comparison; the active corrected outputs are in `research/results`. Audit results and logs are under `research/pit_audit`. Code changes are also saved as a unified diff. No binding forecast is produced by these commands.

## Sources

[1] FRED, *S&P 500 [SP500]*, inspected 31 October 2026; raw page and original retrieval metadata retained in `research/sources`. https://fred.stlouisfed.org/series/SP500

[2] NYSE, *Holidays and Trading Hours*, inspected 31 October 2026; current official rules plus the saved XNYS historical schedule from exchange_calendars 4.13.2. https://www.nyse.com/markets/hours-calendars . Calendar implementation: https://github.com/gerrymanoim/exchange_calendars . A current historical calendar is not an archive of when each closure was announced; unusual closure announcement timing remains outside this audit's certification.

[3] Federal Reserve Bank of St. Louis, *FRED API Real-Time Periods*, inspected 31 October 2026. https://fred.stlouisfed.org/docs/api/fred/realtime_period.html

[4] Federal Reserve Bank of St. Louis, *fred/series/vintagedates* and *fred/series/observations*, inspected 31 October 2026. https://fred.stlouisfed.org/docs/api/fred/series_vintagedates.html ; https://fred.stlouisfed.org/docs/api/fred/series_observations.html . Tool response evidence is retained in `sources/`; ALFRED page attempt: https://alfred.stlouisfed.org/series?seid=SP500 (tool access failed).

# Observable research record

31 October 2026: inspected the existing audited specification and data boundary. Preserved A/B/C through file hashes. Consulted official FRED DGS10, Fed H.15 publication guidance, BLS/BEA releases, FOMC statement/calendar, company earnings releases and SEC-hosted evidence.

Retrieved DGS10 at 14:29:54 UTC; raw CSV contains 1,268 values through 29 October and 57 blanks. Saved response metadata and hashes. Initial source set downloaded successfully except BLS pages, which returned 403; official web-tool responses were accessible and saved. Later company documents downloaded; SEC direct download failed but its web-tool response was preserved. No failed request was replaced by invented observations.

Wrote PROTOCOL.md before candidate metrics: new D only, five observed Treasury-session changes, next-business-day 16:15 NY availability proxy, separate 2024–June 2025 chronological evaluation, fixed sensitivities and scenarios. No variant selected by performance. The six-session equity label convention remains unchanged.

Executed 59 primary forecasts plus three disclosed sensitivities. Primary D MAPE 1.831260%, C 1.807673%, A 1.828480%; no robust incremental gain. Yield slope remained negative. Uncertainty interval crosses zero. Kept all failures, including score-floor observations. No original-52 or October model selection/tuning run was added.

Verified all fits by centered sums and all 59 primary fits independently with Decimal source-value reconstruction. Tested unpublished yields and unmatured labels by perturbation for every evaluation origin. Ran six unit tests: all passed. Checked original code/specification/result hashes unchanged. Inspected the generated figure visually.

Built a separate eight-event October timeline and 48 origin/event classifications. Exact official release times were used for inflation and FOMC; earnings use date bounds where precise first-publication times were unverified. Recorded known-before-origin versus later-release status without inventing consensus surprises. Saved all available daily October yields and six historical Friday-noon proxy snapshots. Apple earnings/date and inaccessible September-meeting minutes contents were not fabricated.

Reported a prespecified +/-25bp factor sensitivity and +25bp/3%-equity-fall scenario at the last historical evaluation origin. Added a clearly labelled analytic risk-off failure illustration (-25bp with a 3% equity fall), without modifying fitting or evaluation. Generated report, reproduction README, dated snapshots and manifests. No binding November forecast or submission action occurred.

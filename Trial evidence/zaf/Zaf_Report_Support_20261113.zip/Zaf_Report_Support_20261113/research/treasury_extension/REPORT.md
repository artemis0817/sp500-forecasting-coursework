# Do Treasury yield changes improve six-session S&P 500 forecasts

Research date 31 October 2026. **The tested Treasury factor does not establish incremental predictive improvement.** In a separate chronological comparison of 59 forecasts, candidate D has MAPE 1.8313%, versus 1.8077% for C and 1.8285% for A. Its yield coefficient has the economically expected negative sign, but forecast gains are absent and timing assumptions materially affect its magnitude. Preserve A as the provisional operational default and C as a challenger; do not promote D or alter A/B/C from these results. No binding November forecast was generated.

## Candidate and mechanism

D adds one factor to the existing momentum regression:

`r6 = a + b*m20 + g*dy5`, `forecast = P_t*(1+r6)`.

`m20 = P_t/P_(t−20)−1` uses 20 XNYS trading-session intervals. `dy5 = Y_u−Y_(u−5)` uses five **Treasury observation-session intervals** (six nonmissing daily DGS10 observations). DGS10 is quoted in percent, so dy5 is in percentage points; +25 basis points is +0.25, not 25 or a 25% relative change. All endpoint dates are saved. Bond holidays differ from equity holidays: five Treasury observations need not cover exactly five NYSE sessions. There is no interpolation or forward filling; missing dates are logged and a span over 14 calendar days raises an error. Treating observed yield dates as Treasury sessions cannot distinguish an unrecorded unexpected outage from a market holiday, a remaining calendar limitation.

The source is FRED DGS10, sourced from the Federal Reserve's H.15, at daily frequency [1,2]. The downloaded snapshot contains 1268 observations from 2021-10-01 to 2026-10-29, plus 57 blank dates. It was retrieved on 31 October at 14:29:54 UTC; URL, response headers and SHA-256 are saved. The 30 October observation is not in the download and is never invented.

Expected g is negative: higher long rates can increase discount rates applied to distant equity cash flows, raise borrowing costs and make bonds more competitive. Growth-oriented equities can be particularly exposed to discount-rate changes. This is a hypothesis about an aggregate index, not a causal identification strategy. Rising yields can instead reflect stronger expected growth and earnings. Falling yields can accompany recession fears, safe-haven demand and simultaneous equity declines. Nominal yields combine real-rate, inflation-expectation and term-premium effects, which D does not separate. New announcements after cutoff, priced-in information, changing regimes and endogenous equity/rate responses can all invalidate extrapolation of last week's relationship.

## Timing and training discipline

Origins remain Friday 12:00 Europe/London, converted through UTC and America/New_York. The equity baseline is the latest preceding exchange close; holidays and early closes use the existing audited calendar. Targets are next-Friday closes with exactly six intervening equity sessions. This preserves the existing A/B/C convention.

H.15 states that it posts at 16:15 on business days; the retrieved 30 October release contains 29 October observations [2]. The primary rule therefore assumes next conservative federal-business-day publication at 16:15 New York, with no further FRED processing delay. It normally uses **Wednesday yields at Friday noon**, while equities use Thursday's close. Federal holidays, Good Friday and the exceptional 9 January 2025 closure are conservatively skipped for this proxy. These extra exclusions can delay an input; they are not proof that H.15 was actually closed that day.

Every training feature uses the yield vintage proxy applicable at its **own** historical origin. Every label must have a target closing timestamp strictly before the current fitting origin; current-Friday closes are excluded. A/B/C remain the original functions/specifications. D estimates an intercept plus two unconstrained slopes by expanding OLS with at least 52 matured rows. No scaling, regularisation, feature selection or hyperparameter search is fitted. C and D have identical training-row counts in the primary comparison, so their difference isolates the added factor rather than changed data coverage.

**This is not a certified point-in-time FRED replay.** Next-day release timing is a declared proxy; a current update timestamp does not establish first availability for every historical observation. Exact historical FRED processing times, revisions and SP500 vintages are unknown. The raw snapshots were retrieved after the historical origins. Both a further publication lag and an optimistic same-day bound are reported below. An optimistic result would not make that timing convention valid.

## Separate chronological evaluation

The protocol was saved before candidate results. Evaluation origins are fixed to January 2024–June 2025: the 59 eligible origins run **5 January 2024–20 June 2025**, with targets 12 January 2024–27 June 2025. Closed/shortened weeks are excluded by the unchanged six-session convention. The first fit has 85 matured rows and the last 143.

No origin overlaps the previously examined 52-origin test, which starts 18 July 2025. Every new evaluation target precedes that first origin. October outcomes and the existing 52 test outcomes are never used to fit, select or score D in this experiment. Earlier outcomes in the new evaluation period may enter later fits only once realised, as required by the expanding online rule. The original 52 results are neither overwritten nor reselected.

This period was formerly part of the original models' training history. It is a separate chronological out-of-sample replay for each forecast, **not newly collected, pristine prospective evidence**; prior research/design exposure remains. A separate fixed test is used instead of nested tuning because no parameter/variant is selected by validation. Sensitivities are disclosed diagnostics, not a menu from which to pick a winner.

## Errors and incremental information

| Model | n | MAPE % | Median % | Maximum % | Mean score /50 | Beat A % | Beat C % |
|---|---|---|---|---|---|---|---|
| A | 59 | 1.8285 | 1.5029 | 12.2038 | 41.045 | — | 40.67 |
| B | 59 | 1.8334 | 1.2771 | 11.3986 | 40.952 | 49.15 | 45.76 |
| C | 59 | 1.8077 | 1.5442 | 12.4079 | 41.166 | 59.32 | — |
| D | 59 | 1.8313 | 1.5998 | 12.1732 | 41.028 | 50.84 | 42.37 |

Errors use the actual close as denominator. Scores use the original capped formula `round(max(0,50−5*APE%),2)`; the mean of individual scores need not equal 50−5×MAPE when a loss exceeds 10%. All large failures are retained. D beats C in only 25 of 59 weeks (42.37%). Its mean score is 0.138 marks below C and 0.017 below A.

The mean paired D−C APE difference is **+0.02359 percentage points**, where positive means D is worse. A four-observation circular block bootstrap (5,000 draws, fixed seed) gives a descriptive 95% interval **−0.07365 to +0.12070**. D−A is +0.00278, interval −0.13048 to +0.13961. Eight-observation blocks give the same qualitative conclusion. Overlap in weekly returns, irregular omitted holiday weeks and limited observations constrain inference; these intervals are not proof of equivalence or absence of all predictive information.

The primary yield slope is negative at all 59 fits: range **−0.03663 to −0.02527**, median −0.03106, ending at −0.02737 decimal return per percentage-point yield change. The expected sign is therefore stable within this fit sequence, but that does not imply out-of-sample predictive value. Design condition numbers stay below 22.36 for primary raw regressors; this does not establish parameter precision. No causal interpretation or statistical-significance claim is made.

![Coefficient path and cumulative forecast errors](figures/stability_and_errors.png)

## Robustness and sensitivities

| Candidate variant | MAPE % | Mean score /50 |
|---|---|---|
| primary | 1.8313 | 41.028 |
| extra_release_lag | 1.8272 | 41.068 |
| optimistic_same_day | 1.8520 | 40.911 |
| trailing104 | 1.8242 | 41.093 |

None of these prespecified D variants beats C's 1.8077% primary MAPE. One extra publication day reduces the median yield coefficient magnitude from about 0.03106 to 0.00879, so the factor is economically sensitive to alignment. The trailing-104 fit retains a negative sign but its slope weakens substantially. A/B/C are unchanged in every panel.

D is worse than C in both chronological halves, in 2024 and 2025 separately, and in both rising-yield and flat/falling-yield subsets. Removing any single evaluation loss from aggregation still leaves D−C MAPE positive (range +0.00877 to +0.04426 percentage points); the incremental shortfall is not attributable to one observation alone. Relative to A, the leave-one-out ranking can change. These are descriptive robustness checks with no multiple-testing-adjusted discovery claim.

## Quantified adverse scenarios

Use only the last **evaluation** origin, 20 June 2025, baseline 5,980.87 and g=−0.027374154. Holding momentum and coefficients fixed, adding 25 bp to the observed five-session yield-change factor lowers D's predicted return by **0.68435 percentage points**, or **40.93 index points**; subtracting 25 bp raises it by the same amount. This is a conditional factor perturbation, not a prediction of a yield shock's causal effect. A shock after the origin cannot actually be used to update an already-issued forecast.

Under the prespecified illustrative +25 bp factor shift and a hypothetical equity target 3% below baseline (5,801.4439), D forecasts 5,965.65: error 2.8305%, score 35.85/50. A scores 34.54; C scores 33.55. Even a favourable directional mechanism can leave a large level error.

An additional analytical failure illustration (not another evaluated or selected model) reverses the yield move: safe-haven demand lowers yields 25 bp while equities still fall 3%. D then forecasts **6,047.51**, its error rises to **4.2415%** and its score falls to **28.79/50**. This exposes the failure of assuming that lower yields necessarily support stocks. Scenario magnitudes are assumptions without probabilities and are not November forecasts.

## Separate October timeline

[The dated timeline](timeline/TIMELINE.md) and its 48 origin/event classifications distinguish published outcomes from information unavailable at each Friday cutoff. It covers official CPI, PPI and PCE releases, the 28 October FOMC decision, and Meta, Microsoft, Alphabet and Amazon earnings. Earnings dates are verified; where a release clock time was not established, whole-date bounds are used rather than inventing a timestamp or substituting the webcast time. BLS direct downloads returned 403, so accessible official-page web responses are retained. An Alphabet direct download also returned 403; the SEC-hosted document was accessible through the web tool.

CPI/PPI released 14–15 October were later information for the 9 October origin but known by 16 October. Meta's 21 October release was known by 23 October. The Fed decision and Microsoft/Alphabet releases on 28 October, and PCE/Amazon on 29 October, were all later information for the 23 October origin. The dates of scheduled announcements can be known in advance without their results being known. **No archived pre-release consensus was retrieved**, so numerical “surprises” or beat/miss claims are unverified and are not used as explanations of model errors.

The daily Treasury timeline shows yields at 5.29% on 30 September and 4.98% on 29 October, a 31 bp fall. The latest observation is not a 30 October close. These contemporaneous changes alongside inflation and earnings news do not identify causation. The model experiment and event timeline remain separate.

## Verification, preservation and next step

Six automated tests pass, including independent Decimal OLS/forecast reconstruction for all 59 primary origins, timestamp and no-overlap assertions, DST/holiday checks, unit checks and score-cap checks. All 59 unpublished-yield poisoning and unmatured-label poisoning tests pass. Independently computed centered-sum coefficients also match every numerical fit. These checks establish calculation behaviour, not historical source publication proof. Original A/B/C code, specifications and result files are hash-verified unchanged.

Keep D as a documented rejected-for-now candidate. Further investigation requires verified release/vintage data and genuinely new forward validation, or a fresh nested development design with any new factor definitions selected only inside earlier training folds. Do not tune this candidate against the old 52 results or the October timeline. There is no evidence here sufficient to replace the provisional simple model.

## Sources

[1] Federal Reserve Board via FRED, *DGS10*, retrieved 31 October 2026. https://fred.stlouisfed.org/series/DGS10 . Raw data and provenance: `data/dgs10.csv` and its metadata JSON.

[2] Federal Reserve Board, *H.15 Selected Interest Rates* and *About*, retrieved 31 October 2026. https://www.federalreserve.gov/releases/h15/ ; https://www.federalreserve.gov/releases/h15/about.htm . Daily schedule and dated release snapshot support the timing investigation, not a complete historical archive.

[3] S&P DJI via FRED, *SP500*, original project snapshot retrieved 31 October 2026. https://fred.stlouisfed.org/series/SP500 . Existing audited code and model specifications are referenced without modification. XNYS sessions: exchange_calendars 4.13.2; conservative federal holiday proxy: pandas USFederalHolidayCalendar plus stated exclusions.

[4] October release-specific original sources are linked individually in `timeline/TIMELINE.md` and `timeline/events.csv`, including BLS, BEA, Federal Reserve, company investor relations and SEC. No media narrative or retrospective AI statement is treated as evidence of a pre-cutoff surprise.

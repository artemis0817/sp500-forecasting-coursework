from pathlib import Path
import sys,json
from datetime import date,datetime,time,timedelta,timezone
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
import calculate as c
b=c.b
# Exact release times only when supported by primary release text; earnings use whole-date bounds.
events=[
 ('2026-10-14','08:30','Inflation','September CPI','Headline +0.6% m/m and +3.7% y/y; core +0.3% m/m and +2.6% y/y.','https://www.bls.gov/news.release/archives/cpi_10142026.htm'),
 ('2026-10-15','08:30','Inflation','September PPI','Final demand +1.3% m/m and +6.3% y/y.','https://www.bls.gov/news.release/archives/ppi_10152026.htm'),
 ('2026-10-21',None,'Technology earnings','Meta Q3','Revenue $64.601bn; diluted EPS $3.83; webcast scheduled 16:30 ET. Release clock time unverified.','https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/default.aspx'),
 ('2026-10-28','14:00','Federal Reserve','FOMC decision','Held target range at 3.75%-4.00%; vote 10-2, with two dissenters preferring +25bp.','https://www.federalreserve.gov/newsevents/pressreleases/monetary20261028a.htm'),
 ('2026-10-28',None,'Technology earnings','Microsoft FY27 Q1','Revenue $92.3bn; GAAP EPS $4.92; Azure growth 48%; webcast scheduled 17:30 ET. Release clock time unverified.','https://www.microsoft.com/en-us/Investor/earnings/FY-2027-Q1/press-release-webcast'),
 ('2026-10-28',None,'Technology earnings','Alphabet Q3','Revenue $127.6bn; EPS $2.12; date verified by SEC-hosted earnings exhibit, clock time unverified.','https://www.sec.gov/Archives/edgar/data/1652044/000165204426000080/googexhibit991q32026.htm'),
 ('2026-10-29','08:30','Inflation','September PCE prices','Headline +0.5% m/m and +3.6% y/y; core +0.3% m/m and +3.1% y/y.','https://www.bea.gov/news/2026/personal-income-and-outlays-september-2026'),
 ('2026-10-29',None,'Technology earnings','Amazon Q3','Net sales $201.944bn; net income $20.685bn; AWS sales about $45.984bn. Release clock time unverified.','https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Third-Quarter-Results/default.aspx')]
origins=[date(2026,9,25)]+[date(2026,10,d) for d in [2,9,16,23,30]]
rows=[];matrix=[]
for ds,clock,cat,name,value,url in events:
 d=date.fromisoformat(ds)
 if clock:
  lo=hi=datetime.combine(d,time.fromisoformat(clock),b.NEW_YORK);precision='exact scheduled/public release time'
 else:
  lo=datetime.combine(d,time.min,b.NEW_YORK);hi=datetime.combine(d,time.max,b.NEW_YORK);precision='date only; interval bounds are not publication timestamps'
 r={'event_date':ds,'category':cat,'event':name,'outcome':value,'release_time_precision':precision,
    'earliest_UTC_bound':lo.astimezone(timezone.utc).isoformat(),'latest_UTC_bound':hi.astimezone(timezone.utc).isoformat(),
    'London_release_time':lo.astimezone(b.LONDON).isoformat() if clock else ds+' (date only)',
    'source_url':url,'consensus_surprise':'UNVERIFIED: no archived pre-release expectation retrieved'}
 for o in origins:
  cutoff=b.origin_at(o);status='known before cutoff' if hi<cutoff else 'released after cutoff' if lo>=cutoff else 'intraday timing unresolved'
  matrix.append({'origin_London':cutoff.isoformat(),'target_date':o+timedelta(days=7),'event':name,'event_date':ds,
      'outcome_availability':status,'surprise_status':'unknown; later release is not proof of a market surprise','source':url})
  r[str(o)]=status
 rows.append(r)
c.write('timeline/events.csv',rows);c.write('timeline/origin_event_matrix.csv',matrix)
yields,missing=c.load_yields();october=[d for d in yields if d.year==2026 and d.month==10]
c.write('timeline/daily_treasury_yields.csv',[{'observation_date':d,'yield_percent':yields[d],
    'release_proxy_New_York':c.release_at(d).isoformat(),'release_proxy_London':c.release_at(d).astimezone(b.LONDON).isoformat(),
    'publication_status':'proxy only; exact FRED historical availability unverified'} for d in october])
features=[]
for o in origins:
 f=c.yield_feature(yields,o)
 features.append({'origin_London':b.origin_at(o).isoformat(),**f,'five_session_change_bp':100*f['yield_change_pp']})
c.write('timeline/yields_known_at_origins_proxy.csv',features)
lines=['# October 2026 information timeline','',
'This is a dated descriptive timeline, separate from the model experiment. No event is a fitted feature, a coefficient adjustment or proof of the cause of an S&P move. There is no November point forecast.', '',
'## Official releases and selected technology earnings','',
'| Date/time London | Event | Released information | First listed Friday cutoff with outcome known |','|---|---|---|---|']
for r in rows:
 known=[str(o) for o in origins if r[str(o)]=='known before cutoff']
 lines.append(f"| {r['London_release_time']} | [{r['event']}]({r['source_url']}) | {r['outcome']} | {known[0] if known else 'none'} |")
lines+=['','For example, the 9 October forecast could not use the CPI or PPI outcomes released on 14–15 October. The 16 October forecast could use those inflation reports but not Meta’s 21 October outcome. The 23 October forecast could use Meta’s results but could not use the 28 October Fed/Microsoft/Alphabet releases or 29 October PCE/Amazon releases. The 30 October column is context for information availability only; no November forecast is calculated.', '',
'Scheduled event versus surprise: the BLS October calendar, last modified 18 February 2026, listed CPI/PPI dates in advance; the Fed calendar lists the 27–28 October meeting. Knowing an event date is not knowing its outcome. No archived consensus forecasts or futures-implied expectations were retrieved, so numerical surprise magnitudes and “beat/miss” classifications are intentionally unverified. Earnings release dates are verified, but their original announcement dates and exact first-distribution clock times were not established. Whole-date bounds suffice for the Friday cutoffs here. Webcast times are not substituted for release times.', '',
'## Treasury yields','',
'| Friday London cutoff | Latest yield date under proxy | Yield % | Five-session earlier date | Five-session change bp |','|---|---|---|---|---|']
for f in features:lines.append(f"| {f['origin_London']} | {f['yield_date']} | {f['yield_level']:.2f} | {f['yield_lookback_date']} | {f['five_session_change_bp']:+.1f} |")
lines+=['',f"DGS10 moved from {yields[date(2026,9,30)]:.2f}% on 30 September to {yields[max(october)]:.2f}% on {max(october)}, a {100*(yields[max(october)]-yields[date(2026,9,30)]):+.0f} bp change. The latest available downloaded observation is 29 October, not 30 October. Daily values and release proxies are in `daily_treasury_yields.csv`. On 12 October no DGS10 value is present; it is a federal/bond holiday and was not filled. Equity and Treasury calendars differ.", '',
'The primary proxy is next conservative federal-business-day 16:15 New York. Thus on 23 October noon the latest yield observation is 21 October (5.13%), not 22 October (4.96%). The 22 October value would be released after that cutoff under this rule. On 30 October noon the latest proxy-eligible observation is 28 October (5.05%), not 29 October (4.98%). These are model timing assumptions, not independently archived FRED release timestamps.', '',
'## Coverage and limitations','',
'The earnings selection covers Meta, Microsoft, Alphabet and Amazon. It is not an exhaustive technology earnings calendar. Searches did not establish an October 2026 Apple earnings release from its official investor/newsroom pages; no date or result was invented. The Fed calendar also lists September-meeting minutes released 7 October, but the linked minutes text failed to load; no content-based interpretation is assigned.', '',
'Primary source snapshots/metadata are retained under `../sources/`. Direct BLS HTML downloads returned HTTP 403, so the accessible official-page web-tool responses were preserved instead. The source checks establish published release content, not historical FRED vintages or prior market expectations. Inflation/PPI/PCE and earnings can later revise or restate; the dated release pages are the evidence used here.']
(BASE/'timeline/TIMELINE.md').write_text('\n'.join(lines)+'\n')
print('Saved',len(rows),'events,',len(matrix),'origin/event classifications,',len(october),'daily Treasury observations')

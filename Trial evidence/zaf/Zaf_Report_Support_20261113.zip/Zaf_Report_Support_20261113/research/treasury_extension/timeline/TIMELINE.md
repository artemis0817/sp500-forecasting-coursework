# October 2026 information timeline

This is a dated descriptive timeline, separate from the model experiment. No event is a fitted feature, a coefficient adjustment or proof of the cause of an S&P move. There is no November point forecast.

## Official releases and selected technology earnings

| Date/time London | Event | Released information | First listed Friday cutoff with outcome known |
|---|---|---|---|
| 2026-10-14T13:30:00+01:00 | [September CPI](https://www.bls.gov/news.release/archives/cpi_10142026.htm) | Headline +0.6% m/m and +3.7% y/y; core +0.3% m/m and +2.6% y/y. | 2026-10-16 |
| 2026-10-15T13:30:00+01:00 | [September PPI](https://www.bls.gov/news.release/archives/ppi_10152026.htm) | Final demand +1.3% m/m and +6.3% y/y. | 2026-10-16 |
| 2026-10-21 (date only) | [Meta Q3](https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/default.aspx) | Revenue $64.601bn; diluted EPS $3.83; webcast scheduled 16:30 ET. Release clock time unverified. | 2026-10-23 |
| 2026-10-28T18:00:00+00:00 | [FOMC decision](https://www.federalreserve.gov/newsevents/pressreleases/monetary20261028a.htm) | Held target range at 3.75%-4.00%; vote 10-2, with two dissenters preferring +25bp. | 2026-10-30 |
| 2026-10-28 (date only) | [Microsoft FY27 Q1](https://www.microsoft.com/en-us/Investor/earnings/FY-2027-Q1/press-release-webcast) | Revenue $92.3bn; GAAP EPS $4.92; Azure growth 48%; webcast scheduled 17:30 ET. Release clock time unverified. | 2026-10-30 |
| 2026-10-28 (date only) | [Alphabet Q3](https://www.sec.gov/Archives/edgar/data/1652044/000165204426000080/googexhibit991q32026.htm) | Revenue $127.6bn; EPS $2.12; date verified by SEC-hosted earnings exhibit, clock time unverified. | 2026-10-30 |
| 2026-10-29T12:30:00+00:00 | [September PCE prices](https://www.bea.gov/news/2026/personal-income-and-outlays-september-2026) | Headline +0.5% m/m and +3.6% y/y; core +0.3% m/m and +3.1% y/y. | 2026-10-30 |
| 2026-10-29 (date only) | [Amazon Q3](https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Third-Quarter-Results/default.aspx) | Net sales $201.944bn; net income $20.685bn; AWS sales about $45.984bn. Release clock time unverified. | 2026-10-30 |

For example, the 9 October forecast could not use the CPI or PPI outcomes released on 14–15 October. The 16 October forecast could use those inflation reports but not Meta’s 21 October outcome. The 23 October forecast could use Meta’s results but could not use the 28 October Fed/Microsoft/Alphabet releases or 29 October PCE/Amazon releases. The 30 October column is context for information availability only; no November forecast is calculated.

Scheduled event versus surprise: the BLS October calendar, last modified 18 February 2026, listed CPI/PPI dates in advance; the Fed calendar lists the 27–28 October meeting. Knowing an event date is not knowing its outcome. No archived consensus forecasts or futures-implied expectations were retrieved, so numerical surprise magnitudes and “beat/miss” classifications are intentionally unverified. Earnings release dates are verified, but their original announcement dates and exact first-distribution clock times were not established. Whole-date bounds suffice for the Friday cutoffs here. Webcast times are not substituted for release times.

## Treasury yields

| Friday London cutoff | Latest yield date under proxy | Yield % | Five-session earlier date | Five-session change bp |
|---|---|---|---|---|
| 2026-09-25T12:00:00+01:00 | 2026-09-23 | 5.11 | 2026-09-16 | +10.0 |
| 2026-10-02T12:00:00+01:00 | 2026-09-30 | 5.29 | 2026-09-23 | +18.0 |
| 2026-10-09T12:00:00+01:00 | 2026-10-07 | 5.28 | 2026-09-30 | -1.0 |
| 2026-10-16T12:00:00+01:00 | 2026-10-14 | 5.19 | 2026-10-06 | -8.0 |
| 2026-10-23T12:00:00+01:00 | 2026-10-21 | 5.13 | 2026-10-14 | -6.0 |
| 2026-10-30T12:00:00+00:00 | 2026-10-28 | 5.05 | 2026-10-21 | -8.0 |

DGS10 moved from 5.29% on 30 September to 4.98% on 2026-10-29, a -31 bp change. The latest available downloaded observation is 29 October, not 30 October. Daily values and release proxies are in `daily_treasury_yields.csv`. On 12 October no DGS10 value is present; it is a federal/bond holiday and was not filled. Equity and Treasury calendars differ.

The primary proxy is next conservative federal-business-day 16:15 New York. Thus on 23 October noon the latest yield observation is 21 October (5.13%), not 22 October (4.96%). The 22 October value would be released after that cutoff under this rule. On 30 October noon the latest proxy-eligible observation is 28 October (5.05%), not 29 October (4.98%). These are model timing assumptions, not independently archived FRED release timestamps.

## Coverage and limitations

The earnings selection covers Meta, Microsoft, Alphabet and Amazon. It is not an exhaustive technology earnings calendar. Searches did not establish an October 2026 Apple earnings release from its official investor/newsroom pages; no date or result was invented. The Fed calendar also lists September-meeting minutes released 7 October, but the linked minutes text failed to load; no content-based interpretation is assigned.

Primary source snapshots/metadata are retained under `../sources/`. Direct BLS HTML downloads returned HTTP 403, so the accessible official-page web-tool responses were preserved instead. The source checks establish published release content, not historical FRED vintages or prior market expectations. Inflation/PPI/PCE and earnings can later revise or restate; the dated release pages are the evidence used here.

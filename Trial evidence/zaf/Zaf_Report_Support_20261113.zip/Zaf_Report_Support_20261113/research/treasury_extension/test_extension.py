import unittest,json
from datetime import date,datetime,timezone
from decimal import Decimal,localcontext
import calculate as c
b=c.b
class ExtensionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.y,_=c.load_yields();cls.out=c.read(c.OUT/'results/all_forecasts.csv');cls.primary=[r for r in cls.out if r['variant']=='primary']
    def test_disjoint_chronology_and_training_timestamps(self):
        old={r['origin'] for r in c.read(c.ROOT/'results/primary_forecasts.csv')}
        self.assertEqual(len(self.primary),59)
        self.assertFalse(old&{r['origin'] for r in self.primary})
        for r in self.primary:self.assertLess(r['target_date'],min(old))
        for r in c.read(c.OUT/'validation/training_eligibility.csv'):
            if r['eligible']=='True':
                self.assertLess(datetime.fromisoformat(r['target_close']),datetime.fromisoformat(r['fitting_origin_timestamp']))
            self.assertLess(datetime.fromisoformat(r['yield_release_proxy']),b.origin_at(date.fromisoformat(r['training_origin'])))
    def test_yield_lag_DST_and_holiday(self):
        f=c.yield_feature(self.y,date(2026,10,23));self.assertEqual(f['yield_date'],date(2026,10,21))
        self.assertGreater(c.release_at(date(2026,10,22)),b.origin_at(date(2026,10,23)))
        self.assertEqual(c.next_business(date(2026,10,9)),date(2026,10,13))
        self.assertEqual(c.release_at(date(2026,3,12)).astimezone(timezone.utc).hour,20)
        self.assertEqual(b.origin_at(date(2026,3,13)).astimezone(timezone.utc).hour,12)
        self.assertEqual(b.origin_at(date(2026,4,10)).astimezone(timezone.utc).hour,11)
    def test_factor_units_and_constant_level_shift(self):
        o=date(2025,6,20);a=c.yield_feature(self.y,o);z=c.yield_feature({d:v+10 for d,v in self.y.items()},o)
        self.assertAlmostEqual(a['yield_change_pp'],z['yield_change_pp'],places=12)
        ds=[d for d in self.y if c.release_at(d)<b.origin_at(o)]
        self.assertEqual(a['yield_lookback_date'],ds[-6])
        changed=dict(self.y);changed[a['yield_date']]+=.25
        self.assertAlmostEqual(c.yield_feature(changed,o)['yield_change_pp']-a['yield_change_pp'],.25,places=12)
    def test_all_saved_adversarial_checks(self):
        rows=c.read(c.OUT/'validation/adversarial_checks.csv');self.assertEqual(len(rows),59)
        self.assertTrue(all(r['unpublished_yield_poison']=='PASS' and r['unmatured_return_poison']=='PASS' for r in rows))
    def test_independent_decimal_OLS_all_primary_origins(self):
        p={date.fromisoformat(r['observation_date']):Decimal(r['SP500']) for r in c.read(c.ROOT/'data/raw/fred_SP500.csv') if r['SP500'] not in ('','.')}
        yy={d:Decimal(str(v)) for d,v in self.y.items()}
        ledger=c.read(c.OUT/'validation/training_eligibility.csv')
        with localcontext() as ctx:
            ctx.prec=40
            for r in self.primary:
                train=[z for z in ledger if z['fitting_origin']==r['origin'] and z['eligible']=='True'];xs=[];zs=[];ys=[]
                for t in train:
                    bd=date.fromisoformat(t['SP_feature_close'][:10]);target=date.fromisoformat(t['target_close'][:10])
                    days=sorted(d for d in p if d<=bd);m=p[bd]/p[days[-21]]-1
                    yend=date.fromisoformat(t['yield_date']);ybeg=date.fromisoformat(t['yield_lookback_date'])
                    xs.append(m);zs.append(yy[yend]-yy[ybeg]);ys.append(p[target]/p[bd]-1)
                n=len(xs);xm=sum(xs)/n;zm=sum(zs)/n;ym=sum(ys)/n
                xx=sum((x-xm)**2 for x in xs);zz=sum((z-zm)**2 for z in zs);xz=sum((x-xm)*(z-zm) for x,z in zip(xs,zs))
                xy=sum((x-xm)*(y-ym) for x,y in zip(xs,ys));zy=sum((z-zm)*(y-ym) for z,y in zip(zs,ys));det=xx*zz-xz*xz
                beta=(xy*zz-zy*xz)/det;gamma=(zy*xx-xy*xz)/det;alpha=ym-beta*xm-gamma*zm
                for expected,key in [(alpha,'intercept'),(beta,'momentum_beta'),(gamma,'yield_beta')]:
                    self.assertAlmostEqual(float(expected),float(r[key]),places=11)
                bd=date.fromisoformat(r['base_date']);look=date.fromisoformat(r['lookback_date'])
                dy=yy[date.fromisoformat(r['yield_date'])]-yy[date.fromisoformat(r['yield_lookback_date'])]
                f=p[bd]*(1+alpha+beta*(p[bd]/p[look]-1)+gamma*dy)
                self.assertAlmostEqual(float(f),float(r['D_forecast']),places=8)
    def test_metric_caps_and_original_files_unchanged(self):
        meta=json.loads((c.OUT/'validation/run_checks.json').read_text())
        for path,h in meta['preserved_files'].items():self.assertEqual(c.sha(c.ROOT/path),h)
        for r in self.out:
            for m in 'ABCD':
                e=100*abs(float(r[m+'_forecast'])-float(r['actual']))/float(r['actual'])
                self.assertAlmostEqual(e,float(r[m+'_APE']),places=10)
                self.assertEqual(round(max(0,50-5*e),2),float(r[m+'_score']))
if __name__=='__main__':unittest.main(verbosity=2)

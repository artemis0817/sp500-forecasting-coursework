from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib
OUT=Path(__file__).resolve().parent
URLS={
'microsoft.html':'https://www.microsoft.com/en-us/Investor/earnings/FY-2027-Q1/press-release-webcast',
'meta.html':'https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/default.aspx',
'amazon.html':'https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Third-Quarter-Results/default.aspx',
'alphabet.html':'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000080/googexhibit991q32026.htm',
'fomc_calendar.html':'https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm',
'dgs10.csv':'https://fred.stlouisfed.org/graph/fredgraph.csv?id=DGS10&cosd=2021-10-01&coed=2026-10-30',
'dgs10_series.html':'https://fred.stlouisfed.org/series/DGS10',
'h15.html':'https://www.federalreserve.gov/releases/h15/',
'h15_about.html':'https://www.federalreserve.gov/releases/h15/about.htm',
'fomc_october.html':'https://www.federalreserve.gov/newsevents/pressreleases/monetary20261028a.htm',
'bls_calendar.html':'https://www.bls.gov/schedule/2026/10_sched.htm',
'cpi_september.html':'https://www.bls.gov/news.release/archives/cpi_10142026.htm',
'ppi_september.html':'https://www.bls.gov/news.release/archives/ppi_10152026.htm',
'pce_september.html':'https://www.bea.gov/news/2026/personal-income-and-outlays-september-2026'}
for name,url in URLS.items():
 dest=OUT/('data' if name.endswith('.csv') else 'sources')/name
 if dest.exists():continue
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 academic research'}),timeout=30) as r:
   raw=r.read();headers={k:v for k,v in r.headers.items() if k.lower() not in ['set-cookie','cookie','authorization']};resolved=r.url
  dest.write_bytes(raw)
  meta={'url':url,'resolved_url':resolved,'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),'headers':headers,'sha256':hashlib.sha256(raw).hexdigest()}
  dest.with_suffix(dest.suffix+'.metadata.json').write_text(json.dumps(meta,indent=2))
  print(name,len(raw),raw[-100:] if name.endswith('.csv') else '')
 except Exception as e:
  dest.with_suffix('.error.json').write_text(json.dumps({'url':url,'error':str(e),'attempted_at_utc':datetime.now(timezone.utc).isoformat()},indent=2));print(name,str(e))

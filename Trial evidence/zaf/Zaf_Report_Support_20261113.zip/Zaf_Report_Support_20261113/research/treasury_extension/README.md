# Treasury yield extension

Read `REPORT.md` for the incremental-predictability experiment and `timeline/TIMELINE.md` for the separate October event chronology. Main conclusion: the Treasury candidate does not establish an improvement. A/B/C remain unchanged.

Reproduce from the project root using the existing Python environment and pinned research dependencies:

```sh
MPLCONFIGDIR=/tmp/sp500-treasury-mpl python3 research/treasury_extension/calculate.py
python3 research/treasury_extension/test_extension.py
python3 research/treasury_extension/timeline/build_timeline.py
python3 research/treasury_extension/write_report.py
```

No live network, account or AI subscription is needed for these calculations. `calculate.py` loads original SP500 inputs and the saved DGS10 snapshot, imports the existing audited model helpers, and writes only under this extension. Matplotlib is also required for the saved figure. `retrieve.py` is optional source retrieval; it skips files already saved. Do not replace these frozen inputs and label a later retrieval as this run.

Files:
- `PROTOCOL.md`: specifications and evaluation design recorded before candidate results.
- `data/`: raw DGS10, UTC retrieval metadata and hash, blank-date log and explicit publication proxies.
- `results/`: all forecasts, metrics, coefficient stability, subperiods, paired uncertainty, scenario calculations and execution log.
- `validation/`: six passing tests, 59 adversarial checks, training eligibility ledger and unchanged-original-file hashes.
- `timeline/`: official release events, 48 origin/event availability classifications, 20 daily October yield observations and six cutoff yield-factor records. No earnings/news input is fitted.
- `sources/`: dated raw release documents, metadata, failed-download logs and web-tool fallbacks for official pages inaccessible to urllib.
- `figures/`: coefficient stability and cumulative errors.
- `snapshots/2026-10-31/`: frozen price/yield inputs and model/protocol files.

The 59 forecast origins (5 January 2024–20 June 2025) do not overlap the already inspected 52 origins. This is retrospective evaluation of former training-period data, not fresh prospective evidence. Historical FRED publication times and value revisions remain unverified; a conservative release-time proxy and timing sensitivities are disclosed. No binding November forecast exists.

# Trial 3 sharing evidence

Cutoff 2026-11-04T12:00:00Z; target 2026-11-11T21:00:00Z; issuance 2026-11-04T12:05:10.293385+00:00. Forward-issued after noon under revised protocol; late under initial before-noon rule.

Read trial_manifest.json for the exact raw inputs, original forecast/coefficients, source row and training ledger locations. Original entry scripts are historical evidence and may use the old project layout. Run ../reproduce.py from Zaf/ for all four offline verifications without fetching data or issuing forecasts. The shared code is under ../code/. Original manifest references outside this curated package are not evidence of missing model inputs; exclusions and redactions are documented in ../COPY_PROVENANCE.json.

"""Capture a trial information set, preserving separate unchanged source responses."""
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import json
import urllib.request

urls = {
    "sp500.csv": "https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500&cosd=2021-10-30",
    "dgs10.csv": "https://fred.stlouisfed.org/graph/fredgraph.csv?id=DGS10&cosd=2021-10-01",
    "sp500.html": "https://fred.stlouisfed.org/series/SP500",
    "yahoo.html": "https://finance.yahoo.com/quote/%5EGSPC/history/",
    "ft.html": "https://markets.ft.markitdigital.com/data/indices/tearsheet/historical?s=INX%3AIOM",
}
def now():
    return datetime.now(timezone.utc)

if __name__ == "__main__":
    root = Path(__file__).parent / now().strftime("%Y%m%dT%H%M%S%fZ")
    root.mkdir()
    for name, url in urls.items():
        meta = {"url": url, "request_started_utc": now().isoformat()}
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=30) as response:
                data = response.read()
                (root / name).write_bytes(data)
                meta.update(sha256=hashlib.sha256(data).hexdigest(), resolved_url=response.url,
                            headers={k:v for k,v in response.headers.items() if k.lower() in ("date","last-modified","content-type")})
        except Exception as exc:
            meta["error"] = str(exc)
        t = now()
        meta.update(retrieved_utc=t.isoformat(), retrieved_london=t.astimezone(ZoneInfo("Europe/London")).isoformat())
        (root / (name+".metadata.json")).write_text(json.dumps(meta, indent=2))
        print(name, meta.get("error", "saved"))
    print(root)

#!/usr/bin/env python3
"""Append-only live trial evidence. Never substitutes market close for verified publication."""
from pathlib import Path
import sys,csv,json,hashlib,shutil,urllib.request,argparse,statistics,copy
from datetime import date,datetime,time,timedelta,timezone
from decimal import Decimal,localcontext
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
HIST=ROOT/'evidence/historical'
sys.path[:0]=[str(HIST/'src'),str(ROOT.parent/'vendor')]
import run_backtest as b
import importlib.util
spec=importlib.util.spec_from_file_location('treasury_frozen',HIST/'treasury_extension/calculate.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
UTC=timezone.utc; LON=ZoneInfo('Europe/London')
DATES={date(2026,11,i):date(2026,11,i+7) for i in range(2,6)}
URLS={'sp500.csv':'https://fred.stlouisfed.org/graph/fredgraph.csv?id=SP500&cosd=2021-10-30','dgs10.csv':'https://fred.stlouisfed.org/graph/fredgraph.csv?id=DGS10&cosd=2021-10-01','sp500.html':'https://fred.stlouisfed.org/series/SP500','dgs10.html':'https://fred.stlouisfed.org/series/DGS10'}
def now():return datetime.now(UTC)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,default=str,allow_nan=False)+'\n')
def rows(p):return list(csv.DictReader(p.open()))
def write(p,rs):b.write_csv(p,rs)
def noon(day):return datetime.combine(day,time(12),LON)
def calendar():return b.xc.get_calendar('XNYS',start=str(b.START),end='2026-11-30')
def read_series(p,key):
 out={}
 for r in rows(p):
  if r[key] in ('','.'):continue
  day=date.fromisoformat(r['observation_date']);v=float(r[key])
  if day in out or not b.np.isfinite(v) or (key=='SP500' and v<=0):raise ValueError('Invalid/duplicate observation')
  out[day]=v
 return dict(sorted(out.items()))
def retrieve(dest):
 dest.mkdir(parents=True,exist_ok=False)
 for name,url in URLS.items():
  m={'url':url,'retrieval_started_utc':now().isoformat()}
  try:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as res:
    (dest/name).write_bytes(res.read());m.update(sha256=sha(dest/name),resolved_url=res.url,headers={k:v for k,v in res.headers.items() if k.lower() in ['date','last-modified','content-type']})
  except Exception as e:m['error']=str(e)
  m.update(retrieved_at_utc=now().isoformat());dump(dest/(name+'.metadata.json'),m)
 return dest

def inputs(p,cal,origin):
 stamp=noon(origin);target=DATES[origin];ss=[x.date() for x in cal.sessions]
 base=cal.schedule[cal.schedule['close']<stamp].index[-1].date();j=ss.index(base);look=ss[j-20]
 for day in ss[j-20:j+1]:
  if day not in p:raise ValueError(f'Missing expected price {day}; stale fallback forbidden')
 if ss.index(target)-j!=6:raise ValueError('Trial not six exchange sessions')
 if b.close_at(cal,target)!=datetime.combine(target,time(21),UTC):raise ValueError('Target close mismatch')
 return {'origin':origin,'origin_london':stamp.isoformat(),'origin_utc':stamp.astimezone(UTC).isoformat(),'origin_new_york':stamp.astimezone(b.NEW_YORK).isoformat(),'target_date':target,'target_close_utc':b.close_at(cal,target).isoformat(),'base_date':base,'lookback_date':look,'base':p[base],'lookback_level':p[look],'momentum':p[base]/p[look]-1,'horizon_sessions':6,'price_window_dates':ss[j-20:j+1]}

def yf(y,stamp):
 ds=[x for x in sorted(y) if d.release_at(x)<stamp]
 if len(ds)<6:raise ValueError('Missing Treasury lookback')
 start,end=ds[-6],ds[-1]
 # Require most recent expected primary-lag date, never silently use a stale feed.
 expected=stamp.date()-timedelta(days=1)
 while expected.weekday()>4 or expected in d.HOLIDAYS or d.release_at(expected)>=stamp:expected-=timedelta(days=1)
 if end!=expected:raise ValueError(f'Missing latest lag-eligible DGS10: expected {expected}, got {end}')
 if (end-start).days>14:raise ValueError('Excessive yield lookback gap')
 return {'yield_date':end,'yield_lookback_date':start,'yield_level':y[end],'yield_lookback_level':y[start],'yield_change_pp':y[end]-y[start],'yield_window_dates':ds[-6:],'yield_release_proxy':d.release_at(end).isoformat()}

def training(p,y,cal,stamp):
 pool=[];dp=[];ledger=[]
 fri=b.START+timedelta(days=(4-b.START.weekday())%7)
 while fri<stamp.date():
  target=fri+timedelta(days=7)
  if b.pd.Timestamp(target) in cal.sessions and b.close_at(cal,target)<stamp and target in p:
   if len([x for x in p if x<fri])>=21:
    r=b.forecast_inputs(p,cal,fri,target)
    if r['horizon_sessions']==6:
     r.update(actual=p[target],**{'return':p[target]/r['base']-1});pool.append(r)
     try:dp.append(dict(r,**yf(y,b.origin_at(fri))))
     except ValueError as e:ledger.append({'origin':fri,'reason':str(e),'D_included':False})
  fri+=timedelta(days=7)
 return pool,dp,ledger

def predict(p,y,origin):
 cal=calendar();stamp=noon(origin);f=inputs(p,cal,origin);tc,td,excluded=training(p,y,cal,stamp)
 co,delta=b.fit(tc);ret={'A':0.,'B':.25*f['momentum'],'C':float(co[0]+co[1]*f['momentum'])};coeff={'A':[0.,0.,0.],'B':[0.,.25,0.],'C':[float(co[0]),float(co[1]),0.]};warnings={};cond=None
 try:
  f.update(yf(y,stamp));cd,cond=d.fit_D(td);coeff['D']=list(map(float,cd));ret['D']=float(cd[0]+cd[1]*f['momentum']+cd[2]*f['yield_change_pp'])
 except (ValueError,AssertionError) as e:warnings['D']=str(e)
 out=[]
 for m in 'ABCD':
  tr=tc if m=='C' else td if m=='D' else []
  forecast=f['base']*(1+ret[m]) if m in ret else None
  if forecast is not None and (not b.np.isfinite(forecast) or forecast<=0):raise ValueError('Invalid forecast')
  out.append({'model':m,'predicted_six_session_return':ret.get(m),'forecast_full_precision':forecast,'forecast_level':format(forecast,'.2f') if forecast is not None else None,'intercept':coeff.get(m,[None]*3)[0],'momentum_beta':coeff.get(m,[None]*3)[1],'yield_beta':coeff.get(m,[None]*3)[2],'training_n':len(tr),'training_first_origin':tr[0]['origin'] if tr else None,'training_last_origin':tr[-1]['origin'] if tr else None,'training_latest_target':max(t['target_date'] for t in tr) if tr else None,'warning':warnings.get(m),'status':'calculated_under_unverified_availability' if forecast else 'blocked'})
 return f,out,tc,td,excluded,{'C_independent_coefficient_max_difference':delta,'D_design_condition':cond}

def validate(p,y,origin,result):
 f,out,tc,td,_,checks=result;cal=calendar();stamp=noon(origin)
 prefix={x:v for x,v in p.items() if b.pd.Timestamp(x) in cal.sessions and b.close_at(cal,x)<stamp};yy={x:v for x,v in y.items() if d.release_at(x)<stamp}
 truncated=predict(prefix,yy,origin)
 poisoned=dict(p);poison_y=dict(y)
 for x in cal.sessions:
  day=x.date()
  if b.close_at(cal,day)>=stamp:poisoned[day]=1e7+day.day
 for i in range(15):poison_y[origin+timedelta(days=i)]=80+i
 attacked=predict(poisoned,poison_y,origin)
 keys=['forecast_full_precision','intercept','momentum_beta','yield_beta','training_n']
 for k in keys:
  assert [r[k] for r in out]==[r[k] for r in truncated[1]]==[r[k] for r in attacked[1]],k
 # Explicit unmatured label gate using reconstructed calendar close, independent of supplied timestamps.
 fake=dict(tc[-1],target_date=DATES[origin],**{'return':1000})
 eligible=[r for r in tc+[fake] if b.close_at(cal,r['target_date'])<stamp]
 assert eligible==tc
 for tr in (tc,td):
  assert all(b.close_at(cal,r['target_date'])<stamp for r in tr)
 # Decimal OLS recomputed from raw endpoints and raw training outcomes.
 independent=[]
 with localcontext() as ctx:
  ctx.prec=40
  P={x:Decimal(str(v)) for x,v in p.items()};Y={x:Decimal(str(v)) for x,v in y.items()};m=P[f['base_date']]/P[f['lookback_date']]-1
  for r in out:
   model=r['model'];train=tc if model=='C' else td
   if r['forecast_full_precision'] is None:continue
   a=Decimal(0);bx=Decimal('.25') if model=='B' else Decimal(0);bz=Decimal(0)
   if model in 'CD':
    xs=[P[t['base_date']]/P[t['lookback_date']]-1 for t in train];rs=[P[t['target_date']]/P[t['base_date']]-1 for t in train];n=len(train);xm=sum(xs)/n;rm=sum(rs)/n;xx=sum((x-xm)**2 for x in xs);xr=sum((x-xm)*(v-rm) for x,v in zip(xs,rs));bx=xr/xx
    if model=='D':
     zs=[Y[t['yield_date']]-Y[t['yield_lookback_date']] for t in train];zm=sum(zs)/n;zz=sum((z-zm)**2 for z in zs);xz=sum((x-xm)*(z-zm) for x,z in zip(xs,zs));zr=sum((z-zm)*(v-rm) for z,v in zip(zs,rs));det=xx*zz-xz*xz;bx=(xr*zz-zr*xz)/det;bz=(zr*xx-xr*xz)/det
    a=rm-bx*xm-(bz*zm if model=='D' else 0)
   z=Y[f['yield_date']]-Y[f['yield_lookback_date']] if model=='D' else 0
   level=P[f['base_date']]*(1+a+bx*m+bz*z);diff=abs(float(level)-r['forecast_full_precision']);assert diff<1e-7
   independent.append({'model':model,'decimal_forecast':str(level),'absolute_difference':diff,'pass':True})
 checks.update(future_price_and_yield_poison='PASS',truncated_history='PASS',unmatured_target='PASS',six_sessions='PASS',source_first_availability='UNVERIFIED',historical_value_vintages='UNVERIFIED',prospective_certification=False)
 return checks,independent

def freeze(path,event):
 hashes={str(p.relative_to(path)):sha(p) for p in sorted(path.rglob('*')) if p.is_file() and p.name!='SHA256.json'}
 dump(path/'SHA256.json',hashes)
 register=ROOT/'evidence_register.jsonl';prev=hashlib.sha256(register.read_bytes()).hexdigest() if register.exists() else None
 with register.open('a') as h:h.write(json.dumps({'recorded_utc':now().isoformat(),'event':event,'path':str(path.relative_to(ROOT)),'manifest_sha256':sha(path/'SHA256.json'),'previous_register_sha256':prev})+'\n')

def run(origin,mode,source=None):
 if origin not in DATES:raise ValueError('Only 2–5 November trials; binding 13 November disabled')
 execution=now();cutoff=noon(origin)
 if mode=='prospective' and (execution.date()!=origin or execution>=cutoff):raise ValueError('Prospective computation must occur on origin date before noon; use replay separately')
 if mode=='replay' and execution<cutoff:raise ValueError('Future replay prohibited')
 runid=execution.strftime('%Y%m%dT%H%M%S%fZ')+'_'+mode
 dest=ROOT/str(origin)/'runs'/runid;dest.mkdir(parents=True,exist_ok=False)
 log={'command':sys.argv,'execution_started_utc':execution.isoformat(),'origin':cutoff.isoformat(),'mode':mode,'source':str(source) if source else 'new retrieval'};dump(dest/'execution_log.json',log)
 try:
  if source:shutil.copytree(source,dest/'raw')
  else:retrieve(dest/'raw')
  p=read_series(dest/'raw/sp500.csv','SP500');y=read_series(dest/'raw/dgs10.csv','DGS10')
  result=predict(p,y,origin);f,forecasts,tc,td,excluded,_=result;checks,independent=validate(p,y,origin,result)
  cal=calendar();manifest=[]
  for key,vals,name in [('SP500',p,'sp500.csv'),('DGS10',y,'dgs10.csv')]:
   meta=json.loads((dest/'raw'/(name+'.metadata.json')).read_text());retrieval=datetime.fromisoformat(meta['retrieved_at_utc']);used=f.get('base_date' if key=='SP500' else 'yield_date');last=max(vals)
   if sha(dest/'raw'/name)!=meta['sha256']:raise ValueError('Source hash mismatch')
   if mode=='prospective' and retrieval>cutoff:raise ValueError('Source retrieved after cutoff')
   manifest.append({'dataset':key,'provider':'FRED; S&P Dow Jones Indices' if key=='SP500' else 'FRED; Federal Reserve Board H.15','url':meta['url'],'instrument':'S&P 500 price index (excludes dividends)' if key=='SP500' else '10-year Treasury constant maturity yield','unit':'index points' if key=='SP500' else 'percent per annum; changes in percentage points','frequency':'daily close' if key=='SP500' else 'daily nonmissing observations','observation_date':last,'observation_timestamp':b.close_at(cal,last).isoformat() if key=='SP500' else None,'observation_timestamp_status':'scheduled exchange close, not publication' if key=='SP500' else 'source supplies date only; intraday observation time unverified','first_availability_timestamp':None,'retrieval_utc':retrieval.isoformat(),'retrieval_Europe_London':retrieval.astimezone(LON).isoformat(),'latest_observation_date':last,'latest_observation_value':vals[last],'last_used_date':used,'last_used_value':vals.get(used),'reporting_lag':'FRED delay unverified' if key=='SP500' else 'next federal business day 16:15 America/New_York proxy; FRED additional delay unknown','raw_file':'raw/'+name,'sha256':sha(dest/'raw'/name),'licence':'S&P copyrighted; retain for coursework; redistribution requires applicable permission' if key=='SP500' else 'Federal Reserve source; check FRED/source terms before redistribution','verification':'UNVERIFIED historical first availability and revisions; retrieval proves only observed by retrieval time'})
  for key,vals in [('SP500',p),('DGS10',y)]:
   eligible=[{'date':day,key:v,'observation_close_or_publication_proxy':b.close_at(cal,day).isoformat() if key=='SP500' else d.release_at(day).isoformat(),'availability_status':'proxy only'} for day,v in vals.items() if (b.pd.Timestamp(day) in cal.sessions and b.close_at(cal,day)<cutoff if key=='SP500' else d.release_at(day)<cutoff)]
   write(dest/f'processed/{key}_eligible.csv',eligible)
  cal.schedule.to_csv(dest/'processed/exchange_schedule.csv')
  dump(dest/'source_manifest.json',manifest);dump(dest/'model_inputs.json',f)
  write(dest/'calculation/training_C.csv',tc);write(dest/'calculation/training_D.csv',td);dump(dest/'calculation/D_exclusions.json',excluded)
  for r in forecasts:r.update(origin=cutoff.isoformat(),target=f['target_close_utc'],actual_execution_utc=execution.isoformat(),mode=mode,baseline=f['base'],baseline_date=str(f['base_date']),model_code_sha256=sha(Path(__file__)),historical_model_sha256=sha(HIST/'src/run_backtest.py'),treasury_model_sha256=sha(HIST/'treasury_extension/calculate.py'),source_snapshot_ids=[v['sha256'] for v in manifest],human_approval='pending',formally_issued=False,assumptions='Friday training transferred to weekday origins; SP500 market-close proxy; D next-business-day publication proxy; first availability and vintages unverified')
  dump(dest/'forecasts.json',forecasts);write(dest/'forecasts.csv',[{k:(json.dumps(v) if isinstance(v,list) else v) for k,v in r.items()} for r in forecasts]);dump(dest/'validation.json',checks);write(dest/'independent_checks.csv',independent)
  dump(dest/'status.json',{'status':'retrospective_noncertified_replay' if mode=='replay' else 'prospective_calculation_unverified_not_issued','completed_utc':now().isoformat(),'human_approval':'pending; group must approve Model D use and evidence limitations; approval does not establish historical availability'})
  (dest/'README.md').write_text(f'# {origin} {mode}\n\nUnissued research calculation. Source availability is not certified. Original computation time is recorded; intended noon origin is not an issuance timestamp. No target outcome is included.\n\nRecompute into a NEW run: `python3 research/live_trials/src/live_trials.py run --origin {origin} --mode replay --source {dest.relative_to(ROOT.parent.parent)}/raw`. Replay only after cutoff. Files here must not be edited. SHA256.json covers all run files; evidence register links the manifest. See overview for tests and approval responsibilities.\n')
 except Exception as e:
  dump(dest/'status.json',{'status':'BLOCKED','reason':str(e),'completed_utc':now().isoformat()});freeze(dest,'blocked_attempt');raise
 if mode=='prospective' and now()>=cutoff:
  dump(dest/'status.json',{'status':'BLOCKED','reason':'Calculation completed after cutoff; prospective issuance prohibited'})
 freeze(dest,'research_calculation_not_formal_issue');print(dest);return dest

def score_run(runpath,evidence):
 # Evidence must be a saved unmodified official/FRED response with metadata, not a manually typed actual.
 fs=json.loads((runpath/'forecasts.json').read_text());target=datetime.fromisoformat(fs[0]['target']);meta=json.loads((evidence.parent/(evidence.name+'.metadata.json')).read_text())
 if now()<=target:raise ValueError('Target is not yet due')
 retrieval=datetime.fromisoformat(meta['retrieved_at_utc'])
 if retrieval<=target or retrieval>now():raise ValueError('Invalid outcome retrieval time')
 if meta.get('url','').split('?')[0]!='https://fred.stlouisfed.org/graph/fredgraph.csv':raise ValueError('Expected established FRED official price-index dataset endpoint')
 if sha(evidence)!=meta['sha256']:raise ValueError('Outcome snapshot hash mismatch')
 values=read_series(evidence,'SP500');actual=values[target.date()];out=[]
 for f in fs:
  if f['forecast_level'] is None:continue
  forecast=float(f['forecast_level']);diff=abs(forecast-actual);ape=100*diff/actual;deduct=min(50,5*ape)
  out.append({'model':f['model'],'forecast_level':forecast,'actual_official_index_close':actual,'absolute_points':diff,'APE':ape,'marks_deducted':deduct,'accuracy_score':50-deduct,'forecast_mode':f['mode'],'formally_issued':f['formally_issued'],'forecast_sha256':sha(runpath/'forecasts.json')})
 best=min(r['APE'] for r in out)
 for r in out:r['trial_winner']=abs(r['APE']-best)<1e-12
 dest=runpath.parent.parent/'evaluations'/now().strftime('%Y%m%dT%H%M%S%fZ');dest.mkdir(parents=True);shutil.copy2(evidence,dest/evidence.name);dump(dest/'source_metadata.json',meta);write(dest/'scores.csv',out);freeze(dest,'later_scoring');print(dest)

def main():
 parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True)
 r=sub.add_parser('run');r.add_argument('--origin',type=date.fromisoformat,required=True);r.add_argument('--mode',choices=['replay','prospective'],required=True);r.add_argument('--source',type=Path)
 s=sub.add_parser('score');s.add_argument('--run',type=Path,required=True);s.add_argument('--evidence',type=Path,required=True)
 a=parser.parse_args()
 if a.command=='run':run(a.origin,a.mode,a.source)
 else:score_run(a.run,a.evidence)
if __name__=='__main__':main()

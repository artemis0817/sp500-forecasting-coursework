#!/usr/bin/env python3
"""Offline exploratory backtest. No final forecasting path. See frozen specifications."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
import csv,json,re,hashlib,statistics,platform,importlib.metadata
from datetime import date,datetime,time,timedelta,timezone
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
import exchange_calendars as xc
START=date(2021,10,30); CUT=date(2026,10,30)

def write_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['status']);w.writeheader();w.writerows(rows)

def score(e): return round(max(0.,50.-5.*e),2)
def ape(f,a): return 100*abs(f-a)/a

def load_prices():
    values={}; missing=[]
    with (ROOT/'data/raw/fred_SP500.csv').open() as f:
        for r in csv.DictReader(f):
            d=date.fromisoformat(r['observation_date'])
            if not START<=d<=CUT: continue
            if r['SP500'] in ('','.'): missing.append(d);continue
            v=float(r['SP500'])
            if d in values or not np.isfinite(v) or v<=0: raise ValueError('Invalid/duplicate price')
            values[d]=v
    # A separately retrieved primary-source page supplies the newest observation.
    html=(ROOT/'sources/fred_series.html').read_text()
    match=re.search(r'(\d{4}-\d{2}-\d{2}):\s*<span class="series-meta-observation-value">([\d,.]+)</span>',html)
    if not match: raise ValueError('Cannot parse latest FRED webpage observation')
    d=date.fromisoformat(match[1]);v=float(match[2].replace(',',''))
    supplemental=[]
    if START<=d<=CUT:
        if d in values: assert values[d]==v
        else: values[d]=v;supplemental=[{'date':d,'SP500':v,'source':'sources/fred_series.html'}]
    write_csv(ROOT/'data/processed/webpage_supplement.csv',supplemental)
    return dict(sorted(values.items())),missing

LONDON=ZoneInfo('Europe/London')
NEW_YORK=ZoneInfo('America/New_York')

def origin_at(day):
    if day.weekday()!=4: raise ValueError('Forecast origins must be Fridays')
    return datetime.combine(day,time(12),LONDON)

def close_at(cal,day):
    return cal.schedule.loc[str(day),'close'].to_pydatetime()

def forecast_inputs(prices,cal,origin,target,lag=0):
    """Construct features from history alone; no realised target value is accessed."""
    stamp=origin_at(origin)
    if target!=origin+timedelta(days=7): raise ValueError('Target must be following Friday')
    if pd.Timestamp(target) not in cal.sessions: raise ValueError('Closed target Friday')
    prior=cal.schedule[cal.schedule['close']<stamp]
    if len(prior)<21+lag: raise ValueError('Insufficient exchange-session history')
    base=prior.index[-1-lag].date()
    sessions=[t.date() for t in cal.sessions]
    j=sessions.index(base);look=sessions[j-20]
    # Fail on missing sessions rather than silently using a stale earlier close.
    for day in sessions[j-20:j+1]:
        if day not in prices: raise ValueError(f'Missing eligible price {day}')
        if not np.isfinite(prices[day]) or prices[day]<=0: raise ValueError('Invalid price')
    h=sessions.index(target)-j
    return {'origin':origin,'origin_london':stamp.isoformat(),
            'origin_utc':stamp.astimezone(timezone.utc).isoformat(),
            'origin_new_york':stamp.astimezone(NEW_YORK).isoformat(),
            'base_date':base,'lookback_date':look,'target_date':target,
            'feature_close_utc':close_at(cal,base).isoformat(),
            'lookback_close_utc':close_at(cal,look).isoformat(),
            'target_close_utc':close_at(cal,target).isoformat(),
            'base':prices[base],'momentum':prices[base]/prices[look]-1,
            'horizon_sessions':h,'base_index':sorted(prices).index(base)}

def build(prices,cal,lag=0):
    rows=[];audit=[]
    fri=START+timedelta(days=(4-START.weekday())%7)
    while fri+timedelta(days=7)<=CUT:
        target=fri+timedelta(days=7);reason=''
        if pd.Timestamp(target) not in cal.sessions: reason='target exchange holiday; no Friday close'
        elif target not in prices: reason='target not yet retrieved; no invented observation'
        elif len([d for d in prices if d<fri])<21+lag: reason='insufficient 20-session factor history'
        if not reason:
            row=forecast_inputs(prices,cal,fri,target,lag)
            row.update(actual=prices[target],**{'return':prices[target]/row['base']-1})
            rows.append(row);h=row['horizon_sessions']
            reason='eligible six-session' if h==6 else f'holiday/lag horizon {h}; excluded from primary'
        audit.append({'origin':fri,'target_date':target,'reason':reason})
        fri+=timedelta(days=7)
    return rows,audit

def training_eligibility(row,origin,cal,lag=False):
    """Gate each candidate by actual calendar timestamps, never by provided metadata alone.
    Timestamp availability is a market-close proxy, NOT a verified FRED release timestamp.
    """
    stamp=origin_at(origin)
    target=row.get('target_date')
    if target is None or pd.Timestamp(target) not in cal.sessions:
        return False,'unresolved target date'
    target_stamp=close_at(cal,target)
    if target_stamp>=stamp: return False,'target not yet closed'
    if row.get('return') is None or not np.isfinite(row['return']):
        return False,'unresolved target value'
    feature_stamp=close_at(cal,row['base_date'])
    if feature_stamp>=origin_at(row['origin']) or feature_stamp>=stamp:
        return False,'feature not available at training origin'
    if close_at(cal,row['lookback_date'])>feature_stamp:
        return False,'lookback after feature date'
    if lag:
        prior=cal.schedule[cal.schedule['close']<stamp].index[-1].date()
        # Retain original extra-conservative lag rule: exclude prior-session date.
        if target_stamp>=close_at(cal,prior): return False,'extra lag embargo'
    return True,'eligible under market-close availability assumption'

def fit(train):
    if len(train)<52: raise ValueError('Fewer than 52 matured training outcomes')
    X=np.array([[1.,r['momentum']] for r in train]);y=np.array([r['return'] for r in train])
    b,_,rank,_=np.linalg.lstsq(X,y,rcond=None)
    if rank!=2 or not np.isfinite(b).all(): raise ValueError('Rank deficient or invalid OLS')
    # Independent scalar centered sums, no linear algebra routine.
    xs=[r['momentum'] for r in train];ys=[r['return'] for r in train]
    xm=statistics.mean(xs);ym=statistics.mean(ys)
    slope=sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/sum((x-xm)**2 for x in xs)
    alt=np.array([ym-slope*xm,slope])
    assert np.allclose(b,alt,rtol=1e-10,atol=1e-12)
    return b,float(max(abs(b-alt)))

def evaluate(tests,trainpool,panel,prices,lag=False,cal=None):
    if cal is None: cal=xc.get_calendar('XNYS',start=str(START),end=str(CUT))
    out=[]
    for r in tests:
        stamp=origin_at(r['origin'])
        assert close_at(cal,r['base_date'])<stamp
        assert close_at(cal,r['lookback_date'])<=close_at(cal,r['base_date'])
        train=[z for z in trainpool if training_eligibility(z,r['origin'],cal,lag)[0]]
        assert all(close_at(cal,z['target_date'])<stamp for z in train)
        b,diff=fit(train)
        forecasts={'A':r['base'],'B':r['base']*(1+.25*r['momentum']),
                   'C':r['base']*(1+(b[0]+b[1]*r['momentum'])*r['horizon_sessions']/6)}
        row={k:v for k,v in r.items() if k not in ['base_index','return']}
        row.update(panel=panel,train_n=len(train),training_latest_target=max(z['target_date'] for z in train),
                   intercept=b[0],beta=b[1],ols_independent_max_difference=diff)
        for model,f in forecasts.items():
            assert f>0 and np.isfinite(f)
            row[f'{model}_forecast']=f;row[f'{model}_APE_pct']=ape(f,r['actual']);row[f'{model}_score']=score(ape(f,r['actual']))
        out.append(row)
    return out

def summarize(rows,panel):
    summary=[]
    for m in ['A','B','C']:
        e=[r[f'{m}_APE_pct'] for r in rows]
        summary.append({'panel':panel,'model':m,'n':len(e),'MAPE_pct':statistics.mean(e),
                        'median_APE_pct':statistics.median(e),'max_APE_pct':max(e),
                        'beat_A_pct':100*sum(r[f'{m}_APE_pct']<r['A_APE_pct'] for r in rows)/len(rows),
                        'tie_A_pct':100*sum(r[f'{m}_APE_pct']==r['A_APE_pct'] for r in rows)/len(rows),
                        'mean_accuracy_score_of_50':statistics.mean(r[f'{m}_score'] for r in rows)})
    return summary

def main():
    prices,missing=load_prices()
    cal=xc.get_calendar('XNYS',start=str(START),end=str(CUT))
    expected={s.date() for s in cal.sessions if min(prices)<=s.date()<=max(prices)}
    absent=sorted(expected-set(prices));non_session=sorted(set(prices)-expected)
    audit={'first':str(min(prices)),'last':str(max(prices)),'n_closes':len(prices),
           'missing_expected_sessions':list(map(str,absent)),'unexpected_non_session_prices':list(map(str,non_session)),
           'raw_missing_rows':len(missing),'raw_missing_on_exchange_sessions':[str(d) for d in missing if d in expected]}
    (ROOT/'validation/data_quality.json').write_text(json.dumps(audit,indent=2))
    if absent or non_session: raise ValueError(f'Calendar/data discrepancy: {audit}')
    write_csv(ROOT/'data/processed/prices.csv',[{'date':d,'SP500':v,'source':'FRED webpage' if d==max(prices) else 'FRED CSV'} for d,v in prices.items()])
    cal.schedule.to_csv(ROOT/'data/processed/exchange_schedule.csv')
    candidates,exclusions=build(prices,cal)
    write_csv(ROOT/'results/origin_audit.csv',exclusions)
    six=[r for r in candidates if r['horizon_sessions']==6]
    write_csv(ROOT/'results/training_pool.csv',six)
    primary=evaluate(six[-52:],six,'primary_six_sessions',prices)
    holiday=evaluate(candidates[-52:],six,'all_open_fridays',prices)
    # Lagged features: exact six-session labels, with outcomes strictly matured.
    lagrows,_=build(prices,cal,lag=1)
    lookup={r['origin']:r for r in lagrows};days=list(prices);lagpool=[]
    for r in lagrows:
        j=r['base_index'];target=days[j+6]
        z=dict(r,target_date=target,target_close_utc=close_at(cal,target).isoformat(),
               actual=prices[target],horizon_sessions=6,
               **{'return':prices[target]/r['base']-1})
        lagpool.append(z)
    delayed=evaluate([lookup[r['origin']] for r in primary],lagpool,'one_session_delayed_inputs',prices,lag=True)
    summaries=[]
    for name,rows in [('primary',primary),('holiday',holiday),('delayed',delayed)]:
        write_csv(ROOT/f'results/{name}_forecasts.csv',rows)
        summaries.extend(summarize(rows,rows[0]['panel']))
    write_csv(ROOT/'results/summary.csv',summaries)
    rng=np.random.default_rng(20261031);boot=[]
    for m in ['B','C']:
        delta=np.array([r[f'{m}_APE_pct']-r['A_APE_pct'] for r in primary]);n=len(delta)
        starts=rng.integers(0,n,size=(5000,13))
        inds=((starts[:,:,None]+np.arange(4))%n).reshape(5000,52)
        means=delta[inds].mean(axis=1)
        boot.append({'model_minus_A':m,'mean_APE_difference_percentage_points':delta.mean(),
                     'block_length':4,'draws':5000,'seed':20261031,
                     'bootstrap_2_5_pct':np.quantile(means,.025),'bootstrap_97_5_pct':np.quantile(means,.975)})
    write_csv(ROOT/'results/paired_block_bootstrap.csv',boot)
    # Original sample reconciliation, including incorrectly rounded cells.
    old=[]
    for file in (ROOT/'originals/sp500_backtest').glob('*.csv'):
        for r in csv.DictReader(file.open()):
            bd=r.get('baseline_close_date',r.get('latest_eligible_close_date'))
            td=r.get('target_date',r.get('target_friday'))
            b=prices[date.fromisoformat(bd)];a=prices[date.fromisoformat(td)]
            reported_b=float(r.get('random_walk_forecast',r.get('unchanged_price_forecast')))
            reported_a=float(r.get('actual_index_close',r.get('actual_close')))
            old.append({'file':file.name,'base_date':bd,'target_date':td,
                        'baseline_matches_FRED':b==reported_b,'actual_matches_FRED':a==reported_a,
                        'recomputed_rw_APE':ape(b,a),'reported_rw_APE':r.get('random_walk_APE_pct',r.get('absolute_percentage_error_pct'))})
            if '20_day_lookback_date' in r:
                j=days.index(date.fromisoformat(bd));look=days[j-20];mom=b/prices[look]-1
                old[-1].update({'correct_lookback':str(look),'lookback_matches':str(look)==r['20_day_lookback_date'],
                                'correct_momentum_pct':100*mom,'reported_momentum_pct':float(r['past_20d_return_pct']),
                                'correct_fixed_forecast':b*(1+.25*mom),
                                'reported_fixed_forecast':float(r['fixed_momentum_forecast_alpha_0_25'])})
    keys=list(dict.fromkeys(k for r in old for k in r));old=[{k:r.get(k,'') for k in keys} for r in old]
    write_csv(ROOT/'validation/original_examples_reconciliation.csv',old)
    env={'python':sys.version,'platform':platform.platform(),'packages':{m:importlib.metadata.version(m) for m in ['numpy','pandas','exchange_calendars','pyluach','toolz','tzdata','korean_lunar_calendar','python-dateutil','six']}}
    (ROOT/'validation/environment.json').write_text(json.dumps(env,indent=2))
    (ROOT/'requirements.txt').write_text('\n'.join(f'{k}=={v}' for k,v in env['packages'].items())+'\n')
    checks={'calendar_complete':True,'all_ols_match_independent_scalar_formula':True,
            'primary_count':len(primary),'primary_first_origin':str(primary[0]['origin']),
            'primary_last_origin':str(primary[-1]['origin']),'training_n_first':primary[0]['train_n'],
            'primary_horizons':sorted(set(r['horizon_sessions'] for r in primary)),
            'all_training_targets_before_origin':all(r['training_latest_target']<r['origin'] for r in primary+holiday+delayed),
            'binding_forecast_created':False,'historical_FRED_publication_times_verified':False}
    (ROOT/'validation/run_checks.json').write_text(json.dumps(checks,indent=2))
    print(json.dumps(audit,indent=2));print(json.dumps(checks,indent=2))
    for row in summaries:print(row)
if __name__=='__main__':main()

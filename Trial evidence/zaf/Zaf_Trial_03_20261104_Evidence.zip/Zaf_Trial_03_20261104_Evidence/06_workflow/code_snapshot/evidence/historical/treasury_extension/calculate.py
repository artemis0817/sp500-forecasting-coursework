from pathlib import Path
import sys,csv,io,json,hashlib,statistics
from datetime import date,datetime,time,timedelta,timezone
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
sys.path.insert(0,str(ROOT/'src'))
import run_backtest as b
import numpy as np
import pandas as pd
from pandas.tseries.holiday import USFederalHolidayCalendar,GoodFriday
NY=b.NEW_YORK

def read(path):return list(csv.DictReader(io.StringIO(path.read_text())))
def write(name,rows):b.write_csv(OUT/name,rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
HOLIDAYS=set(USFederalHolidayCalendar().holidays('2021-01-01','2027-12-31').date)
HOLIDAYS.update(GoodFriday.dates('2021-01-01','2027-12-31').date)
HOLIDAYS.add(date(2025,1,9))
def next_business(d):
    d+=timedelta(days=1)
    while d.weekday()>4 or d in HOLIDAYS:d+=timedelta(days=1)
    return d

def release_at(d,lag=1):
    for _ in range(lag):d=next_business(d)
    return datetime.combine(d,time(16,15),NY)

def load_yields():
    result={};missing=[]
    for r in read(OUT/'data/dgs10.csv'):
        d=date.fromisoformat(r['observation_date'])
        if r['DGS10'] in ('','.'):missing.append(d);continue
        v=float(r['DGS10']);assert np.isfinite(v) and d not in result
        result[d]=v
    return dict(sorted(result.items())),missing

def yield_feature(yields,origin,lag=1):
    stamp=b.origin_at(origin)
    ds=[d for d in sorted(yields) if release_at(d,lag)<stamp]
    if len(ds)<6:return None
    end,start=ds[-1],ds[-6]
    if (end-start).days>14:raise ValueError('Five-observation interval exceeds 14 calendar days')
    return {'yield_date':end,'yield_lookback_date':start,'yield_level':yields[end],
        'yield_lookback_level':yields[start],'yield_change_pp':yields[end]-yields[start],
        'yield_release_proxy':release_at(end,lag).isoformat(),'yield_lookback_release_proxy':release_at(start,lag).isoformat(),
        'yield_span_calendar_days':(end-start).days,'yield_staleness_calendar_days':(origin-end).days}

def fit_D(train):
    if len(train)<52:raise ValueError('Not enough matured rows')
    X=np.array([[1,r['momentum'],r['yield_change_pp']] for r in train],float);y=np.array([r['return'] for r in train])
    coef,_,rank,_=np.linalg.lstsq(X,y,rcond=None)
    assert rank==3 and np.isfinite(coef).all()
    # Independent centered two-variable OLS, avoiding lstsq or normal-equation solver.
    xm=X[:,1].mean();zm=X[:,2].mean();ym=y.mean()
    x=X[:,1]-xm;z=X[:,2]-zm;yy=y-ym
    xx=sum(x*x);zz=sum(z*z);xz=sum(x*z);xy=sum(x*yy);zy=sum(z*yy);det=xx*zz-xz*xz
    bx=(xy*zz-zy*xz)/det;bz=(zy*xx-xy*xz)/det;a=ym-bx*xm-bz*zm
    assert np.allclose(coef,[a,bx,bz],rtol=1e-10,atol=1e-12)
    return coef,float(np.linalg.cond(X))

def prepare(pool,yields,lag):
    rows=[]
    for r in pool:
        f=yield_feature(yields,r['origin'],lag)
        if f is not None:rows.append(dict(r,**f))
    return rows

def predict_D(test,pool,cal,window=None):
    train=[r for r in pool if b.training_eligibility(r,test['origin'],cal)[0]]
    if window:train=train[-window:]
    for r in train:
        assert datetime.fromisoformat(r['yield_release_proxy'])<b.origin_at(r['origin'])
        assert b.close_at(cal,r['target_date'])<b.origin_at(test['origin'])
    coef,condition=fit_D(train);ret=float(coef[0]+coef[1]*test['momentum']+coef[2]*test['yield_change_pp'])
    return train,coef,condition,ret,test['base']*(1+ret)

def main():
    protected=[ROOT/'src/run_backtest.py',ROOT/'docs/model_specifications.md']+list((ROOT/'results').rglob('*.csv'))
    hashes={str(p.relative_to(ROOT)):sha(p) for p in protected}
    yields,missing=load_yields()
    prices={date.fromisoformat(r['observation_date']):float(r['SP500']) for r in read(ROOT/'data/raw/fred_SP500.csv')
        if r['SP500'] not in ('','.') and b.START<=date.fromisoformat(r['observation_date'])<=date(2025,7,4)}
    cal=b.xc.get_calendar('XNYS',start=str(b.START),end=str(b.CUT))
    candidates,_=b.build(prices,cal);pool=[r for r in candidates if r['horizon_sessions']==6]
    tests=[r for r in pool if date(2024,1,1)<=r['origin']<=date(2025,6,27)]
    old52=read(ROOT/'results/primary_forecasts.csv');oldorigins={r['origin'] for r in old52}
    assert not {str(r['origin']) for r in tests}&oldorigins
    assert max(r['target_date'] for r in tests)<date.fromisoformat(min(oldorigins))
    abc=b.evaluate(tests,pool,'separate_chronological',prices,cal=cal)
    out=[];ledger=[];prepared={}
    for variant,lag,window in [('primary',1,None),('extra_release_lag',2,None),('optimistic_same_day',0,None),('trailing104',1,104)]:
        pp=prepare(pool,yields,lag);prepared[variant]=pp;lookup={r['origin']:r for r in pp}
        for test,baseline in zip(tests,abc):
            r=lookup[test['origin']];train,coef,condition,ret,f=predict_D(r,pp,cal,window)
            assert len(train)==baseline['train_n'] or variant=='trailing104'
            row={k:v for k,v in r.items() if k not in ['base_index','return']}
            row.update(variant=variant,train_n=len(train),latest_training_target=max(t['target_date'] for t in train),
                intercept=float(coef[0]),momentum_beta=float(coef[1]),yield_beta=float(coef[2]),design_condition=condition,
                forecast_return=ret,D_forecast=f,D_APE=b.ape(f,r['actual']),D_score=b.score(b.ape(f,r['actual'])))
            for m in 'ABC':row.update({m+'_forecast':baseline[m+'_forecast'],m+'_APE':baseline[m+'_APE_pct'],m+'_score':baseline[m+'_score']})
            out.append(row)
            if variant=='primary':
                for t in pp:
                    eligible=b.training_eligibility(t,r['origin'],cal)[0]
                    ledger.append({'fitting_origin':r['origin'],'fitting_origin_timestamp':r['origin_london'],
                        'training_origin':t['origin'],'SP_feature_close':b.close_at(cal,t['base_date']).isoformat(),
                        'yield_date':t['yield_date'],'yield_lookback_date':t['yield_lookback_date'],
                        'yield_release_proxy':t['yield_release_proxy'],'target_close':b.close_at(cal,t['target_date']).isoformat(),
                        'eligible':eligible})
    write('results/all_forecasts.csv',out);write('validation/training_eligibility.csv',ledger)
    primary=[r for r in out if r['variant']=='primary'];summ=[]
    def summary(rr,variant,model):
        errs=[r[model+'_APE'] for r in rr]
        return {'variant':variant,'model':model,'n':len(rr),'MAPE_pct':statistics.mean(errs),
            'median_APE_pct':statistics.median(errs),'max_APE_pct':max(errs),
            'mean_score':statistics.mean(r[model+'_score'] for r in rr),
            'beat_A_pct':100*sum(r[model+'_APE']<r['A_APE'] for r in rr)/len(rr),
            'beat_C_pct':100*sum(r[model+'_APE']<r['C_APE'] for r in rr)/len(rr)}
    for m in 'ABCD':summ.append(summary(primary,'primary',m))
    for variant in ['extra_release_lag','optimistic_same_day','trailing104']:
        rr=[r for r in out if r['variant']==variant];summ.append(summary(rr,variant,'D'))
    write('results/summary.csv',summ)
    regime=[]
    groups={'first_half':primary[:len(primary)//2],'second_half':primary[len(primary)//2:],
        '2024':[r for r in primary if r['origin'].year==2024],'2025':[r for r in primary if r['origin'].year==2025],
        'yield_increase':[r for r in primary if r['yield_change_pp']>0],
        'yield_flat_or_decrease':[r for r in primary if r['yield_change_pp']<=0]}
    for label,rr in groups.items():
        for m in 'ACD':regime.append(summary(rr,label,m))
    write('results/subperiods.csv',regime)
    uncertainty=[];rng=np.random.default_rng(20261031);n=len(primary)
    for comparator in 'AC':
        delta=np.array([r['D_APE']-r[comparator+'_APE'] for r in primary])
        for block in [4,8]:
            starts=rng.integers(0,n,(5000,(n+block-1)//block));idx=((starts[:,:,None]+np.arange(block))%n).reshape(5000,-1)[:,:n]
            means=delta[idx].mean(axis=1)
            uncertainty.append({'comparison':'D-'+comparator,'block':block,'mean_APE_difference_pp':float(delta.mean()),
                'lower_95':float(np.quantile(means,.025)),'upper_95':float(np.quantile(means,.975)),
                'best_leave_one_out_difference':min(float(np.delete(delta,i).mean()) for i in range(n)),
                'worst_leave_one_out_difference':max(float(np.delete(delta,i).mean()) for i in range(n))})
    write('results/paired_uncertainty.csv',uncertainty)
    stability=[]
    for variant in ['primary','extra_release_lag','optimistic_same_day','trailing104']:
        rr=[r for r in out if r['variant']==variant];g=[r['yield_beta'] for r in rr]
        stability.append({'variant':variant,'yield_beta_min':min(g),'yield_beta_max':max(g),'yield_beta_median':statistics.median(g),
            'negative_beta_share_pct':100*sum(x<0 for x in g)/len(g),'first_beta':g[0],'last_beta':g[-1],
            'max_design_condition':max(r['design_condition'] for r in rr)})
    write('results/coefficient_stability.csv',stability)
    last=primary[-1];scenario=[]
    for shock in [-.25,.25]:
        dr=last['yield_beta']*shock
        scenario.append({'origin':last['origin'],'type':'factor sensitivity only','factor_change_pp':shock,
            'return_change_decimal':dr,'return_change_percent':100*dr,'index_point_change':last['base']*dr,
            'D_scenario_level':last['D_forecast']+last['base']*dr})
    write('results/factor_sensitivity_scenario.csv',scenario)
    assumed_actual=last['base']*.97
    adverse=[]
    for m in 'ACD':
        f=last[m+'_forecast']+(last['base']*last['yield_beta']*.25 if m=='D' else 0)
        e=b.ape(f,assumed_actual)
        adverse.append({'origin':last['origin'],'model':m,'assumption':'yield-change factor +25bp; equity target 3% below baseline; hypothetical',
            'forecast':f,'hypothetical_actual':assumed_actual,'APE_pct':e,'score':b.score(e)})
    write('results/adverse_scenario.csv',adverse)
    # Adversarial yield changes must include Thursday observations still unpublished at noon.
    attack_checks=[]
    for r in primary:
        stamp=b.origin_at(r['origin']);yy={d:(v+20+(d.toordinal()%7)) if release_at(d,1)>=stamp else v for d,v in yields.items()}
        attacked_pool=prepare(pool,yy,1);t=next(z for z in attacked_pool if z['origin']==r['origin'])
        _,co,_,_,f=predict_D(t,attacked_pool,cal)
        assert abs(f-r['D_forecast'])<1e-9 and np.allclose(co,[r['intercept'],r['momentum_beta'],r['yield_beta']],atol=1e-12)
        poisoned=[dict(z,**{'return':1000.}) if b.close_at(cal,z['target_date'])>=stamp else z for z in prepared['primary']]
        _,co2,_,_,f2=predict_D(next(z for z in prepared['primary'] if z['origin']==r['origin']),poisoned,cal)
        assert f2==r['D_forecast']
        attack_checks.append({'origin':r['origin'],'unpublished_yield_poison':'PASS','unmatured_return_poison':'PASS'})
    write('validation/adversarial_checks.csv',attack_checks)
    # Independent score / aggregate arithmetic from emitted forecasts.
    for r in out:
        for m in 'ABCD':assert abs(r[m+'_APE']-100*abs(r[m+'_forecast']-r['actual'])/r['actual'])<1e-12
    assert all(sha(ROOT/k)==v for k,v in hashes.items())
    yield_audit=[{'date':d,'yield_percent':v,'primary_release_proxy':release_at(d).isoformat(),'actual_publication_timestamp':'unverified'} for d,v in yields.items()]
    write('data/yields_with_availability_proxy.csv',yield_audit)
    write('data/blank_yield_dates.csv',[{'date':d,'reason':'non-observation; never forward-filled'} for d in missing])
    meta={'execution_utc':datetime.now(timezone.utc).isoformat(),'evaluation_count':len(primary),
        'first_origin':str(primary[0]['origin']),'last_origin':str(primary[-1]['origin']),
        'first_target':str(primary[0]['target_date']),'last_target':str(primary[-1]['target_date']),
        'initial_training_n':primary[0]['train_n'],'final_training_n':primary[-1]['train_n'],
        'original52_overlap':0,'source_yield_first':str(min(yields)),'source_yield_last':str(max(yields)),
        'yield_observations':len(yields),'yield_blank_dates':len(missing),'protocol_sha256':sha(OUT/'PROTOCOL.md'),
        'preserved_files':hashes,'independent_OLS':'all fits PASS','adversarial_origins_passed':len(primary),
        'vintage_certified':False,'no_November_forecast':True}
    (OUT/'validation/run_checks.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(meta,indent=2));print(json.dumps(summ,indent=2));print(json.dumps(stability,indent=2));print(json.dumps(uncertainty,indent=2))
    plots(primary)

def plots(rr):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True)
    dates=[r['origin'] for r in rr]
    axs[0].plot(dates,[r['yield_beta'] for r in rr],color='#387D58');axs[0].axhline(0,color='black',lw=.8)
    axs[0].set_ylabel('Yield coefficient\nreturn per percentage point');axs[0].set_title('Treasury candidate: separate chronological evaluation',loc='left')
    for m,color in [('A','#335C81'),('C','#9A6AB0'),('D','#387D58')]:
        axs[1].plot(dates,np.cumsum([r[m+'_APE'] for r in rr]),label=m,color=color)
    axs[1].set_ylabel('Cumulative APE (percentage points)');axs[1].set_xlabel('Historical forecast origin');axs[1].legend()
    for ax in axs:ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.2)
    fig.tight_layout();fig.savefig(OUT/'figures/stability_and_errors.png',dpi=170);plt.close(fig)
if __name__=='__main__':main()

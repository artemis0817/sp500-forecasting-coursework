# Trial 3 candidate forecasts

The target is the official S&P 500 price-index close on 11 November at 21:00 GMT. Sources were frozen by 2026-11-04T11:33:04.771837+00:00. The information cutoff was 2026-11-04T12:00:00+00:00. Calculations ran from 2026-11-04T12:01:40.903028+00:00 to 2026-11-04T12:01:41.330857+00:00. Validation completed at 2026-11-04T12:01:59.614547+00:00. Formal issuance requires a separate user decision.

| Model | Candidate level | Full-precision level |
|---|---:|---:|
| A | 7568.92 | 7568.92 |
| B | 7508.42 | 7508.416015145294 |
| C | 7573.50 | 7573.504994582201 |
| D | 7593.19 | 7593.190008858995 |

FRED's price series ended 2 November. The approved Yahoo 3 November Close of 7,568.92 matches FT. All models use that baseline. The 20-session lookback is 2026-10-06 at 7818.93, giving momentum -3.19749633%. D uses the 2 November DGS10 yield of 4.91% and the 26 October yield of 5.00%, a change of −0.09 percentage points. Its endpoint publication proxy is 3 November 16:15 New York.

The exchange calendar places six sessions between baseline and target. C/D used 198 matured Friday-origin rows through the 2026-10-30 outcome. The independent membership reconstruction, Decimal checks, future poisoning, unmatured-label exclusion, truncated-history comparison, negative availability controls and all five established test suites passed.

Source timestamps establish an observed-by bound at this trial cutoff. Exact first publication, intraday Treasury observation time and historical feature vintages remain unverified. Local checksums detect changes and depend on the recorded clock. The Trial 3 instructions authorize a post-noon calculation and require approval before issue. Under the earlier pre-noon issuance convention, a later issue would be classified as late.

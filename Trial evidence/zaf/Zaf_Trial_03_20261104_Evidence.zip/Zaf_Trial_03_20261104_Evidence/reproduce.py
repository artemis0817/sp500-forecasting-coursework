"""Offline replay verification from packaged original raw data; never issues a forecast."""
from pathlib import Path
from datetime import date
from html.parser import HTMLParser
import sys,json,hashlib,csv,platform,importlib.metadata
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'06_workflow/code_snapshot/src'))
import live_trials as model
class Rows(HTMLParser):
 def __init__(self):super().__init__();self.rows=[];self.row=None;self.cell=None
 def handle_starttag(self,tag,attrs):
  if tag=='tr':self.row=[]
  if tag in ('td','th') and self.row is not None:self.cell=[]
 def handle_data(self,s):
  if self.cell is not None:self.cell.append(s)
 def handle_endtag(self,tag):
  if tag in ('td','th') and self.cell is not None:self.row.append(''.join(self.cell));self.cell=None
  if tag=='tr' and self.row is not None:self.rows.append(self.row);self.row=None
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for conf in json.loads((ROOT/'trial_index.json').read_text()):
 folder=ROOT/conf['folder'];origin=date.fromisoformat(conf['origin'])
 assert sha(folder/conf['raw_prices'])==conf['raw_price_sha256'];assert sha(folder/conf['raw_yields'])==conf['raw_yield_sha256']
 prices=model.read_series(folder/conf['raw_prices'],'SP500');yields=model.read_series(folder/conf['raw_yields'],'DGS10')
 if conf['yahoo']:
  path=folder/conf['yahoo'];assert sha(path)==conf['yahoo_sha256'];parser=Rows();parser.feed(path.read_text())
  expected_day=date.fromisoformat(conf['input_record']['base_date']);label=expected_day.strftime('%b ')+str(expected_day.day)+expected_day.strftime(', %Y')
  matches=[r for r in parser.rows if r and label in r[0]];assert len(matches)==1
  assert expected_day not in prices
  prices[expected_day]=float(matches[0][4].replace(',',''))
 result=model.predict(prices,yields,origin);inputs,forecasts,tc,td,exclusions,_=result
 checks,independent=model.validate(prices,yields,origin,result)
 for train,key in [(tc,'training_C'),(td,'training_D')]:
  with (folder/conf[key]).open() as f:saved=list(csv.DictReader(f))
  assert len(saved)==len(train)==198
  assert [(str(r['origin']),str(r['target_date'])) for r in train]==[(r['origin'],r['target_date']) for r in saved]
 for f in forecasts:
  saved=next(s for s in conf['forecasts_and_coefficients'] if s['model']==f['model'])
  assert f['forecast_level']==saved['forecast_level']
  assert abs(f['forecast_full_precision']-saved['forecast_full_precision'])<1e-8
  for key in ['intercept','momentum_beta','yield_beta']:assert abs(f[key]-saved[key])<1e-10
 results.append({'trial':conf['trial'],'forecasts':forecasts,'inputs':inputs,'independent_calculations':independent,'validation':checks,'training_membership_matches':True})
print(json.dumps({'mode':'OFFLINE_REPRODUCTION_NOT_NEW_ISSUANCE','python':platform.python_version(),'packages':{k:importlib.metadata.version(k) for k in ['numpy','pandas','exchange_calendars']},'all_4_forecasts_match':True,'trials':results},indent=2,default=str))

# 2026-11-02 replay

Unissued research calculation. Source availability is not certified. Original computation time is recorded; intended noon origin is not an issuance timestamp. No target outcome is included.

Recompute into a NEW run: `python3 research/live_trials/src/live_trials.py run --origin 2026-11-02 --mode replay --source research/live_trials/2026-11-02/runs/20261102T193625570832Z_replay/raw`. Replay only after cutoff. Files here must not be edited. SHA256.json covers all run files; evidence register links the manifest. See overview for tests and approval responsibilities.

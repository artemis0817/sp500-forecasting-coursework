"""Second trial: Tuesday noon GMT -> next Tuesday 16:00 New York close.

Uses saved public snapshots only. Keeps actual generation time separate from
the retrospectively reconstructed information cutoff.
"""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, shutil, platform
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
SNAP=ROOT/'snapshots/20261103T162442Z'
TRIAL=ROOT/'trial_02_20261103_1200GMT'
for sub in ['01_raw','02_inputs','03_models','04_forecasts','05_checks','06_workflow']:
    (TRIAL/sub).mkdir(parents=True,exist_ok=True)
CUTOFF=pd.Timestamp('2026-11-03 12:00:00+00:00')
TARGET=pd.Timestamp('2026-11-10 21:00:00+00:00')
DAY=CUTOFF.tz_localize(None).normalize()
TRAIN_YEARS=3
MIN_TRAIN=100

def writejson(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def load_inputs():
    for name in ['sp500_yahoo.json','vix_cboe.csv','manifest.json']:
        shutil.copy2(SNAP/name,TRIAL/'01_raw'/name)
    result=json.loads((TRIAL/'01_raw/sp500_yahoo.json').read_text())['chart']['result'][0]
    assert result['meta']['symbol']=='^GSPC'
    idx=pd.to_datetime(result['timestamp'],unit='s',utc=True).tz_convert('America/New_York').tz_localize(None).normalize()
    p=pd.Series(result['indicators']['quote'][0]['close'],index=idx,name='sp500_close').dropna().sort_index()
    raw=pd.read_csv(TRIAL/'01_raw/vix_cboe.csv')
    v=pd.Series(raw.CLOSE.to_numpy(),index=pd.to_datetime(raw.DATE,format='%m/%d/%Y'),name='vix_close').dropna().sort_index()
    assert not p.index.duplicated().any() and not v.index.duplicated().any()
    excluded=[str(x.date()) for x in p.index if x>=DAY]
    p=p.loc[p.index<DAY];v=v.loc[v.index<DAY]
    assert (p>0).all() and (v>0).all()
    m=np.log(p/p.shift(20));vc=np.log(v/v.shift(5))
    daily=pd.concat([p,v,m.rename('momentum20'),vc.rename('vix_change5')],axis=1,sort=True)
    daily.loc[daily.index>=pd.Timestamp('2023-09-01')].to_csv(TRIAL/'02_inputs/daily_eligible_inputs.csv',index_label='date',float_format='%.12f')
    latest=dict(price_date=str(p.index[-1].date()),vix_date=str(v.index[-1].date()),p0=float(p.iloc[-1]),
        momentum20=float(m.iloc[-1]),vix_change5=float(vc.iloc[-1]),
        momentum_reference_date=str(p.index[-21].date()),momentum_reference_close=float(p.iloc[-21]),
        vix_reference_date=str(v.index[-6].date()),vix_reference_close=float(v.iloc[-6]),
        excluded_sp500_observation_dates=excluded)
    return p,v,m,vc,latest

def make_training(p,v,m,vc):
    # Match the weekday and noon information origin of this trial. This is a
    # schedule alignment, not a search over weekdays for the best backtest.
    rows=[]
    for origin in pd.date_range(DAY-pd.DateOffset(years=TRAIN_YEARS),DAY,freq='W-TUE'):
        if origin>=DAY:continue
        nominal=origin+pd.Timedelta(days=7)
        target_time=(nominal+pd.Timedelta(hours=16)).tz_localize('America/New_York').tz_convert('UTC')
        if target_time>=CUTOFF:continue
        pp=p.loc[p.index<origin];vv=v.loc[v.index<origin]
        if pp.empty or vv.empty:continue
        pd0,vd0=pp.index[-1],vv.index[-1]
        end=p.loc[p.index<=nominal]
        actualdate=end.index[-1]
        assert (nominal-actualdate).days<=4
        if pd.isna(m.loc[pd0]) or pd.isna(vc.loc[vd0]):continue
        rows.append(dict(origin_date=str(origin.date()),origin_utc=(origin.tz_localize('UTC')+pd.Timedelta(hours=12)).isoformat(),
            price_date=str(pd0.date()),vix_date=str(vd0.date()),p0=float(pp.iloc[-1]),
            momentum20=float(m.loc[pd0]),vix_change5=float(vc.loc[vd0]),
            nominal_target_date=str(nominal.date()),target_close_utc=target_time.isoformat(),
            actual_target_date=str(actualdate.date()),actual_close=float(end.iloc[-1]),
            target_fallback_to_prior_close=bool(actualdate!=nominal),
            target_log_return=float(np.log(end.iloc[-1]/pp.iloc[-1]))))
    train=pd.DataFrame(rows)
    assert len(train)>=MIN_TRAIN
    assert (pd.to_datetime(train.target_close_utc,utc=True)<CUTOFF).all()
    assert (pd.to_datetime(train.price_date)<pd.to_datetime(train.origin_date)).all()
    assert (pd.to_datetime(train.vix_date)<pd.to_datetime(train.origin_date)).all()
    train.to_csv(TRIAL/'02_inputs/training_samples.csv',index=False,float_format='%.12f')
    return train

def main():
    generated=datetime.now(timezone.utc).isoformat()
    p,v,m,vc,current=load_inputs()
    train=make_training(p,v,m,vc)
    forecasts=[];model_details={};checks={}
    for name,factors in [('VIX5_regression',['momentum20','vix_change5']),('momentum_only_OLS',['momentum20'])]:
        X=np.column_stack([np.ones(len(train))]+[train[x].to_numpy() for x in factors])
        y=train.target_log_return.to_numpy()
        beta,_,rank,svals=np.linalg.lstsq(X,y,rcond=None)
        assert rank==X.shape[1]
        reference=np.linalg.solve(X.T@X,X.T@y)
        assert np.allclose(beta,reference,rtol=1e-7,atol=1e-9)
        features=np.array([1.]+[current[x] for x in factors])
        contributions=features*beta
        ret=float(contributions.sum());prediction=float(current['p0']*np.exp(ret))
        terms=['intercept']+factors
        details=dict(model=name,factors=factors,coefficients={x:float(b) for x,b in zip(terms,beta)},
            contributions_to_predicted_log_return={x:float(b) for x,b in zip(terms,contributions)},
            current_features={x:current[x] for x in factors},predicted_log_return=ret,
            predicted_simple_return=float(np.expm1(ret)),forecast_full_precision=prediction,
            forecast_2dp=format(prediction,'.2f'),training_n=len(train),training_design_condition_number=float(svals[0]/svals[-1]),
            note='Training-only coefficients; no window selection or parameter search in this run.')
        model_details[name]=details
        writejson(TRIAL/f'03_models/{name}.json',details)
        design=pd.DataFrame(X,columns=terms);design['target_log_return']=y
        design.to_csv(TRIAL/f'03_models/{name}_design_matrix.csv',index=False,float_format='%.12f')
        forecasts.append(dict(model=name,forecast_value=prediction,forecast_display=format(prediction,'.2f'),
            expected_log_return=ret,expected_simple_return_pct=float(100*np.expm1(ret)),training_n=len(train)))
        checks[name+'_ols_vs_normal_equations']=True
    forecasts.append(dict(model='random_walk_no_drift',forecast_value=current['p0'],forecast_display=format(current['p0'],'.2f'),
        expected_log_return=0.,expected_simple_return_pct=0.,training_n=0))
    for row in forecasts:row.update(trial_id='trial_02',market='S&P 500 price index',unit='index points',
        information_cutoff_utc=CUTOFF.isoformat(),target_time_utc=TARGET.isoformat(),actual_generated_utc=generated,
        status='retrospective_asof_reconstruction',actual_value=None,absolute_percentage_error_pct=None)
    pd.DataFrame(forecasts).to_csv(TRIAL/'04_forecasts/forecast_comparison.csv',index=False,float_format='%.12f')
    record=dict(trial_id='trial_02',information_cutoff_utc=CUTOFF.isoformat(),target_time_utc=TARGET.isoformat(),
        target_definition='Official S&P 500 price-index closing level on 2026-11-10. Current research inputs use Yahoo ^GSPC raw Close.',
        forecast_horizon_hours=float((TARGET-CUTOFF).total_seconds()/3600),actual_generated_utc=generated,
        status='retrospective_asof_reconstruction',current_inputs=current,training=dict(years=TRAIN_YEARS,
        origin_weekday='Tuesday',origin_time_utc='12:00',n=len(train),first_origin=train.origin_date.iloc[0],
        last_origin=train.origin_date.iloc[-1],latest_target=train.nominal_target_date.iloc[-1],
        holiday_target_fallback_count=int(train.target_fallback_to_prior_close.sum())),
        forecasts=forecasts,models=model_details,
        source_policy='Yahoo ^GSPC raw Close and Cboe official VIX historical CLOSE; Yahoo VIX not used.',
        availability_limit='Snapshot downloaded at 16:24 UTC, after the noon cutoff. Prior-session closes are assumed to have been available by noon; historical vintages and publication timestamps are not reconstructed.',
        alignment_note='Historical Tuesday-noon -> next-Tuesday New York close training matches this Tuesday trial. Earlier 103-origin diagnostic used Friday origins. Factor windows, OLS form and three-year lookback are unchanged.',
        selected_final_model=None,human_group_approval='pending',versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__))
    writejson(TRIAL/'04_forecasts/forecast_record.json',record)
    checks.update(training_targets_precede_cutoff=True,historical_inputs_precede_each_origin=True,
        latest_input_dates_precede_current_origin=True,no_2026_11_03_market_data_used=True,
        random_walk_equals_p0=True,source_hashes={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in (TRIAL/'01_raw').glob('*')})
    writejson(TRIAL/'05_checks/run_checks.json',checks)
    writejson(TRIAL/'06_workflow/run_config.json',dict(cutoff=CUTOFF.isoformat(),target=TARGET.isoformat(),momentum_window=20,
        vix_window=5,training_years=3,training_weekday='Tuesday',intercept=True,snapshot=str(SNAP.relative_to(ROOT)),
        generated_utc=generated,trial_folder=TRIAL.name))
    print(pd.DataFrame(forecasts)[['model','forecast_display','expected_simple_return_pct','training_n']].to_string(index=False))
    print(json.dumps(dict(current_inputs=current,training=record['training'],generated_utc=generated),ensure_ascii=False,indent=2))

if __name__=='__main__':main()

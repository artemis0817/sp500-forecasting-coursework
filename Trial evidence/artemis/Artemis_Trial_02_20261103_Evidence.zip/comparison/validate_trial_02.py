"""Independent checks against the saved trial files. Does not overwrite forecasts."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
T=ROOT/'trial_02_20261103_1200GMT'
r=json.loads((T/'04_forecasts/forecast_record.json').read_text(encoding='utf-8'))
tr=pd.read_csv(T/'02_inputs/training_samples.csv')
cutoff=pd.Timestamp(r['information_cutoff_utc'])
assert r['forecast_horizon_hours']==177
assert (pd.to_datetime(tr.target_close_utc,utc=True)<cutoff).all()
assert (pd.to_datetime(tr.price_date)<pd.to_datetime(tr.origin_date)).all()
assert (pd.to_datetime(tr.vix_date)<pd.to_datetime(tr.origin_date)).all()
assert (pd.to_datetime(tr.origin_date).dt.weekday==1).all()
assert len(tr)==155
assert '2026-10-27' not in tr.origin_date.to_list()
ci=r['current_inputs']
assert np.isclose(np.log(ci['p0']/ci['momentum_reference_close']),ci['momentum20'])
v=pd.read_csv(T/'01_raw/vix_cboe.csv')
v['date']=pd.to_datetime(v.DATE,format='%m/%d/%Y')
v=v.loc[v.date<pd.Timestamp('2026-11-03')].sort_values('date')
assert np.isclose(np.log(v.CLOSE.iloc[-1]/v.CLOSE.iloc[-6]),ci['vix_change5'])
checks={}
for name,fields in [('VIX5_regression',['momentum20','vix_change5']),('momentum_only_OLS',['momentum20'])]:
    X=np.column_stack([np.ones(len(tr))]+[tr[x].to_numpy() for x in fields])
    y=np.log(tr.actual_close.to_numpy()/tr.p0.to_numpy())
    coef=np.linalg.solve(X.T@X,X.T@y)
    x=np.array([1.]+[ci[f] for f in fields])
    forecast=float(ci['p0']*np.exp(x@coef))
    saved=next(z for z in r['forecasts'] if z['model']==name)
    assert np.isclose(forecast,saved['forecast_value'],atol=1e-6,rtol=0)
    assert format(forecast,'.2f')==saved['forecast_display']
    checks[name]={'independent_forecast':forecast,'matches_saved_to_2dp':True}
rw=next(z for z in r['forecasts'] if z['model']=='random_walk_no_drift')
assert rw['forecast_value']==ci['p0']
manifest=json.loads((T/'01_raw/manifest.json').read_text(encoding='utf-8'))
for item in manifest:
    if item['file'] not in ['sp500_yahoo.json','vix_cboe.csv']:continue
    assert hashlib.sha256((T/'01_raw'/item['file']).read_bytes()).hexdigest()==item['sha256']
check_record=dict(validated_at_utc=datetime.now(timezone.utc).isoformat(),horizon_hours=177,
    training_rows=155,latest_unknown_target_excluded=True,weekday_alignment_checked=True,
    target_dates_before_cutoff=True,features_independently_recomputed=True,raw_hashes_match_manifest=True,
    regression_checks=checks,random_walk_equals_p0=True)
(T/'05_checks/independent_validation.json').write_text(json.dumps(check_record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(check_record,ensure_ascii=False,indent=2))

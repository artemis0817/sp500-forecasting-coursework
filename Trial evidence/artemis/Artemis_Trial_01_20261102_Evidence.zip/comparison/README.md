# First-trial workflow workspace

本目录新建于伦敦日期2026-11-02。原model_prototype数据、代码、回测和报告未覆盖。

## 当前状态

用户已确认沿用原里程碑：信息截止2026-11-02 12:00 GMT，目标2026-11-09 21:00 GMT，窗口7天9小时。第一轮三个候选已生成并独立核对。

| 模型 | 预测指数点位 |
|---|---:|
| VIX5 regression | 7626.17 |
| Only momentum（带截距OLS） | 7627.42 |
| Random walk（无漂移） | 7580.07 |

进入trial_01_20261102_1200GMT查看本轮完整文件。预测实际生成于11月2日22:06 UTC，属于按中午信息集事后重建，不能记作12:00前发布。实际值和误差等待目标到来后另行记录。

## 已完成

- collect_snapshots.py：并行下载三项来源，保存URL、实际请求/完成时间、响应头、文件哈希和报价元数据。
- snapshots/20261102T215859Z：在21:59 GMT保存标普500、Cboe VIX和Yahoo VIX原始快照。全部在22:00之前完成。
- prepare_inputs.py：逐来源清洗、检查日期与重复观测，构造20日动量和5日VIX变化；未确定最终因子来源，也不生成预测。
- preparation/source_comparison_daily.csv：并排保留官方及备用VIX观测，方便检查来源差异及数据滞后。
- preparation/input_checks.json：输入核查。

## 本轮执行

run_first_trial.py从保存快照读取Yahoo标普500与Cboe官方VIX，剔除11月2日行情，仅用10月30日及以前收盘。以周一到下周一标签匹配试预测安排，使用此前三年155条已揭晓周度样本拟合两个OLS，保存完整设计矩阵、系数、因子贡献、预测记录与真实生成时间。validate_first_trial.py从训练CSV独立重算，三个结果均通过核查。

不能将晚间获取的资料当作中午已经保存的快照，也不能把实际生成时间改写为更早时刻。

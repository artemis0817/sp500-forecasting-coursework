# First trial Agent workflow record

这是实际操作的摘要，不冒充完整原始聊天导出。

1. 用户授权：执行11月2日first trial，三个模型为VIX5 regression、only momentum、random walk；完整保留流程，新建comparison目录。
2. 时间核对：用户先提到伦敦22:00，Agent指出原里程碑为12:00，用户随后明确确认沿用11月13日正式任务对应的中午信息边界。最终cutoff=2026-11-02 12:00 UTC，target=2026-11-09 21:00 UTC。
3. 获取资料：collect_snapshots.py并行调用公开Yahoo ^GSPC图表端点、Cboe VIX历史CSV及Yahoo ^VIX端点，21:59左右保存原始响应和元数据。默认网络受限，通过授权的网络执行获取；未使用账户凭据。
4. 初步检查：prepare_inputs.py发现Yahoo已有11月2日行情，而Cboe最新为10月30日；保存了来源差异报告。Yahoo VIX历史与Cboe存在差异，因此正式输入沿用原先Cboe来源，不混用Yahoo VIX。
5. 信息过滤：cutoff是中午，排除全部11月2日价格，即使夜间已可见。保留10月30日完整收盘。声明为事后信息集重建，并保留真实22:06生成时间。
6. 方法决定：保持M20、VIX5、带截距OLS、3年窗口；按本次周一信息起点与下周一收盘构造历史样本，与原周五探索区分。过滤尚未揭晓的标签，最终155条。
7. 计算：numpy.linalg.lstsq估计两个回归，以P0×exp(rhat)转为点位；random walk=P0。完整设计矩阵、系数和贡献均保存。
8. 主程序核查：日期边界、OLS与正规方程对比、输入源哈希。独立脚本从CSV重算标签、系数、价格及两位小数结果，不直接相信已保存误差或系数。
9. 形成建议：保留全部三个候选对比，未根据预测值大小挑选最终模型，未声称某模型将更准确。最终选型及小组审批待人类决定。
10. 冻结：保存三份预测记录与实际生成时间，实际结果、误差均留空；打包本轮数据和代码，目标到来后另行评分。

工具文件：collect_snapshots.py、prepare_inputs.py、run_first_trial.py、validate_first_trial.py。

人类责任：用户确认时间口径；本轮数值尚待组员交叉核对。Agent没有向WhatsApp或共享文档发送任何内容。

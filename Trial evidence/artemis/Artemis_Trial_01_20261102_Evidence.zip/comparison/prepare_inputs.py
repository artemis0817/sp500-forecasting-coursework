"""Inspect snapshot inputs; no forecast cutoff or source-selection decision is implied."""
from pathlib import Path
import json
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parent
SNAP=ROOT/'snapshots/20261102T215859Z'
OUT=ROOT/'preparation';OUT.mkdir(exist_ok=True)
def chart_series(name,label):
 result=json.loads((SNAP/name).read_text())['chart']['result'][0]
 dates=pd.to_datetime(result['timestamp'],unit='s',utc=True).tz_convert('America/New_York').tz_localize(None).normalize()
 series=pd.Series(result['indicators']['quote'][0]['close'],index=dates,name=label).dropna().sort_index()
 assert not series.index.duplicated().any() and (series>0).all()
 return series
p=chart_series('sp500_yahoo.json','sp500_yahoo_close')
vy=chart_series('vix_yahoo.json','vix_yahoo_close')
raw=pd.read_csv(SNAP/'vix_cboe.csv')
vc=pd.Series(raw.CLOSE.to_numpy(),index=pd.to_datetime(raw.DATE,format='%m/%d/%Y'),name='vix_cboe_close')
df=pd.concat([p,vc,vy],axis=1,sort=True)
df['momentum20']=np.log(p/p.shift(20))
df['vix5_cboe']=np.log(vc/vc.shift(5))
df['vix5_yahoo']=np.log(vy/vy.shift(5))
df.loc[df.index>=pd.Timestamp('2023-10-01')].to_csv(OUT/'source_comparison_daily.csv',index_label='date',float_format='%.10f')
common=pd.concat([vc,vy],axis=1,join='inner').dropna()
checks=dict(sp500_last_date=str(p.index.max().date()),vix_cboe_last_date=str(vc.index.max().date()),
 vix_yahoo_last_date=str(vy.index.max().date()),vix_overlap_n=len(common),
 vix_overlap_max_abs_difference=float((common.iloc[:,0]-common.iloc[:,1]).abs().max()),
 status='Inputs prepared. Forecast origin/cutoff and source policy awaiting clarification. No forecast issued.')
(OUT/'input_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(checks,ensure_ascii=False,indent=2))

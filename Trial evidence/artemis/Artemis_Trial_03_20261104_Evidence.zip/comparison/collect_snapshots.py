"""Capture dated public source snapshots without choosing a forecast cutoff."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import urllib.request, json, hashlib

ROOT=Path(__file__).resolve().parent
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
OUT=ROOT/'snapshots'/stamp;OUT.mkdir(parents=True,exist_ok=False)
sources=[('sp500_yahoo.json','https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?range=10y&interval=1d'),
 ('vix_cboe.csv','https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv'),
 ('vix_yahoo.json','https://query1.finance.yahoo.com/v8/finance/chart/%5EVIX?range=10y&interval=1d')]
def retrieve(pair):
 name,url=pair;record={'file':name,'url':url,'request_started_utc':datetime.now(timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
  with urllib.request.urlopen(req,timeout=35) as response:
   body=response.read();record.update(http_status=response.status,response_headers=dict(response.headers.items()))
  (OUT/name).write_bytes(body)
  record.update(retrieved_utc=datetime.now(timezone.utc).isoformat(),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),status='downloaded')
  if name.endswith('.json'):
   result=json.loads(body)['chart']['result'][0]
   record['instrument_metadata']=result['meta']
  else:
   record['last_csv_line']=body.decode('utf-8-sig').strip().splitlines()[-1]
 except Exception as exc:record.update(status='failed',error=repr(exc),finished_utc=datetime.now(timezone.utc).isoformat())
 return record
with ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(retrieve,sources))
(OUT/'manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
for r in records:print(json.dumps({k:r[k] for k in ['file','status','retrieved_utc','bytes','last_csv_line','error'] if k in r},ensure_ascii=False))
print('Snapshot directory:',OUT)

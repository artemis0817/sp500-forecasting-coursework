# Orainna Trial 04 evidence — 05 November 2026

This is Orainna’s supplemental retrospective evidence package for the frozen Trial 04 dated 20261105. Package assembled on 13 November 2026. It is a reconstruction, not a forecast issued by the noon cutoff.

This package covers Trial 04, organized to accompany the Zaf evidence archives in the coursework repository. It is not a forecast issued by the noon cutoff.

## Contents
- `inputs/frozen_trial.zip`: original Artemis frozen trial archive containing source snapshots, model record and original trial evidence.
- `inputs/comparison_actuals.csv` and source note: later target close transcription and provenance limitations.
- `outputs/rebuilt_forecast.json`: full precision factors, coefficients, training rows, and displayed forecasts.
- `scripts/`: standard-library-only reproduction and independent arithmetic check.
- `evidence/`: prompt/scope, source timing, actual correction path and software record.
- `SHA256SUMS.txt`: integrity hashes for package files.

## Offline reproduction
From this directory, verify the package and reproduce the outputs:
```sh
shasum -a 256 -c SHA256SUMS.txt
python3 scripts/recompute_trial.py inputs/frozen_trial.zip
python3 scripts/independent_check.py
python3 scripts/recompute_ape.py
```
The first command writes `outputs/rebuilt_forecast.json` and verifies the nested raw Yahoo SHA-256. Python 3.9+ is required; no third-party packages or network access are used. `outputs/rebuilt_forecast.json` contains the observation rows required by the independent check.

## Scope and caveats
This is the user's two-row comparison contribution, not the full assessed forecast pack. The group workbook also assesses Random walk, Fixed momentum and Expanding regression. Group approval is not recorded. Target actuals were transcribed from the Yahoo history page, viewed at 2026-11-13 01:08 UTC; original page HTML/screenshot was not retained. FRED matched 9–11 Nov and AP corroborated 12 Nov, as described in the source note.
